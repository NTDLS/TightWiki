EXEC SaveEmoji @Name='american-football', @Path='activity/american-football.png', @Categories= 'activity,american,football'
GO
EXEC SaveEmoji @Name='badminton', @Path='activity/badminton.png', @Categories= 'activity,badminton'
GO
EXEC SaveEmoji @Name='ballet-shoes', @Path='activity/ballet-shoes.png', @Categories= 'activity,ballet,shoes'
GO
EXEC SaveEmoji @Name='baseball', @Path='activity/baseball.png', @Categories= 'activity,baseball'
GO
EXEC SaveEmoji @Name='basketball', @Path='activity/basketball.png', @Categories= 'activity,basketball'
GO
EXEC SaveEmoji @Name='bathtub', @Path='activity/bathtub.png', @Categories= 'activity,bathtub'
GO
EXEC SaveEmoji @Name='bed', @Path='activity/bed.png', @Categories= 'activity,bed'
GO
EXEC SaveEmoji @Name='boomerang', @Path='activity/boomerang.png', @Categories= 'activity,boomerang'
GO
EXEC SaveEmoji @Name='bowling', @Path='activity/bowling.png', @Categories= 'activity,bowling'
GO
EXEC SaveEmoji @Name='boxing-glove', @Path='activity/boxing-glove.png', @Categories= 'activity,boxing,glove'
GO
EXEC SaveEmoji @Name='breast-feeding', @Path='activity/breast-feeding.png', @Categories= 'activity,breast,feeding'
GO
EXEC SaveEmoji @Name='camping', @Path='activity/camping.png', @Categories= 'activity,camping'
GO
EXEC SaveEmoji @Name='canoe', @Path='activity/canoe.png', @Categories= 'activity,canoe'
GO
EXEC SaveEmoji @Name='carousel-horse', @Path='activity/carousel-horse.png', @Categories= 'activity,carousel,horse'
GO
EXEC SaveEmoji @Name='crossed-swords', @Path='activity/crossed-swords.png', @Categories= 'activity,crossed,swords'
GO
EXEC SaveEmoji @Name='curling-stone', @Path='activity/curling-stone.png', @Categories= 'activity,curling,stone'
GO
EXEC SaveEmoji @Name='dagger', @Path='activity/dagger.png', @Categories= 'activity,dagger'
GO
EXEC SaveEmoji @Name='diving-mask', @Path='activity/diving-mask.png', @Categories= 'activity,diving,mask'
GO
EXEC SaveEmoji @Name='ferris-wheel', @Path='activity/ferris-wheel.png', @Categories= 'activity,ferris,wheel'
GO
EXEC SaveEmoji @Name='field-hockey', @Path='activity/field-hockey.png', @Categories= 'activity,field,hockey'
GO
EXEC SaveEmoji @Name='fishing-pole', @Path='activity/fishing-pole.png', @Categories= 'activity,fishing,pole'
GO
EXEC SaveEmoji @Name='flower-playing-cards', @Path='activity/flower-playing-cards.png', @Categories= 'activity,cards,flower,playing'
GO
EXEC SaveEmoji @Name='flying-disc', @Path='activity/flying-disc.png', @Categories= 'activity,disc,flying'
GO
EXEC SaveEmoji @Name='game-die', @Path='activity/game-die.png', @Categories= 'activity,die,game'
GO
EXEC SaveEmoji @Name='goggles', @Path='activity/goggles.png', @Categories= 'activity,goggles'
GO
EXEC SaveEmoji @Name='hammer-and-pick', @Path='activity/hammer-and-pick.png', @Categories= 'activity,and,hammer,pick'
GO
EXEC SaveEmoji @Name='hammer-and-wrench', @Path='activity/hammer-and-wrench.png', @Categories= 'activity,and,hammer,wrench'
GO
EXEC SaveEmoji @Name='hammer', @Path='activity/hammer.png', @Categories= 'activity,hammer'
GO
EXEC SaveEmoji @Name='horse-racing', @Path='activity/horse-racing.png', @Categories= 'activity,horse,racing'
GO
EXEC SaveEmoji @Name='ice-hockey', @Path='activity/ice-hockey.png', @Categories= 'activity,hockey,ice'
GO
EXEC SaveEmoji @Name='ice-skate', @Path='activity/ice-skate.png', @Categories= 'activity,ice,skate'
GO
EXEC SaveEmoji @Name='kite', @Path='activity/kite.png', @Categories= 'activity,kite'
GO
EXEC SaveEmoji @Name='lacrosse', @Path='activity/lacrosse.png', @Categories= 'activity,lacrosse'
GO
EXEC SaveEmoji @Name='man-biking', @Path='activity/man-biking.png', @Categories= 'activity,biking,man'
GO
EXEC SaveEmoji @Name='man-bouncing-ball', @Path='activity/man-bouncing-ball.png', @Categories= 'activity,ball,bouncing,man'
GO
EXEC SaveEmoji @Name='man-cartwheeling', @Path='activity/man-cartwheeling.png', @Categories= 'activity,cartwheeling,man'
GO
EXEC SaveEmoji @Name='man-climbing', @Path='activity/man-climbing.png', @Categories= 'activity,climbing,man'
GO
EXEC SaveEmoji @Name='man-dancing', @Path='activity/man-dancing.png', @Categories= 'activity,dancing,man'
GO
EXEC SaveEmoji @Name='man-golfing', @Path='activity/man-golfing.png', @Categories= 'activity,golfing,man'
GO
EXEC SaveEmoji @Name='man-in-manual-wheelchair', @Path='activity/man-in-manual-wheelchair.png', @Categories= 'activity,in,man,manual,wheelchair'
GO
EXEC SaveEmoji @Name='man-in-motorized-wheelchair', @Path='activity/man-in-motorized-wheelchair.png', @Categories= 'activity,in,man,motorized,wheelchair'
GO
EXEC SaveEmoji @Name='man-kneeling', @Path='activity/man-kneeling.png', @Categories= 'activity,kneeling,man'
GO
EXEC SaveEmoji @Name='man-lifting-weights', @Path='activity/man-lifting-weights.png', @Categories= 'activity,lifting,man,weights'
GO
EXEC SaveEmoji @Name='man-playing-handball', @Path='activity/man-playing-handball.png', @Categories= 'activity,handball,man,playing'
GO
EXEC SaveEmoji @Name='man-playing-water-polo', @Path='activity/man-playing-water-polo.png', @Categories= 'activity,man,playing,polo,water'
GO
EXEC SaveEmoji @Name='man-rowing-boat', @Path='activity/man-rowing-boat.png', @Categories= 'activity,boat,man,rowing'
GO
EXEC SaveEmoji @Name='man-running', @Path='activity/man-running.png', @Categories= 'activity,man,running'
GO
EXEC SaveEmoji @Name='man-standing', @Path='activity/man-standing.png', @Categories= 'activity,man,standing'
GO
EXEC SaveEmoji @Name='man-surfing', @Path='activity/man-surfing.png', @Categories= 'activity,man,surfing'
GO
EXEC SaveEmoji @Name='man-swimming', @Path='activity/man-swimming.png', @Categories= 'activity,man,swimming'
GO
EXEC SaveEmoji @Name='man-walking', @Path='activity/man-walking.png', @Categories= 'activity,man,walking'
GO
EXEC SaveEmoji @Name='man-with-white-cane', @Path='activity/man-with-white-cane.png', @Categories= 'activity,cane,man,white,with'
GO
EXEC SaveEmoji @Name='martial-arts-uniform', @Path='activity/martial-arts-uniform.png', @Categories= 'activity,arts,martial,uniform'
GO
EXEC SaveEmoji @Name='men-wrestling', @Path='activity/men-wrestling.png', @Categories= 'activity,men,wrestling'
GO
EXEC SaveEmoji @Name='people-holding-hands', @Path='activity/people-holding-hands.png', @Categories= 'activity,hands,holding,people'
GO
EXEC SaveEmoji @Name='people-with-bunny-ears', @Path='activity/people-with-bunny-ears.png', @Categories= 'activity,bunny,ears,people,with'
GO
EXEC SaveEmoji @Name='people-wrestling', @Path='activity/people-wrestling.png', @Categories= 'activity,people,wrestling'
GO
EXEC SaveEmoji @Name='performing-arts', @Path='activity/performing-arts.png', @Categories= 'activity,arts,performing'
GO
EXEC SaveEmoji @Name='person-biking', @Path='activity/person-biking.png', @Categories= 'activity,biking,person'
GO
EXEC SaveEmoji @Name='person-bouncing-ball', @Path='activity/person-bouncing-ball.png', @Categories= 'activity,ball,bouncing,person'
GO
EXEC SaveEmoji @Name='person-cartwheeling', @Path='activity/person-cartwheeling.png', @Categories= 'activity,cartwheeling,person'
GO
EXEC SaveEmoji @Name='person-climbing', @Path='activity/person-climbing.png', @Categories= 'activity,climbing,person'
GO
EXEC SaveEmoji @Name='person-feeding-baby', @Path='activity/person-feeding-baby.png', @Categories= 'activity,baby,feeding,person'
GO
EXEC SaveEmoji @Name='person-fencing', @Path='activity/person-fencing.png', @Categories= 'activity,fencing,person'
GO
EXEC SaveEmoji @Name='person-golfing', @Path='activity/person-golfing.png', @Categories= 'activity,golfing,person'
GO
EXEC SaveEmoji @Name='person-in-bed', @Path='activity/person-in-bed.png', @Categories= 'activity,bed,in,person'
GO
EXEC SaveEmoji @Name='person-in-lotus-position', @Path='activity/person-in-lotus-position.png', @Categories= 'activity,in,lotus,person,position'
GO
EXEC SaveEmoji @Name='person-in-manual-wheelchair', @Path='activity/person-in-manual-wheelchair.png', @Categories= 'activity,in,manual,person,wheelchair'
GO
EXEC SaveEmoji @Name='person-in-motorized-wheelchair', @Path='activity/person-in-motorized-wheelchair.png', @Categories= 'activity,in,motorized,person,wheelchair'
GO
EXEC SaveEmoji @Name='person-in-suit-levitating', @Path='activity/person-in-suit-levitating.png', @Categories= 'activity,in,levitating,person,suit'
GO
EXEC SaveEmoji @Name='person-juggling', @Path='activity/person-juggling.png', @Categories= 'activity,juggling,person'
GO
EXEC SaveEmoji @Name='person-kneeling', @Path='activity/person-kneeling.png', @Categories= 'activity,kneeling,person'
GO
EXEC SaveEmoji @Name='person-lifting-weights', @Path='activity/person-lifting-weights.png', @Categories= 'activity,lifting,person,weights'
GO
EXEC SaveEmoji @Name='person-mountain-biking', @Path='activity/person-mountain-biking.png', @Categories= 'activity,biking,mountain,person'
GO
EXEC SaveEmoji @Name='person-playing-handball', @Path='activity/person-playing-handball.png', @Categories= 'activity,handball,person,playing'
GO
EXEC SaveEmoji @Name='person-playing-water-polo', @Path='activity/person-playing-water-polo.png', @Categories= 'activity,person,playing,polo,water'
GO
EXEC SaveEmoji @Name='person-rowing-boat', @Path='activity/person-rowing-boat.png', @Categories= 'activity,boat,person,rowing'
GO
EXEC SaveEmoji @Name='person-running', @Path='activity/person-running.png', @Categories= 'activity,person,running'
GO
EXEC SaveEmoji @Name='person-standing', @Path='activity/person-standing.png', @Categories= 'activity,person,standing'
GO
EXEC SaveEmoji @Name='person-surfing', @Path='activity/person-surfing.png', @Categories= 'activity,person,surfing'
GO
EXEC SaveEmoji @Name='person-swimming', @Path='activity/person-swimming.png', @Categories= 'activity,person,swimming'
GO
EXEC SaveEmoji @Name='person-taking-bath', @Path='activity/person-taking-bath.png', @Categories= 'activity,bath,person,taking'
GO
EXEC SaveEmoji @Name='person-walking', @Path='activity/person-walking.png', @Categories= 'activity,person,walking'
GO
EXEC SaveEmoji @Name='person-with-white-cane', @Path='activity/person-with-white-cane.png', @Categories= 'activity,cane,person,white,with'
GO
EXEC SaveEmoji @Name='ping-pong', @Path='activity/ping-pong.png', @Categories= 'activity,ping,pong'
GO
EXEC SaveEmoji @Name='pool-8-ball', @Path='activity/pool-8-ball.png', @Categories= '8,activity,ball,pool'
GO
EXEC SaveEmoji @Name='roller-skate', @Path='activity/roller-skate.png', @Categories= 'activity,roller,skate'
GO
EXEC SaveEmoji @Name='rugby-football', @Path='activity/rugby-football.png', @Categories= 'activity,football,rugby'
GO
EXEC SaveEmoji @Name='shopping-bags', @Path='activity/shopping-bags.png', @Categories= 'activity,bags,shopping'
GO
EXEC SaveEmoji @Name='skateboard', @Path='activity/skateboard.png', @Categories= 'activity,skateboard'
GO
EXEC SaveEmoji @Name='skier', @Path='activity/skier.png', @Categories= 'activity,skier'
GO
EXEC SaveEmoji @Name='skis', @Path='activity/skis.png', @Categories= 'activity,skis'
GO
EXEC SaveEmoji @Name='sled', @Path='activity/sled.png', @Categories= 'activity,sled'
GO
EXEC SaveEmoji @Name='snowboarder', @Path='activity/snowboarder.png', @Categories= 'activity,snowboarder'
GO
EXEC SaveEmoji @Name='soccer-ball', @Path='activity/soccer-ball.png', @Categories= 'activity,ball,soccer'
GO
EXEC SaveEmoji @Name='softball', @Path='activity/softball.png', @Categories= 'activity,softball'
GO
EXEC SaveEmoji @Name='tennis', @Path='activity/tennis.png', @Categories= 'activity,tennis'
GO
EXEC SaveEmoji @Name='volleyball', @Path='activity/volleyball.png', @Categories= 'activity,volleyball'
GO
EXEC SaveEmoji @Name='woman-biking', @Path='activity/woman-biking.png', @Categories= 'activity,biking,woman'
GO
EXEC SaveEmoji @Name='woman-bouncing-ball', @Path='activity/woman-bouncing-ball.png', @Categories= 'activity,ball,bouncing,woman'
GO
EXEC SaveEmoji @Name='woman-cartwheeling', @Path='activity/woman-cartwheeling.png', @Categories= 'activity,cartwheeling,woman'
GO
EXEC SaveEmoji @Name='woman-climbing', @Path='activity/woman-climbing.png', @Categories= 'activity,climbing,woman'
GO
EXEC SaveEmoji @Name='woman-dancing', @Path='activity/woman-dancing.png', @Categories= 'activity,dancing,woman'
GO
EXEC SaveEmoji @Name='woman-golfing', @Path='activity/woman-golfing.png', @Categories= 'activity,golfing,woman'
GO
EXEC SaveEmoji @Name='woman-in-lotus-position', @Path='activity/woman-in-lotus-position.png', @Categories= 'activity,in,lotus,position,woman'
GO
EXEC SaveEmoji @Name='woman-in-manual-wheelchair', @Path='activity/woman-in-manual-wheelchair.png', @Categories= 'activity,in,manual,wheelchair,woman'
GO
EXEC SaveEmoji @Name='woman-in-motorized-wheelchair', @Path='activity/woman-in-motorized-wheelchair.png', @Categories= 'activity,in,motorized,wheelchair,woman'
GO
EXEC SaveEmoji @Name='woman-juggling', @Path='activity/woman-juggling.png', @Categories= 'activity,juggling,woman'
GO
EXEC SaveEmoji @Name='woman-kneeling', @Path='activity/woman-kneeling.png', @Categories= 'activity,kneeling,woman'
GO
EXEC SaveEmoji @Name='woman-lifting-weights', @Path='activity/woman-lifting-weights.png', @Categories= 'activity,lifting,weights,woman'
GO
EXEC SaveEmoji @Name='woman-mountain-biking', @Path='activity/woman-mountain-biking.png', @Categories= 'activity,biking,mountain,woman'
GO
EXEC SaveEmoji @Name='woman-playing-handball', @Path='activity/woman-playing-handball.png', @Categories= 'activity,handball,playing,woman'
GO
EXEC SaveEmoji @Name='woman-playing-water-polo', @Path='activity/woman-playing-water-polo.png', @Categories= 'activity,playing,polo,water,woman'
GO
EXEC SaveEmoji @Name='woman-rowing-boat', @Path='activity/woman-rowing-boat.png', @Categories= 'activity,boat,rowing,woman'
GO
EXEC SaveEmoji @Name='woman-running', @Path='activity/woman-running.png', @Categories= 'activity,running,woman'
GO
EXEC SaveEmoji @Name='woman-standing', @Path='activity/woman-standing.png', @Categories= 'activity,standing,woman'
GO
EXEC SaveEmoji @Name='woman-surfing', @Path='activity/woman-surfing.png', @Categories= 'activity,surfing,woman'
GO
EXEC SaveEmoji @Name='woman-swimming', @Path='activity/woman-swimming.png', @Categories= 'activity,swimming,woman'
GO
EXEC SaveEmoji @Name='woman-walking', @Path='activity/woman-walking.png', @Categories= 'activity,walking,woman'
GO
EXEC SaveEmoji @Name='woman-with-white-cane', @Path='activity/woman-with-white-cane.png', @Categories= 'activity,cane,white,with,woman'
GO
EXEC SaveEmoji @Name='women-wrestling', @Path='activity/women-wrestling.png', @Categories= 'activity,women,wrestling'
GO
EXEC SaveEmoji @Name='yo-yo', @Path='activity/yo-yo.png', @Categories= 'activity,yo'
GO
EXEC SaveEmoji @Name='ant', @Path='animal/ant.png', @Categories= 'animal,ant'
GO
EXEC SaveEmoji @Name='badger', @Path='animal/badger.png', @Categories= 'animal,badger'
GO
EXEC SaveEmoji @Name='bat', @Path='animal/bat.png', @Categories= 'animal,bat'
GO
EXEC SaveEmoji @Name='beaver', @Path='animal/beaver.png', @Categories= 'animal,beaver'
GO
EXEC SaveEmoji @Name='beetle', @Path='animal/beetle.png', @Categories= 'animal,beetle'
GO
EXEC SaveEmoji @Name='bison', @Path='animal/bison.png', @Categories= 'animal,bison'
GO
EXEC SaveEmoji @Name='black-bird', @Path='animal/black-bird.png', @Categories= 'animal,bird,black'
GO
EXEC SaveEmoji @Name='black-cat', @Path='animal/black-cat.png', @Categories= 'animal,black,cat'
GO
EXEC SaveEmoji @Name='blowfish', @Path='animal/blowfish.png', @Categories= 'animal,blowfish'
GO
EXEC SaveEmoji @Name='boar', @Path='animal/boar.png', @Categories= 'animal,boar'
GO
EXEC SaveEmoji @Name='bug', @Path='animal/bug.png', @Categories= 'animal,bug'
GO
EXEC SaveEmoji @Name='butterfly', @Path='animal/butterfly.png', @Categories= 'animal,butterfly'
GO
EXEC SaveEmoji @Name='camel', @Path='animal/camel.png', @Categories= 'animal,camel'
GO
EXEC SaveEmoji @Name='cat', @Path='animal/cat.png', @Categories= 'animal,cat'
GO
EXEC SaveEmoji @Name='chipmunk', @Path='animal/chipmunk.png', @Categories= 'animal,chipmunk'
GO
EXEC SaveEmoji @Name='cockroach', @Path='animal/cockroach.png', @Categories= 'animal,cockroach'
GO
EXEC SaveEmoji @Name='cow', @Path='animal/cow.png', @Categories= 'animal,cow'
GO
EXEC SaveEmoji @Name='crab', @Path='animal/crab.png', @Categories= 'animal,crab'
GO
EXEC SaveEmoji @Name='cricket', @Path='animal/cricket.png', @Categories= 'animal,cricket'
GO
EXEC SaveEmoji @Name='crocodile', @Path='animal/crocodile.png', @Categories= 'animal,crocodile'
GO
EXEC SaveEmoji @Name='deer', @Path='animal/deer.png', @Categories= 'animal,deer'
GO
EXEC SaveEmoji @Name='dodo', @Path='animal/dodo.png', @Categories= 'animal,dodo'
GO
EXEC SaveEmoji @Name='dog', @Path='animal/dog.png', @Categories= 'animal,dog'
GO
EXEC SaveEmoji @Name='dolphin', @Path='animal/dolphin.png', @Categories= 'animal,dolphin'
GO
EXEC SaveEmoji @Name='donkey', @Path='animal/donkey.png', @Categories= 'animal,donkey'
GO
EXEC SaveEmoji @Name='dove', @Path='animal/dove.png', @Categories= 'animal,dove'
GO
EXEC SaveEmoji @Name='dragon', @Path='animal/dragon.png', @Categories= 'animal,dragon'
GO
EXEC SaveEmoji @Name='duck', @Path='animal/duck.png', @Categories= 'animal,duck'
GO
EXEC SaveEmoji @Name='eagle', @Path='animal/eagle.png', @Categories= 'animal,eagle'
GO
EXEC SaveEmoji @Name='elephant', @Path='animal/elephant.png', @Categories= 'animal,elephant'
GO
EXEC SaveEmoji @Name='ewe', @Path='animal/ewe.png', @Categories= 'animal,ewe'
GO
EXEC SaveEmoji @Name='fish', @Path='animal/fish.png', @Categories= 'animal,fish'
GO
EXEC SaveEmoji @Name='flamingo', @Path='animal/flamingo.png', @Categories= 'animal,flamingo'
GO
EXEC SaveEmoji @Name='fly', @Path='animal/fly.png', @Categories= 'animal,fly'
GO
EXEC SaveEmoji @Name='front-facing-baby-chick', @Path='animal/front-facing-baby-chick.png', @Categories= 'animal,baby,chick,facing,front'
GO
EXEC SaveEmoji @Name='giraffe', @Path='animal/giraffe.png', @Categories= 'animal,giraffe'
GO
EXEC SaveEmoji @Name='goat', @Path='animal/goat.png', @Categories= 'animal,goat'
GO
EXEC SaveEmoji @Name='goose', @Path='animal/goose.png', @Categories= 'animal,goose'
GO
EXEC SaveEmoji @Name='gorilla', @Path='animal/gorilla.png', @Categories= 'animal,gorilla'
GO
EXEC SaveEmoji @Name='guide-dog', @Path='animal/guide-dog.png', @Categories= 'animal,dog,guide'
GO
EXEC SaveEmoji @Name='hatching-chick', @Path='animal/hatching-chick.png', @Categories= 'animal,chick,hatching'
GO
EXEC SaveEmoji @Name='hedgehog', @Path='animal/hedgehog.png', @Categories= 'animal,hedgehog'
GO
EXEC SaveEmoji @Name='hippopotamus', @Path='animal/hippopotamus.png', @Categories= 'animal,hippopotamus'
GO
EXEC SaveEmoji @Name='honeybee', @Path='animal/honeybee.png', @Categories= 'animal,honeybee'
GO
EXEC SaveEmoji @Name='horse', @Path='animal/horse.png', @Categories= 'animal,horse'
GO
EXEC SaveEmoji @Name='jellyfish', @Path='animal/jellyfish.png', @Categories= 'animal,jellyfish'
GO
EXEC SaveEmoji @Name='kangaroo', @Path='animal/kangaroo.png', @Categories= 'animal,kangaroo'
GO
EXEC SaveEmoji @Name='lady-beetle', @Path='animal/lady-beetle.png', @Categories= 'animal,beetle,lady'
GO
EXEC SaveEmoji @Name='leopard', @Path='animal/leopard.png', @Categories= 'animal,leopard'
GO
EXEC SaveEmoji @Name='lizard', @Path='animal/lizard.png', @Categories= 'animal,lizard'
GO
EXEC SaveEmoji @Name='llama', @Path='animal/llama.png', @Categories= 'animal,llama'
GO
EXEC SaveEmoji @Name='lobster', @Path='animal/lobster.png', @Categories= 'animal,lobster'
GO
EXEC SaveEmoji @Name='mammoth', @Path='animal/mammoth.png', @Categories= 'animal,mammoth'
GO
EXEC SaveEmoji @Name='monkey', @Path='animal/monkey.png', @Categories= 'animal,monkey'
GO
EXEC SaveEmoji @Name='mosquito', @Path='animal/mosquito.png', @Categories= 'animal,mosquito'
GO
EXEC SaveEmoji @Name='mouse', @Path='animal/mouse.png', @Categories= 'animal,mouse'
GO
EXEC SaveEmoji @Name='octopus', @Path='animal/octopus.png', @Categories= 'animal,octopus'
GO
EXEC SaveEmoji @Name='orangutan', @Path='animal/orangutan.png', @Categories= 'animal,orangutan'
GO
EXEC SaveEmoji @Name='otter', @Path='animal/otter.png', @Categories= 'animal,otter'
GO
EXEC SaveEmoji @Name='owl', @Path='animal/owl.png', @Categories= 'animal,owl'
GO
EXEC SaveEmoji @Name='ox', @Path='animal/ox.png', @Categories= 'animal,ox'
GO
EXEC SaveEmoji @Name='panda', @Path='animal/panda.png', @Categories= 'animal,panda'
GO
EXEC SaveEmoji @Name='parrot', @Path='animal/parrot.png', @Categories= 'animal,parrot'
GO
EXEC SaveEmoji @Name='peacock', @Path='animal/peacock.png', @Categories= 'animal,peacock'
GO
EXEC SaveEmoji @Name='penguin', @Path='animal/penguin.png', @Categories= 'animal,penguin'
GO
EXEC SaveEmoji @Name='pig', @Path='animal/pig.png', @Categories= 'animal,pig'
GO
EXEC SaveEmoji @Name='poodle', @Path='animal/poodle.png', @Categories= 'animal,poodle'
GO
EXEC SaveEmoji @Name='rabbit', @Path='animal/rabbit.png', @Categories= 'animal,rabbit'
GO
EXEC SaveEmoji @Name='raccoon', @Path='animal/raccoon.png', @Categories= 'animal,raccoon'
GO
EXEC SaveEmoji @Name='ram', @Path='animal/ram.png', @Categories= 'animal,ram'
GO
EXEC SaveEmoji @Name='rat', @Path='animal/rat.png', @Categories= 'animal,rat'
GO
EXEC SaveEmoji @Name='rhinoceros', @Path='animal/rhinoceros.png', @Categories= 'animal,rhinoceros'
GO
EXEC SaveEmoji @Name='rooster', @Path='animal/rooster.png', @Categories= 'animal,rooster'
GO
EXEC SaveEmoji @Name='sauropod', @Path='animal/sauropod.png', @Categories= 'animal,sauropod'
GO
EXEC SaveEmoji @Name='scorpion', @Path='animal/scorpion.png', @Categories= 'animal,scorpion'
GO
EXEC SaveEmoji @Name='seal', @Path='animal/seal.png', @Categories= 'animal,seal'
GO
EXEC SaveEmoji @Name='service-dog', @Path='animal/service-dog.png', @Categories= 'animal,dog,service'
GO
EXEC SaveEmoji @Name='shark', @Path='animal/shark.png', @Categories= 'animal,shark'
GO
EXEC SaveEmoji @Name='shrimp', @Path='animal/shrimp.png', @Categories= 'animal,shrimp'
GO
EXEC SaveEmoji @Name='skunk', @Path='animal/skunk.png', @Categories= 'animal,skunk'
GO
EXEC SaveEmoji @Name='sloth', @Path='animal/sloth.png', @Categories= 'animal,sloth'
GO
EXEC SaveEmoji @Name='snail', @Path='animal/snail.png', @Categories= 'animal,snail'
GO
EXEC SaveEmoji @Name='snake', @Path='animal/snake.png', @Categories= 'animal,snake'
GO
EXEC SaveEmoji @Name='spider', @Path='animal/spider.png', @Categories= 'animal,spider'
GO
EXEC SaveEmoji @Name='spouting-whale', @Path='animal/spouting-whale.png', @Categories= 'animal,spouting,whale'
GO
EXEC SaveEmoji @Name='squid', @Path='animal/squid.png', @Categories= 'animal,squid'
GO
EXEC SaveEmoji @Name='swan', @Path='animal/swan.png', @Categories= 'animal,swan'
GO
EXEC SaveEmoji @Name='t-rex', @Path='animal/t-rex.png', @Categories= 'animal,rex,t'
GO
EXEC SaveEmoji @Name='teddy-bear', @Path='animal/teddy-bear.png', @Categories= 'animal,bear,teddy'
GO
EXEC SaveEmoji @Name='tiger', @Path='animal/tiger.png', @Categories= 'animal,tiger'
GO
EXEC SaveEmoji @Name='tropical-fish', @Path='animal/tropical-fish.png', @Categories= 'animal,fish,tropical'
GO
EXEC SaveEmoji @Name='turkey', @Path='animal/turkey.png', @Categories= 'animal,turkey'
GO
EXEC SaveEmoji @Name='turtle', @Path='animal/turtle.png', @Categories= 'animal,turtle'
GO
EXEC SaveEmoji @Name='two-hump-camel', @Path='animal/two-hump-camel.png', @Categories= 'animal,camel,hump,two'
GO
EXEC SaveEmoji @Name='water-buffalo', @Path='animal/water-buffalo.png', @Categories= 'animal,buffalo,water'
GO
EXEC SaveEmoji @Name='whale', @Path='animal/whale.png', @Categories= 'animal,whale'
GO
EXEC SaveEmoji @Name='wolf', @Path='animal/wolf.png', @Categories= 'animal,wolf'
GO
EXEC SaveEmoji @Name='worm', @Path='animal/worm.png', @Categories= 'animal,worm'
GO
EXEC SaveEmoji @Name='zebra', @Path='animal/zebra.png', @Categories= 'animal,zebra'
GO
EXEC SaveEmoji @Name='back-arrow', @Path='arrow/back-arrow.png', @Categories= 'arrow,back'
GO
EXEC SaveEmoji @Name='bow-and-arrow', @Path='arrow/bow-and-arrow.png', @Categories= 'and,arrow,bow'
GO
EXEC SaveEmoji @Name='clockwise-vertical-arrows', @Path='arrow/clockwise-vertical-arrows.png', @Categories= 'arrow,arrows,clockwise,vertical'
GO
EXEC SaveEmoji @Name='counterclockwise-arrows-button', @Path='arrow/counterclockwise-arrows-button.png', @Categories= 'arrow,arrows,button,counterclockwise'
GO
EXEC SaveEmoji @Name='down-arrow', @Path='arrow/down-arrow.png', @Categories= 'arrow,down'
GO
EXEC SaveEmoji @Name='down-left-arrow', @Path='arrow/down-left-arrow.png', @Categories= 'arrow,down,left'
GO
EXEC SaveEmoji @Name='down-right-arrow', @Path='arrow/down-right-arrow.png', @Categories= 'arrow,down,right'
GO
EXEC SaveEmoji @Name='end-arrow', @Path='arrow/end-arrow.png', @Categories= 'arrow,end'
GO
EXEC SaveEmoji @Name='envelope-with-arrow', @Path='arrow/envelope-with-arrow.png', @Categories= 'arrow,envelope,with'
GO
EXEC SaveEmoji @Name='fast-down-button', @Path='arrow/fast-down-button.png', @Categories= 'arrow,button,down,fast'
GO
EXEC SaveEmoji @Name='fast-forward-button', @Path='arrow/fast-forward-button.png', @Categories= 'arrow,button,fast,forward'
GO
EXEC SaveEmoji @Name='fast-reverse-button', @Path='arrow/fast-reverse-button.png', @Categories= 'arrow,button,fast,reverse'
GO
EXEC SaveEmoji @Name='fast-up-button', @Path='arrow/fast-up-button.png', @Categories= 'arrow,button,fast,up'
GO
EXEC SaveEmoji @Name='left-arrow-curving-right', @Path='arrow/left-arrow-curving-right.png', @Categories= 'arrow,curving,left,right'
GO
EXEC SaveEmoji @Name='left-arrow', @Path='arrow/left-arrow.png', @Categories= 'arrow,left'
GO
EXEC SaveEmoji @Name='left-right-arrow', @Path='arrow/left-right-arrow.png', @Categories= 'arrow,left,right'
GO
EXEC SaveEmoji @Name='mobile-phone-with-arrow', @Path='arrow/mobile-phone-with-arrow.png', @Categories= 'arrow,mobile,phone,with'
GO
EXEC SaveEmoji @Name='on-arrow', @Path='arrow/on-arrow.png', @Categories= 'arrow,on'
GO
EXEC SaveEmoji @Name='red-triangle-pointed-down', @Path='arrow/red-triangle-pointed-down.png', @Categories= 'arrow,down,pointed,red,triangle'
GO
EXEC SaveEmoji @Name='red-triangle-pointed-up', @Path='arrow/red-triangle-pointed-up.png', @Categories= 'arrow,pointed,red,triangle,up'
GO
EXEC SaveEmoji @Name='right-arrow-curving-down', @Path='arrow/right-arrow-curving-down.png', @Categories= 'arrow,curving,down,right'
GO
EXEC SaveEmoji @Name='right-arrow-curving-left', @Path='arrow/right-arrow-curving-left.png', @Categories= 'arrow,curving,left,right'
GO
EXEC SaveEmoji @Name='right-arrow-curving-up', @Path='arrow/right-arrow-curving-up.png', @Categories= 'arrow,curving,right,up'
GO
EXEC SaveEmoji @Name='right-arrow', @Path='arrow/right-arrow.png', @Categories= 'arrow,right'
GO
EXEC SaveEmoji @Name='soon-arrow', @Path='arrow/soon-arrow.png', @Categories= 'arrow,soon'
GO
EXEC SaveEmoji @Name='top-arrow', @Path='arrow/top-arrow.png', @Categories= 'arrow,top'
GO
EXEC SaveEmoji @Name='up-arrow', @Path='arrow/up-arrow.png', @Categories= 'arrow,up'
GO
EXEC SaveEmoji @Name='up-button', @Path='arrow/up-button.png', @Categories= 'arrow,button,up'
GO
EXEC SaveEmoji @Name='up-down-arrow', @Path='arrow/up-down-arrow.png', @Categories= 'arrow,down,up'
GO
EXEC SaveEmoji @Name='up-left-arrow', @Path='arrow/up-left-arrow.png', @Categories= 'arrow,left,up'
GO
EXEC SaveEmoji @Name='up-right-arrow', @Path='arrow/up-right-arrow.png', @Categories= 'arrow,right,up'
GO
EXEC SaveEmoji @Name='upwards-button', @Path='arrow/upwards-button.png', @Categories= 'arrow,button,upwards'
GO
EXEC SaveEmoji @Name='accordion', @Path='art/accordion.png', @Categories= 'accordion,art'
GO
EXEC SaveEmoji @Name='artist-palette', @Path='art/artist-palette.png', @Categories= 'art,artist,palette'
GO
EXEC SaveEmoji @Name='banjo', @Path='art/banjo.png', @Categories= 'art,banjo'
GO
EXEC SaveEmoji @Name='drum', @Path='art/drum.png', @Categories= 'art,drum'
GO
EXEC SaveEmoji @Name='film-frames', @Path='art/film-frames.png', @Categories= 'art,film,frames'
GO
EXEC SaveEmoji @Name='flute', @Path='art/flute.png', @Categories= 'art,flute'
GO
EXEC SaveEmoji @Name='fountain-pen', @Path='art/fountain-pen.png', @Categories= 'art,fountain,pen'
GO
EXEC SaveEmoji @Name='guitar', @Path='art/guitar.png', @Categories= 'art,guitar'
GO
EXEC SaveEmoji @Name='maracas', @Path='art/maracas.png', @Categories= 'art,maracas'
GO
EXEC SaveEmoji @Name='musical-keyboard', @Path='art/musical-keyboard.png', @Categories= 'art,keyboard,musical'
GO
EXEC SaveEmoji @Name='musical-note', @Path='art/musical-note.png', @Categories= 'art,musical,note'
GO
EXEC SaveEmoji @Name='musical-notes', @Path='art/musical-notes.png', @Categories= 'art,musical,notes'
GO
EXEC SaveEmoji @Name='musical-score', @Path='art/musical-score.png', @Categories= 'art,musical,score'
GO
EXEC SaveEmoji @Name='notebook-with-decorative-cover', @Path='art/notebook-with-decorative-cover.png', @Categories= 'art,cover,decorative,notebook,with'
GO
EXEC SaveEmoji @Name='notebook', @Path='art/notebook.png', @Categories= 'art,notebook'
GO
EXEC SaveEmoji @Name='open-book', @Path='art/open-book.png', @Categories= 'art,book,open'
GO
EXEC SaveEmoji @Name='orange-book', @Path='art/orange-book.png', @Categories= 'art,book,orange'
GO
EXEC SaveEmoji @Name='page-facing-up', @Path='art/page-facing-up.png', @Categories= 'art,facing,page,up'
GO
EXEC SaveEmoji @Name='page-with-curl', @Path='art/page-with-curl.png', @Categories= 'art,curl,page,with'
GO
EXEC SaveEmoji @Name='paintbrush', @Path='art/paintbrush.png', @Categories= 'art,paintbrush'
GO
EXEC SaveEmoji @Name='pen', @Path='art/pen.png', @Categories= 'art,pen'
GO
EXEC SaveEmoji @Name='pencil', @Path='art/pencil.png', @Categories= 'art,pencil'
GO
EXEC SaveEmoji @Name='pinata', @Path='art/pinata.png', @Categories= 'art,pinata'
GO
EXEC SaveEmoji @Name='pine-decoration', @Path='art/pine-decoration.png', @Categories= 'art,decoration,pine'
GO
EXEC SaveEmoji @Name='placard', @Path='art/placard.png', @Categories= 'art,placard'
GO
EXEC SaveEmoji @Name='postal-horn', @Path='art/postal-horn.png', @Categories= 'art,horn,postal'
GO
EXEC SaveEmoji @Name='pushpin', @Path='art/pushpin.png', @Categories= 'art,pushpin'
GO
EXEC SaveEmoji @Name='saxophone', @Path='art/saxophone.png', @Categories= 'art,saxophone'
GO
EXEC SaveEmoji @Name='scissors', @Path='art/scissors.png', @Categories= 'art,scissors'
GO
EXEC SaveEmoji @Name='spiral-notepad', @Path='art/spiral-notepad.png', @Categories= 'art,notepad,spiral'
GO
EXEC SaveEmoji @Name='straight-ruler', @Path='art/straight-ruler.png', @Categories= 'art,ruler,straight'
GO
EXEC SaveEmoji @Name='triangular-ruler', @Path='art/triangular-ruler.png', @Categories= 'art,ruler,triangular'
GO
EXEC SaveEmoji @Name='trumpet', @Path='art/trumpet.png', @Categories= 'art,trumpet'
GO
EXEC SaveEmoji @Name='violin', @Path='art/violin.png', @Categories= 'art,violin'
GO
EXEC SaveEmoji @Name='antenna-bars', @Path='button/antenna-bars.png', @Categories= 'antenna,bars,button'
GO
EXEC SaveEmoji @Name='cinema', @Path='button/cinema.png', @Categories= 'button,cinema'
GO
EXEC SaveEmoji @Name='cool-button', @Path='button/cool-button.png', @Categories= 'button,cool'
GO
EXEC SaveEmoji @Name='downwards-button', @Path='button/downwards-button.png', @Categories= 'button,downwards'
GO
EXEC SaveEmoji @Name='eject-button', @Path='button/eject-button.png', @Categories= 'button,eject'
GO
EXEC SaveEmoji @Name='free-button', @Path='button/free-button.png', @Categories= 'button,free'
GO
EXEC SaveEmoji @Name='keycap-10', @Path='button/keycap-10.png', @Categories= '10,button,keycap'
GO
EXEC SaveEmoji @Name='keycap-asterisk', @Path='button/keycap-asterisk.png', @Categories= 'asterisk,button,keycap'
GO
EXEC SaveEmoji @Name='keycap-digit-eight', @Path='button/keycap-digit-eight.png', @Categories= 'button,digit,eight,keycap'
GO
EXEC SaveEmoji @Name='keycap-digit-five', @Path='button/keycap-digit-five.png', @Categories= 'button,digit,five,keycap'
GO
EXEC SaveEmoji @Name='keycap-digit-four', @Path='button/keycap-digit-four.png', @Categories= 'button,digit,four,keycap'
GO
EXEC SaveEmoji @Name='keycap-digit-nine', @Path='button/keycap-digit-nine.png', @Categories= 'button,digit,keycap,nine'
GO
EXEC SaveEmoji @Name='keycap-digit-one', @Path='button/keycap-digit-one.png', @Categories= 'button,digit,keycap,one'
GO
EXEC SaveEmoji @Name='keycap-digit-seven', @Path='button/keycap-digit-seven.png', @Categories= 'button,digit,keycap,seven'
GO
EXEC SaveEmoji @Name='keycap-digit-six', @Path='button/keycap-digit-six.png', @Categories= 'button,digit,keycap,six'
GO
EXEC SaveEmoji @Name='keycap-digit-three', @Path='button/keycap-digit-three.png', @Categories= 'button,digit,keycap,three'
GO
EXEC SaveEmoji @Name='keycap-digit-two', @Path='button/keycap-digit-two.png', @Categories= 'button,digit,keycap,two'
GO
EXEC SaveEmoji @Name='keycap-digit-zero', @Path='button/keycap-digit-zero.png', @Categories= 'button,digit,keycap,zero'
GO
EXEC SaveEmoji @Name='keycap-number-sign', @Path='button/keycap-number-sign.png', @Categories= 'button,keycap,number,sign'
GO
EXEC SaveEmoji @Name='last-track-button', @Path='button/last-track-button.png', @Categories= 'button,last,track'
GO
EXEC SaveEmoji @Name='new-button', @Path='button/new-button.png', @Categories= 'button,new'
GO
EXEC SaveEmoji @Name='next-track-button', @Path='button/next-track-button.png', @Categories= 'button,next,track'
GO
EXEC SaveEmoji @Name='ng-button', @Path='button/ng-button.png', @Categories= 'button,ng'
GO
EXEC SaveEmoji @Name='ok-button', @Path='button/ok-button.png', @Categories= 'button,ok'
GO
EXEC SaveEmoji @Name='pause-button', @Path='button/pause-button.png', @Categories= 'button,pause'
GO
EXEC SaveEmoji @Name='play-button', @Path='button/play-button.png', @Categories= 'button,play'
GO
EXEC SaveEmoji @Name='play-or-pause-button', @Path='button/play-or-pause-button.png', @Categories= 'button,or,pause,play'
GO
EXEC SaveEmoji @Name='radio-button', @Path='button/radio-button.png', @Categories= 'button,radio'
GO
EXEC SaveEmoji @Name='record-button', @Path='button/record-button.png', @Categories= 'button,record'
GO
EXEC SaveEmoji @Name='repeat-button', @Path='button/repeat-button.png', @Categories= 'button,repeat'
GO
EXEC SaveEmoji @Name='repeat-single-button', @Path='button/repeat-single-button.png', @Categories= 'button,repeat,single'
GO
EXEC SaveEmoji @Name='reverse-button', @Path='button/reverse-button.png', @Categories= 'button,reverse'
GO
EXEC SaveEmoji @Name='shuffle-tracks-button', @Path='button/shuffle-tracks-button.png', @Categories= 'button,shuffle,tracks'
GO
EXEC SaveEmoji @Name='stop-button', @Path='button/stop-button.png', @Categories= 'button,stop'
GO
EXEC SaveEmoji @Name='adhesive-bandage', @Path='clothes/adhesive-bandage.png', @Categories= 'adhesive,bandage,clothes'
GO
EXEC SaveEmoji @Name='backpack', @Path='clothes/backpack.png', @Categories= 'backpack,clothes'
GO
EXEC SaveEmoji @Name='bikini', @Path='clothes/bikini.png', @Categories= 'bikini,clothes'
GO
EXEC SaveEmoji @Name='billed-cap', @Path='clothes/billed-cap.png', @Categories= 'billed,cap,clothes'
GO
EXEC SaveEmoji @Name='briefcase', @Path='clothes/briefcase.png', @Categories= 'briefcase,clothes'
GO
EXEC SaveEmoji @Name='briefs', @Path='clothes/briefs.png', @Categories= 'briefs,clothes'
GO
EXEC SaveEmoji @Name='clutch-bag', @Path='clothes/clutch-bag.png', @Categories= 'bag,clothes,clutch'
GO
EXEC SaveEmoji @Name='coat', @Path='clothes/coat.png', @Categories= 'clothes,coat'
GO
EXEC SaveEmoji @Name='dress', @Path='clothes/dress.png', @Categories= 'clothes,dress'
GO
EXEC SaveEmoji @Name='flat-shoe', @Path='clothes/flat-shoe.png', @Categories= 'clothes,flat,shoe'
GO
EXEC SaveEmoji @Name='folding-hand-fan', @Path='clothes/folding-hand-fan.png', @Categories= 'clothes,fan,folding,hand'
GO
EXEC SaveEmoji @Name='glasses', @Path='clothes/glasses.png', @Categories= 'clothes,glasses'
GO
EXEC SaveEmoji @Name='gloves', @Path='clothes/gloves.png', @Categories= 'clothes,gloves'
GO
EXEC SaveEmoji @Name='graduation-cap', @Path='clothes/graduation-cap.png', @Categories= 'cap,clothes,graduation'
GO
EXEC SaveEmoji @Name='hair-pick', @Path='clothes/hair-pick.png', @Categories= 'clothes,hair,pick'
GO
EXEC SaveEmoji @Name='handbag', @Path='clothes/handbag.png', @Categories= 'clothes,handbag'
GO
EXEC SaveEmoji @Name='high-heeled-shoe', @Path='clothes/high-heeled-shoe.png', @Categories= 'clothes,heeled,high,shoe'
GO
EXEC SaveEmoji @Name='hiking-boot', @Path='clothes/hiking-boot.png', @Categories= 'boot,clothes,hiking'
GO
EXEC SaveEmoji @Name='jeans', @Path='clothes/jeans.png', @Categories= 'clothes,jeans'
GO
EXEC SaveEmoji @Name='kimono', @Path='clothes/kimono.png', @Categories= 'clothes,kimono'
GO
EXEC SaveEmoji @Name='lab-coat', @Path='clothes/lab-coat.png', @Categories= 'clothes,coat,lab'
GO
EXEC SaveEmoji @Name='lipstick', @Path='clothes/lipstick.png', @Categories= 'clothes,lipstick'
GO
EXEC SaveEmoji @Name='luggage', @Path='clothes/luggage.png', @Categories= 'clothes,luggage'
GO
EXEC SaveEmoji @Name='mans-shoe', @Path='clothes/mans-shoe.png', @Categories= 'clothes,mans,shoe'
GO
EXEC SaveEmoji @Name='military-helmet', @Path='clothes/military-helmet.png', @Categories= 'clothes,helmet,military'
GO
EXEC SaveEmoji @Name='necktie', @Path='clothes/necktie.png', @Categories= 'clothes,necktie'
GO
EXEC SaveEmoji @Name='one-piece-swimsuit', @Path='clothes/one-piece-swimsuit.png', @Categories= 'clothes,one,piece,swimsuit'
GO
EXEC SaveEmoji @Name='prayer-beads', @Path='clothes/prayer-beads.png', @Categories= 'beads,clothes,prayer'
GO
EXEC SaveEmoji @Name='purse', @Path='clothes/purse.png', @Categories= 'clothes,purse'
GO
EXEC SaveEmoji @Name='reminder-ribbon', @Path='clothes/reminder-ribbon.png', @Categories= 'clothes,reminder,ribbon'
GO
EXEC SaveEmoji @Name='rescue-workers-helmet', @Path='clothes/rescue-workers-helmet.png', @Categories= 'clothes,helmet,rescue,workers'
GO
EXEC SaveEmoji @Name='ribbon', @Path='clothes/ribbon.png', @Categories= 'clothes,ribbon'
GO
EXEC SaveEmoji @Name='ring', @Path='clothes/ring.png', @Categories= 'clothes,ring'
GO
EXEC SaveEmoji @Name='running-shirt', @Path='clothes/running-shirt.png', @Categories= 'clothes,running,shirt'
GO
EXEC SaveEmoji @Name='running-shoe', @Path='clothes/running-shoe.png', @Categories= 'clothes,running,shoe'
GO
EXEC SaveEmoji @Name='safety-vest', @Path='clothes/safety-vest.png', @Categories= 'clothes,safety,vest'
GO
EXEC SaveEmoji @Name='sari', @Path='clothes/sari.png', @Categories= 'clothes,sari'
GO
EXEC SaveEmoji @Name='scarf', @Path='clothes/scarf.png', @Categories= 'clothes,scarf'
GO
EXEC SaveEmoji @Name='shorts', @Path='clothes/shorts.png', @Categories= 'clothes,shorts'
GO
EXEC SaveEmoji @Name='socks', @Path='clothes/socks.png', @Categories= 'clothes,socks'
GO
EXEC SaveEmoji @Name='sports-medal', @Path='clothes/sports-medal.png', @Categories= 'clothes,medal,sports'
GO
EXEC SaveEmoji @Name='sunglasses', @Path='clothes/sunglasses.png', @Categories= 'clothes,sunglasses'
GO
EXEC SaveEmoji @Name='t-shirt', @Path='clothes/t-shirt.png', @Categories= 'clothes,shirt,t'
GO
EXEC SaveEmoji @Name='tent', @Path='clothes/tent.png', @Categories= 'clothes,tent'
GO
EXEC SaveEmoji @Name='thong-sandal', @Path='clothes/thong-sandal.png', @Categories= 'clothes,sandal,thong'
GO
EXEC SaveEmoji @Name='top-hat', @Path='clothes/top-hat.png', @Categories= 'clothes,hat,top'
GO
EXEC SaveEmoji @Name='womans-boot', @Path='clothes/womans-boot.png', @Categories= 'boot,clothes,womans'
GO
EXEC SaveEmoji @Name='womans-clothes', @Path='clothes/womans-clothes.png', @Categories= 'clothes,womans'
GO
EXEC SaveEmoji @Name='womans-hat', @Path='clothes/womans-hat.png', @Categories= 'clothes,hat,womans'
GO
EXEC SaveEmoji @Name='womans-sandal', @Path='clothes/womans-sandal.png', @Categories= 'clothes,sandal,womans'
GO
EXEC SaveEmoji @Name='alien', @Path='face/alien.png', @Categories= 'alien,face'
GO
EXEC SaveEmoji @Name='angry-face-with-horns', @Path='face/angry-face-with-horns.png', @Categories= 'angry,face,horns,with'
GO
EXEC SaveEmoji @Name='angry-face', @Path='face/angry-face.png', @Categories= 'angry,face'
GO
EXEC SaveEmoji @Name='anguished-face', @Path='face/anguished-face.png', @Categories= 'anguished,face'
GO
EXEC SaveEmoji @Name='anxious-face-with-sweat', @Path='face/anxious-face-with-sweat.png', @Categories= 'anxious,face,sweat,with'
GO
EXEC SaveEmoji @Name='astonished-face', @Path='face/astonished-face.png', @Categories= 'astonished,face'
GO
EXEC SaveEmoji @Name='baby-chick', @Path='face/baby-chick.png', @Categories= 'baby,chick,face'
GO
EXEC SaveEmoji @Name='beaming-face-with-smiling-eyes', @Path='face/beaming-face-with-smiling-eyes.png', @Categories= 'beaming,eyes,face,smiling,with'
GO
EXEC SaveEmoji @Name='bear', @Path='face/bear.png', @Categories= 'bear,face'
GO
EXEC SaveEmoji @Name='bird', @Path='face/bird.png', @Categories= 'bird,face'
GO
EXEC SaveEmoji @Name='biting-lip', @Path='face/biting-lip.png', @Categories= 'biting,face,lip'
GO
EXEC SaveEmoji @Name='cat-face', @Path='face/cat-face.png', @Categories= 'cat,face'
GO
EXEC SaveEmoji @Name='cat-with-tears-of-joy', @Path='face/cat-with-tears-of-joy.png', @Categories= 'cat,face,joy,of,tears,with'
GO
EXEC SaveEmoji @Name='cat-with-wry-smile', @Path='face/cat-with-wry-smile.png', @Categories= 'cat,face,smile,with,wry'
GO
EXEC SaveEmoji @Name='chicken', @Path='face/chicken.png', @Categories= 'chicken,face'
GO
EXEC SaveEmoji @Name='clown-face', @Path='face/clown-face.png', @Categories= 'clown,face'
GO
EXEC SaveEmoji @Name='cold-face', @Path='face/cold-face.png', @Categories= 'cold,face'
GO
EXEC SaveEmoji @Name='confounded-face', @Path='face/confounded-face.png', @Categories= 'confounded,face'
GO
EXEC SaveEmoji @Name='confused-face', @Path='face/confused-face.png', @Categories= 'confused,face'
GO
EXEC SaveEmoji @Name='cow-face', @Path='face/cow-face.png', @Categories= 'cow,face'
GO
EXEC SaveEmoji @Name='cowboy-hat-face', @Path='face/cowboy-hat-face.png', @Categories= 'cowboy,face,hat'
GO
EXEC SaveEmoji @Name='crying-cat', @Path='face/crying-cat.png', @Categories= 'cat,crying,face'
GO
EXEC SaveEmoji @Name='crying-face', @Path='face/crying-face.png', @Categories= 'crying,face'
GO
EXEC SaveEmoji @Name='disappointed-face', @Path='face/disappointed-face.png', @Categories= 'disappointed,face'
GO
EXEC SaveEmoji @Name='disguised-face', @Path='face/disguised-face.png', @Categories= 'disguised,face'
GO
EXEC SaveEmoji @Name='dizzy-face', @Path='face/dizzy-face.png', @Categories= 'dizzy,face'
GO
EXEC SaveEmoji @Name='dog-face', @Path='face/dog-face.png', @Categories= 'dog,face'
GO
EXEC SaveEmoji @Name='dotted-line-face', @Path='face/dotted-line-face.png', @Categories= 'dotted,face,line'
GO
EXEC SaveEmoji @Name='downcast-face-with-sweat', @Path='face/downcast-face-with-sweat.png', @Categories= 'downcast,face,sweat,with'
GO
EXEC SaveEmoji @Name='dragon-face', @Path='face/dragon-face.png', @Categories= 'dragon,face'
GO
EXEC SaveEmoji @Name='drooling-face', @Path='face/drooling-face.png', @Categories= 'drooling,face'
GO
EXEC SaveEmoji @Name='ear-with-hearing-aid', @Path='face/ear-with-hearing-aid.png', @Categories= 'aid,ear,face,hearing,with'
GO
EXEC SaveEmoji @Name='ear', @Path='face/ear.png', @Categories= 'ear,face'
GO
EXEC SaveEmoji @Name='exploding-head', @Path='face/exploding-head.png', @Categories= 'exploding,face,head'
GO
EXEC SaveEmoji @Name='expressionless-face', @Path='face/expressionless-face.png', @Categories= 'expressionless,face'
GO
EXEC SaveEmoji @Name='eye', @Path='face/eye.png', @Categories= 'eye,face'
GO
EXEC SaveEmoji @Name='eyes', @Path='face/eyes.png', @Categories= 'eyes,face'
GO
EXEC SaveEmoji @Name='face-blowing-a-kiss', @Path='face/face-blowing-a-kiss.png', @Categories= 'a,blowing,face,kiss'
GO
EXEC SaveEmoji @Name='face-exhaling', @Path='face/face-exhaling.png', @Categories= 'exhaling,face'
GO
EXEC SaveEmoji @Name='face-holding-back-tears', @Path='face/face-holding-back-tears.png', @Categories= 'back,face,holding,tears'
GO
EXEC SaveEmoji @Name='face-in-clouds', @Path='face/face-in-clouds.png', @Categories= 'clouds,face,in'
GO
EXEC SaveEmoji @Name='face-savoring-food', @Path='face/face-savoring-food.png', @Categories= 'face,food,savoring'
GO
EXEC SaveEmoji @Name='face-screaming-in-fear', @Path='face/face-screaming-in-fear.png', @Categories= 'face,fear,in,screaming'
GO
EXEC SaveEmoji @Name='face-vomiting', @Path='face/face-vomiting.png', @Categories= 'face,vomiting'
GO
EXEC SaveEmoji @Name='face-with-diagonal-mouth', @Path='face/face-with-diagonal-mouth.png', @Categories= 'diagonal,face,mouth,with'
GO
EXEC SaveEmoji @Name='face-with-hand-over-mouth', @Path='face/face-with-hand-over-mouth.png', @Categories= 'face,hand,mouth,over,with'
GO
EXEC SaveEmoji @Name='face-with-head-bandage', @Path='face/face-with-head-bandage.png', @Categories= 'bandage,face,head,with'
GO
EXEC SaveEmoji @Name='face-with-medical-mask', @Path='face/face-with-medical-mask.png', @Categories= 'face,mask,medical,with'
GO
EXEC SaveEmoji @Name='face-with-monocle', @Path='face/face-with-monocle.png', @Categories= 'face,monocle,with'
GO
EXEC SaveEmoji @Name='face-with-open-eyes-and-hand-over-mouth', @Path='face/face-with-open-eyes-and-hand-over-mouth.png', @Categories= 'and,eyes,face,hand,mouth,open,over,with'
GO
EXEC SaveEmoji @Name='face-with-open-mouth', @Path='face/face-with-open-mouth.png', @Categories= 'face,mouth,open,with'
GO
EXEC SaveEmoji @Name='face-with-peeking-eye', @Path='face/face-with-peeking-eye.png', @Categories= 'eye,face,peeking,with'
GO
EXEC SaveEmoji @Name='face-with-raised-eyebrow', @Path='face/face-with-raised-eyebrow.png', @Categories= 'eyebrow,face,raised,with'
GO
EXEC SaveEmoji @Name='face-with-rolling-eyes', @Path='face/face-with-rolling-eyes.png', @Categories= 'eyes,face,rolling,with'
GO
EXEC SaveEmoji @Name='face-with-spiral-eyes', @Path='face/face-with-spiral-eyes.png', @Categories= 'eyes,face,spiral,with'
GO
EXEC SaveEmoji @Name='face-with-steam-from-nose', @Path='face/face-with-steam-from-nose.png', @Categories= 'face,from,nose,steam,with'
GO
EXEC SaveEmoji @Name='face-with-symbols-on-mouth', @Path='face/face-with-symbols-on-mouth.png', @Categories= 'face,mouth,on,symbols,with'
GO
EXEC SaveEmoji @Name='face-with-tears-of-joy', @Path='face/face-with-tears-of-joy.png', @Categories= 'face,joy,of,tears,with'
GO
EXEC SaveEmoji @Name='face-with-thermometer', @Path='face/face-with-thermometer.png', @Categories= 'face,thermometer,with'
GO
EXEC SaveEmoji @Name='face-with-tongue', @Path='face/face-with-tongue.png', @Categories= 'face,tongue,with'
GO
EXEC SaveEmoji @Name='face-without-mouth', @Path='face/face-without-mouth.png', @Categories= 'face,mouth,without'
GO
EXEC SaveEmoji @Name='fearful-face', @Path='face/fearful-face.png', @Categories= 'face,fearful'
GO
EXEC SaveEmoji @Name='first-quarter-moon-face', @Path='face/first-quarter-moon-face.png', @Categories= 'face,first,moon,quarter'
GO
EXEC SaveEmoji @Name='flushed-face', @Path='face/flushed-face.png', @Categories= 'face,flushed'
GO
EXEC SaveEmoji @Name='fox', @Path='face/fox.png', @Categories= 'face,fox'
GO
EXEC SaveEmoji @Name='frog', @Path='face/frog.png', @Categories= 'face,frog'
GO
EXEC SaveEmoji @Name='frowning-face-with-open-mouth', @Path='face/frowning-face-with-open-mouth.png', @Categories= 'face,frowning,mouth,open,with'
GO
EXEC SaveEmoji @Name='frowning-face', @Path='face/frowning-face.png', @Categories= 'face,frowning'
GO
EXEC SaveEmoji @Name='full-moon-face', @Path='face/full-moon-face.png', @Categories= 'face,full,moon'
GO
EXEC SaveEmoji @Name='ghost', @Path='face/ghost.png', @Categories= 'face,ghost'
GO
EXEC SaveEmoji @Name='goblin', @Path='face/goblin.png', @Categories= 'face,goblin'
GO
EXEC SaveEmoji @Name='grimacing-face', @Path='face/grimacing-face.png', @Categories= 'face,grimacing'
GO
EXEC SaveEmoji @Name='grinning-cat-with-smiling-eyes', @Path='face/grinning-cat-with-smiling-eyes.png', @Categories= 'cat,eyes,face,grinning,smiling,with'
GO
EXEC SaveEmoji @Name='grinning-cat', @Path='face/grinning-cat.png', @Categories= 'cat,face,grinning'
GO
EXEC SaveEmoji @Name='grinning-face-with-big-eyes', @Path='face/grinning-face-with-big-eyes.png', @Categories= 'big,eyes,face,grinning,with'
GO
EXEC SaveEmoji @Name='grinning-face-with-smiling-eyes', @Path='face/grinning-face-with-smiling-eyes.png', @Categories= 'eyes,face,grinning,smiling,with'
GO
EXEC SaveEmoji @Name='grinning-face-with-sweat', @Path='face/grinning-face-with-sweat.png', @Categories= 'face,grinning,sweat,with'
GO
EXEC SaveEmoji @Name='grinning-face', @Path='face/grinning-face.png', @Categories= 'face,grinning'
GO
EXEC SaveEmoji @Name='grinning-squinting-face', @Path='face/grinning-squinting-face.png', @Categories= 'face,grinning,squinting'
GO
EXEC SaveEmoji @Name='hamster', @Path='face/hamster.png', @Categories= 'face,hamster'
GO
EXEC SaveEmoji @Name='hear-no-evil-monkey', @Path='face/hear-no-evil-monkey.png', @Categories= 'evil,face,hear,monkey,no'
GO
EXEC SaveEmoji @Name='horse-face', @Path='face/horse-face.png', @Categories= 'face,horse'
GO
EXEC SaveEmoji @Name='hot-face', @Path='face/hot-face.png', @Categories= 'face,hot'
GO
EXEC SaveEmoji @Name='hugging-face', @Path='face/hugging-face.png', @Categories= 'face,hugging'
GO
EXEC SaveEmoji @Name='hushed-face', @Path='face/hushed-face.png', @Categories= 'face,hushed'
GO
EXEC SaveEmoji @Name='kissing-cat', @Path='face/kissing-cat.png', @Categories= 'cat,face,kissing'
GO
EXEC SaveEmoji @Name='kissing-face-with-closed-eyes', @Path='face/kissing-face-with-closed-eyes.png', @Categories= 'closed,eyes,face,kissing,with'
GO
EXEC SaveEmoji @Name='kissing-face-with-smiling-eyes', @Path='face/kissing-face-with-smiling-eyes.png', @Categories= 'eyes,face,kissing,smiling,with'
GO
EXEC SaveEmoji @Name='kissing-face', @Path='face/kissing-face.png', @Categories= 'face,kissing'
GO
EXEC SaveEmoji @Name='koala', @Path='face/koala.png', @Categories= 'face,koala'
GO
EXEC SaveEmoji @Name='last-quarter-moon-face', @Path='face/last-quarter-moon-face.png', @Categories= 'face,last,moon,quarter'
GO
EXEC SaveEmoji @Name='lion', @Path='face/lion.png', @Categories= 'face,lion'
GO
EXEC SaveEmoji @Name='loudly-crying-face', @Path='face/loudly-crying-face.png', @Categories= 'crying,face,loudly'
GO
EXEC SaveEmoji @Name='lying-face', @Path='face/lying-face.png', @Categories= 'face,lying'
GO
EXEC SaveEmoji @Name='melting-face', @Path='face/melting-face.png', @Categories= 'face,melting'
GO
EXEC SaveEmoji @Name='money-mouth-face', @Path='face/money-mouth-face.png', @Categories= 'face,money,mouth'
GO
EXEC SaveEmoji @Name='monkey-face', @Path='face/monkey-face.png', @Categories= 'face,monkey'
GO
EXEC SaveEmoji @Name='moose', @Path='face/moose.png', @Categories= 'face,moose'
GO
EXEC SaveEmoji @Name='mouse-face', @Path='face/mouse-face.png', @Categories= 'face,mouse'
GO
EXEC SaveEmoji @Name='mouth', @Path='face/mouth.png', @Categories= 'face,mouth'
GO
EXEC SaveEmoji @Name='nauseated-face', @Path='face/nauseated-face.png', @Categories= 'face,nauseated'
GO
EXEC SaveEmoji @Name='nerd-face', @Path='face/nerd-face.png', @Categories= 'face,nerd'
GO
EXEC SaveEmoji @Name='neutral-face', @Path='face/neutral-face.png', @Categories= 'face,neutral'
GO
EXEC SaveEmoji @Name='new-moon-face', @Path='face/new-moon-face.png', @Categories= 'face,moon,new'
GO
EXEC SaveEmoji @Name='nose', @Path='face/nose.png', @Categories= 'face,nose'
GO
EXEC SaveEmoji @Name='ogre', @Path='face/ogre.png', @Categories= 'face,ogre'
GO
EXEC SaveEmoji @Name='partying-face', @Path='face/partying-face.png', @Categories= 'face,partying'
GO
EXEC SaveEmoji @Name='pensive-face', @Path='face/pensive-face.png', @Categories= 'face,pensive'
GO
EXEC SaveEmoji @Name='persevering-face', @Path='face/persevering-face.png', @Categories= 'face,persevering'
GO
EXEC SaveEmoji @Name='pig-face', @Path='face/pig-face.png', @Categories= 'face,pig'
GO
EXEC SaveEmoji @Name='pig-nose', @Path='face/pig-nose.png', @Categories= 'face,nose,pig'
GO
EXEC SaveEmoji @Name='pile-of-poo', @Path='face/pile-of-poo.png', @Categories= 'face,of,pile,poo'
GO
EXEC SaveEmoji @Name='pleading-face', @Path='face/pleading-face.png', @Categories= 'face,pleading'
GO
EXEC SaveEmoji @Name='polar-bear', @Path='face/polar-bear.png', @Categories= 'bear,face,polar'
GO
EXEC SaveEmoji @Name='pouting-cat', @Path='face/pouting-cat.png', @Categories= 'cat,face,pouting'
GO
EXEC SaveEmoji @Name='pouting-face', @Path='face/pouting-face.png', @Categories= 'face,pouting'
GO
EXEC SaveEmoji @Name='rabbit-face', @Path='face/rabbit-face.png', @Categories= 'face,rabbit'
GO
EXEC SaveEmoji @Name='relieved-face', @Path='face/relieved-face.png', @Categories= 'face,relieved'
GO
EXEC SaveEmoji @Name='robot', @Path='face/robot.png', @Categories= 'face,robot'
GO
EXEC SaveEmoji @Name='rolling-on-the-floor-laughing', @Path='face/rolling-on-the-floor-laughing.png', @Categories= 'face,floor,laughing,on,rolling,the'
GO
EXEC SaveEmoji @Name='sad-but-relieved-face', @Path='face/sad-but-relieved-face.png', @Categories= 'but,face,relieved,sad'
GO
EXEC SaveEmoji @Name='saluting-face', @Path='face/saluting-face.png', @Categories= 'face,saluting'
GO
EXEC SaveEmoji @Name='see-no-evil-monkey', @Path='face/see-no-evil-monkey.png', @Categories= 'evil,face,monkey,no,see'
GO
EXEC SaveEmoji @Name='shaking-face', @Path='face/shaking-face.png', @Categories= 'face,shaking'
GO
EXEC SaveEmoji @Name='shushing-face', @Path='face/shushing-face.png', @Categories= 'face,shushing'
GO
EXEC SaveEmoji @Name='skull-and-crossbones', @Path='face/skull-and-crossbones.png', @Categories= 'and,crossbones,face,skull'
GO
EXEC SaveEmoji @Name='skull', @Path='face/skull.png', @Categories= 'face,skull'
GO
EXEC SaveEmoji @Name='sleeping-face', @Path='face/sleeping-face.png', @Categories= 'face,sleeping'
GO
EXEC SaveEmoji @Name='sleepy-face', @Path='face/sleepy-face.png', @Categories= 'face,sleepy'
GO
EXEC SaveEmoji @Name='slightly-frowning-face', @Path='face/slightly-frowning-face.png', @Categories= 'face,frowning,slightly'
GO
EXEC SaveEmoji @Name='slightly-smiling-face', @Path='face/slightly-smiling-face.png', @Categories= 'face,slightly,smiling'
GO
EXEC SaveEmoji @Name='smiling-cat-with-heart-eyes', @Path='face/smiling-cat-with-heart-eyes.png', @Categories= 'cat,eyes,face,heart,smiling,with'
GO
EXEC SaveEmoji @Name='smiling-face-with-halo', @Path='face/smiling-face-with-halo.png', @Categories= 'face,halo,smiling,with'
GO
EXEC SaveEmoji @Name='smiling-face-with-heart-eyes', @Path='face/smiling-face-with-heart-eyes.png', @Categories= 'eyes,face,heart,smiling,with'
GO
EXEC SaveEmoji @Name='smiling-face-with-hearts', @Path='face/smiling-face-with-hearts.png', @Categories= 'face,hearts,smiling,with'
GO
EXEC SaveEmoji @Name='smiling-face-with-horns', @Path='face/smiling-face-with-horns.png', @Categories= 'face,horns,smiling,with'
GO
EXEC SaveEmoji @Name='smiling-face-with-smiling-eyes', @Path='face/smiling-face-with-smiling-eyes.png', @Categories= 'eyes,face,smiling,with'
GO
EXEC SaveEmoji @Name='smiling-face-with-sunglasses', @Path='face/smiling-face-with-sunglasses.png', @Categories= 'face,smiling,sunglasses,with'
GO
EXEC SaveEmoji @Name='smiling-face-with-tear', @Path='face/smiling-face-with-tear.png', @Categories= 'face,smiling,tear,with'
GO
EXEC SaveEmoji @Name='smiling-face', @Path='face/smiling-face.png', @Categories= 'face,smiling'
GO
EXEC SaveEmoji @Name='smirking-face', @Path='face/smirking-face.png', @Categories= 'face,smirking'
GO
EXEC SaveEmoji @Name='sneezing-face', @Path='face/sneezing-face.png', @Categories= 'face,sneezing'
GO
EXEC SaveEmoji @Name='speak-no-evil-monkey', @Path='face/speak-no-evil-monkey.png', @Categories= 'evil,face,monkey,no,speak'
GO
EXEC SaveEmoji @Name='squinting-face-with-tongue', @Path='face/squinting-face-with-tongue.png', @Categories= 'face,squinting,tongue,with'
GO
EXEC SaveEmoji @Name='star-struck', @Path='face/star-struck.png', @Categories= 'face,star,struck'
GO
EXEC SaveEmoji @Name='sun-with-face', @Path='face/sun-with-face.png', @Categories= 'face,sun,with'
GO
EXEC SaveEmoji @Name='thinking-face', @Path='face/thinking-face.png', @Categories= 'face,thinking'
GO
EXEC SaveEmoji @Name='tiger-face', @Path='face/tiger-face.png', @Categories= 'face,tiger'
GO
EXEC SaveEmoji @Name='tired-face', @Path='face/tired-face.png', @Categories= 'face,tired'
GO
EXEC SaveEmoji @Name='tongue', @Path='face/tongue.png', @Categories= 'face,tongue'
GO
EXEC SaveEmoji @Name='unamused-face', @Path='face/unamused-face.png', @Categories= 'face,unamused'
GO
EXEC SaveEmoji @Name='unicorn', @Path='face/unicorn.png', @Categories= 'face,unicorn'
GO
EXEC SaveEmoji @Name='upside-down-face', @Path='face/upside-down-face.png', @Categories= 'down,face,upside'
GO
EXEC SaveEmoji @Name='weary-cat', @Path='face/weary-cat.png', @Categories= 'cat,face,weary'
GO
EXEC SaveEmoji @Name='weary-face', @Path='face/weary-face.png', @Categories= 'face,weary'
GO
EXEC SaveEmoji @Name='winking-face-with-tongue', @Path='face/winking-face-with-tongue.png', @Categories= 'face,tongue,winking,with'
GO
EXEC SaveEmoji @Name='winking-face', @Path='face/winking-face.png', @Categories= 'face,winking'
GO
EXEC SaveEmoji @Name='woozy-face', @Path='face/woozy-face.png', @Categories= 'face,woozy'
GO
EXEC SaveEmoji @Name='worried-face', @Path='face/worried-face.png', @Categories= 'face,worried'
GO
EXEC SaveEmoji @Name='yawning-face', @Path='face/yawning-face.png', @Categories= 'face,yawning'
GO
EXEC SaveEmoji @Name='zany-face', @Path='face/zany-face.png', @Categories= 'face,zany'
GO
EXEC SaveEmoji @Name='zipper-mouth-face', @Path='face/zipper-mouth-face.png', @Categories= 'face,mouth,zipper'
GO
EXEC SaveEmoji @Name='black-flag', @Path='flag/black-flag.png', @Categories= 'black,flag'
GO
EXEC SaveEmoji @Name='carp-streamer', @Path='flag/carp-streamer.png', @Categories= 'carp,flag,streamer'
GO
EXEC SaveEmoji @Name='chequered-flag', @Path='flag/chequered-flag.png', @Categories= 'chequered,flag'
GO
EXEC SaveEmoji @Name='crossed-flags', @Path='flag/crossed-flags.png', @Categories= 'crossed,flag,flags'
GO
EXEC SaveEmoji @Name='flag-afghanistan', @Path='flag/flag-afghanistan.png', @Categories= 'afghanistan,flag'
GO
EXEC SaveEmoji @Name='flag-aland-islands', @Path='flag/flag-aland-islands.png', @Categories= 'aland,flag,islands'
GO
EXEC SaveEmoji @Name='flag-albania', @Path='flag/flag-albania.png', @Categories= 'albania,flag'
GO
EXEC SaveEmoji @Name='flag-algeria', @Path='flag/flag-algeria.png', @Categories= 'algeria,flag'
GO
EXEC SaveEmoji @Name='flag-american-samoa', @Path='flag/flag-american-samoa.png', @Categories= 'american,flag,samoa'
GO
EXEC SaveEmoji @Name='flag-andorra', @Path='flag/flag-andorra.png', @Categories= 'andorra,flag'
GO
EXEC SaveEmoji @Name='flag-angola', @Path='flag/flag-angola.png', @Categories= 'angola,flag'
GO
EXEC SaveEmoji @Name='flag-anguilla', @Path='flag/flag-anguilla.png', @Categories= 'anguilla,flag'
GO
EXEC SaveEmoji @Name='flag-antarctica', @Path='flag/flag-antarctica.png', @Categories= 'antarctica,flag'
GO
EXEC SaveEmoji @Name='flag-antigua-barbuda', @Path='flag/flag-antigua-barbuda.png', @Categories= 'antigua,barbuda,flag'
GO
EXEC SaveEmoji @Name='flag-argentina', @Path='flag/flag-argentina.png', @Categories= 'argentina,flag'
GO
EXEC SaveEmoji @Name='flag-armenia', @Path='flag/flag-armenia.png', @Categories= 'armenia,flag'
GO
EXEC SaveEmoji @Name='flag-aruba', @Path='flag/flag-aruba.png', @Categories= 'aruba,flag'
GO
EXEC SaveEmoji @Name='flag-ascension-island', @Path='flag/flag-ascension-island.png', @Categories= 'ascension,flag,island'
GO
EXEC SaveEmoji @Name='flag-australia', @Path='flag/flag-australia.png', @Categories= 'australia,flag'
GO
EXEC SaveEmoji @Name='flag-austria', @Path='flag/flag-austria.png', @Categories= 'austria,flag'
GO
EXEC SaveEmoji @Name='flag-azerbaijan', @Path='flag/flag-azerbaijan.png', @Categories= 'azerbaijan,flag'
GO
EXEC SaveEmoji @Name='flag-bahamas', @Path='flag/flag-bahamas.png', @Categories= 'bahamas,flag'
GO
EXEC SaveEmoji @Name='flag-bahrain', @Path='flag/flag-bahrain.png', @Categories= 'bahrain,flag'
GO
EXEC SaveEmoji @Name='flag-bangladesh', @Path='flag/flag-bangladesh.png', @Categories= 'bangladesh,flag'
GO
EXEC SaveEmoji @Name='flag-barbados', @Path='flag/flag-barbados.png', @Categories= 'barbados,flag'
GO
EXEC SaveEmoji @Name='flag-belarus', @Path='flag/flag-belarus.png', @Categories= 'belarus,flag'
GO
EXEC SaveEmoji @Name='flag-belgium', @Path='flag/flag-belgium.png', @Categories= 'belgium,flag'
GO
EXEC SaveEmoji @Name='flag-belize', @Path='flag/flag-belize.png', @Categories= 'belize,flag'
GO
EXEC SaveEmoji @Name='flag-benin', @Path='flag/flag-benin.png', @Categories= 'benin,flag'
GO
EXEC SaveEmoji @Name='flag-bermuda', @Path='flag/flag-bermuda.png', @Categories= 'bermuda,flag'
GO
EXEC SaveEmoji @Name='flag-bhutan', @Path='flag/flag-bhutan.png', @Categories= 'bhutan,flag'
GO
EXEC SaveEmoji @Name='flag-bolivia', @Path='flag/flag-bolivia.png', @Categories= 'bolivia,flag'
GO
EXEC SaveEmoji @Name='flag-bosnia-herzegovina', @Path='flag/flag-bosnia-herzegovina.png', @Categories= 'bosnia,flag,herzegovina'
GO
EXEC SaveEmoji @Name='flag-botswana', @Path='flag/flag-botswana.png', @Categories= 'botswana,flag'
GO
EXEC SaveEmoji @Name='flag-bouvet-island', @Path='flag/flag-bouvet-island.png', @Categories= 'bouvet,flag,island'
GO
EXEC SaveEmoji @Name='flag-brazil', @Path='flag/flag-brazil.png', @Categories= 'brazil,flag'
GO
EXEC SaveEmoji @Name='flag-british-indian-ocean-territory', @Path='flag/flag-british-indian-ocean-territory.png', @Categories= 'british,flag,indian,ocean,territory'
GO
EXEC SaveEmoji @Name='flag-british-virgin-islands', @Path='flag/flag-british-virgin-islands.png', @Categories= 'british,flag,islands,virgin'
GO
EXEC SaveEmoji @Name='flag-brunei', @Path='flag/flag-brunei.png', @Categories= 'brunei,flag'
GO
EXEC SaveEmoji @Name='flag-bulgaria', @Path='flag/flag-bulgaria.png', @Categories= 'bulgaria,flag'
GO
EXEC SaveEmoji @Name='flag-burkina-faso', @Path='flag/flag-burkina-faso.png', @Categories= 'burkina,faso,flag'
GO
EXEC SaveEmoji @Name='flag-burundi', @Path='flag/flag-burundi.png', @Categories= 'burundi,flag'
GO
EXEC SaveEmoji @Name='flag-cambodia', @Path='flag/flag-cambodia.png', @Categories= 'cambodia,flag'
GO
EXEC SaveEmoji @Name='flag-cameroon', @Path='flag/flag-cameroon.png', @Categories= 'cameroon,flag'
GO
EXEC SaveEmoji @Name='flag-canada', @Path='flag/flag-canada.png', @Categories= 'canada,flag'
GO
EXEC SaveEmoji @Name='flag-canary-islands', @Path='flag/flag-canary-islands.png', @Categories= 'canary,flag,islands'
GO
EXEC SaveEmoji @Name='flag-cape-verde', @Path='flag/flag-cape-verde.png', @Categories= 'cape,flag,verde'
GO
EXEC SaveEmoji @Name='flag-caribbean-netherlands', @Path='flag/flag-caribbean-netherlands.png', @Categories= 'caribbean,flag,netherlands'
GO
EXEC SaveEmoji @Name='flag-cayman-islands', @Path='flag/flag-cayman-islands.png', @Categories= 'cayman,flag,islands'
GO
EXEC SaveEmoji @Name='flag-central-african-republic', @Path='flag/flag-central-african-republic.png', @Categories= 'african,central,flag,republic'
GO
EXEC SaveEmoji @Name='flag-ceuta-melilla', @Path='flag/flag-ceuta-melilla.png', @Categories= 'ceuta,flag,melilla'
GO
EXEC SaveEmoji @Name='flag-chad', @Path='flag/flag-chad.png', @Categories= 'chad,flag'
GO
EXEC SaveEmoji @Name='flag-chile', @Path='flag/flag-chile.png', @Categories= 'chile,flag'
GO
EXEC SaveEmoji @Name='flag-china', @Path='flag/flag-china.png', @Categories= 'china,flag'
GO
EXEC SaveEmoji @Name='flag-christmas-island', @Path='flag/flag-christmas-island.png', @Categories= 'christmas,flag,island'
GO
EXEC SaveEmoji @Name='flag-clipperton-island', @Path='flag/flag-clipperton-island.png', @Categories= 'clipperton,flag,island'
GO
EXEC SaveEmoji @Name='flag-cocos-keeling-islands', @Path='flag/flag-cocos-keeling-islands.png', @Categories= 'cocos,flag,islands,keeling'
GO
EXEC SaveEmoji @Name='flag-colombia', @Path='flag/flag-colombia.png', @Categories= 'colombia,flag'
GO
EXEC SaveEmoji @Name='flag-comoros', @Path='flag/flag-comoros.png', @Categories= 'comoros,flag'
GO
EXEC SaveEmoji @Name='flag-congo-brazzaville', @Path='flag/flag-congo-brazzaville.png', @Categories= 'brazzaville,congo,flag'
GO
EXEC SaveEmoji @Name='flag-congo-kinshasa', @Path='flag/flag-congo-kinshasa.png', @Categories= 'congo,flag,kinshasa'
GO
EXEC SaveEmoji @Name='flag-cook-islands', @Path='flag/flag-cook-islands.png', @Categories= 'cook,flag,islands'
GO
EXEC SaveEmoji @Name='flag-costa-rica', @Path='flag/flag-costa-rica.png', @Categories= 'costa,flag,rica'
GO
EXEC SaveEmoji @Name='flag-cote-divoire', @Path='flag/flag-cote-divoire.png', @Categories= 'cote,divoire,flag'
GO
EXEC SaveEmoji @Name='flag-croatia', @Path='flag/flag-croatia.png', @Categories= 'croatia,flag'
GO
EXEC SaveEmoji @Name='flag-cuba', @Path='flag/flag-cuba.png', @Categories= 'cuba,flag'
GO
EXEC SaveEmoji @Name='flag-curacao', @Path='flag/flag-curacao.png', @Categories= 'curacao,flag'
GO
EXEC SaveEmoji @Name='flag-cyprus', @Path='flag/flag-cyprus.png', @Categories= 'cyprus,flag'
GO
EXEC SaveEmoji @Name='flag-czechia', @Path='flag/flag-czechia.png', @Categories= 'czechia,flag'
GO
EXEC SaveEmoji @Name='flag-denmark', @Path='flag/flag-denmark.png', @Categories= 'denmark,flag'
GO
EXEC SaveEmoji @Name='flag-diego-garcia', @Path='flag/flag-diego-garcia.png', @Categories= 'diego,flag,garcia'
GO
EXEC SaveEmoji @Name='flag-djibouti', @Path='flag/flag-djibouti.png', @Categories= 'djibouti,flag'
GO
EXEC SaveEmoji @Name='flag-dominica', @Path='flag/flag-dominica.png', @Categories= 'dominica,flag'
GO
EXEC SaveEmoji @Name='flag-dominican-republic', @Path='flag/flag-dominican-republic.png', @Categories= 'dominican,flag,republic'
GO
EXEC SaveEmoji @Name='flag-ecuador', @Path='flag/flag-ecuador.png', @Categories= 'ecuador,flag'
GO
EXEC SaveEmoji @Name='flag-egypt', @Path='flag/flag-egypt.png', @Categories= 'egypt,flag'
GO
EXEC SaveEmoji @Name='flag-el-salvador', @Path='flag/flag-el-salvador.png', @Categories= 'el,flag,salvador'
GO
EXEC SaveEmoji @Name='flag-england', @Path='flag/flag-england.png', @Categories= 'england,flag'
GO
EXEC SaveEmoji @Name='flag-equatorial-guinea', @Path='flag/flag-equatorial-guinea.png', @Categories= 'equatorial,flag,guinea'
GO
EXEC SaveEmoji @Name='flag-eritrea', @Path='flag/flag-eritrea.png', @Categories= 'eritrea,flag'
GO
EXEC SaveEmoji @Name='flag-estonia', @Path='flag/flag-estonia.png', @Categories= 'estonia,flag'
GO
EXEC SaveEmoji @Name='flag-eswatini', @Path='flag/flag-eswatini.png', @Categories= 'eswatini,flag'
GO
EXEC SaveEmoji @Name='flag-ethiopia', @Path='flag/flag-ethiopia.png', @Categories= 'ethiopia,flag'
GO
EXEC SaveEmoji @Name='flag-european-union', @Path='flag/flag-european-union.png', @Categories= 'european,flag,union'
GO
EXEC SaveEmoji @Name='flag-falkland-islands', @Path='flag/flag-falkland-islands.png', @Categories= 'falkland,flag,islands'
GO
EXEC SaveEmoji @Name='flag-faroe-islands', @Path='flag/flag-faroe-islands.png', @Categories= 'faroe,flag,islands'
GO
EXEC SaveEmoji @Name='flag-fiji', @Path='flag/flag-fiji.png', @Categories= 'fiji,flag'
GO
EXEC SaveEmoji @Name='flag-finland', @Path='flag/flag-finland.png', @Categories= 'finland,flag'
GO
EXEC SaveEmoji @Name='flag-france', @Path='flag/flag-france.png', @Categories= 'flag,france'
GO
EXEC SaveEmoji @Name='flag-french-guiana', @Path='flag/flag-french-guiana.png', @Categories= 'flag,french,guiana'
GO
EXEC SaveEmoji @Name='flag-french-polynesia', @Path='flag/flag-french-polynesia.png', @Categories= 'flag,french,polynesia'
GO
EXEC SaveEmoji @Name='flag-french-southern-territories', @Path='flag/flag-french-southern-territories.png', @Categories= 'flag,french,southern,territories'
GO
EXEC SaveEmoji @Name='flag-gabon', @Path='flag/flag-gabon.png', @Categories= 'flag,gabon'
GO
EXEC SaveEmoji @Name='flag-gambia', @Path='flag/flag-gambia.png', @Categories= 'flag,gambia'
GO
EXEC SaveEmoji @Name='flag-georgia', @Path='flag/flag-georgia.png', @Categories= 'flag,georgia'
GO
EXEC SaveEmoji @Name='flag-germany', @Path='flag/flag-germany.png', @Categories= 'flag,germany'
GO
EXEC SaveEmoji @Name='flag-ghana', @Path='flag/flag-ghana.png', @Categories= 'flag,ghana'
GO
EXEC SaveEmoji @Name='flag-gibraltar', @Path='flag/flag-gibraltar.png', @Categories= 'flag,gibraltar'
GO
EXEC SaveEmoji @Name='flag-greece', @Path='flag/flag-greece.png', @Categories= 'flag,greece'
GO
EXEC SaveEmoji @Name='flag-greenland', @Path='flag/flag-greenland.png', @Categories= 'flag,greenland'
GO
EXEC SaveEmoji @Name='flag-grenada', @Path='flag/flag-grenada.png', @Categories= 'flag,grenada'
GO
EXEC SaveEmoji @Name='flag-guadeloupe', @Path='flag/flag-guadeloupe.png', @Categories= 'flag,guadeloupe'
GO
EXEC SaveEmoji @Name='flag-guam', @Path='flag/flag-guam.png', @Categories= 'flag,guam'
GO
EXEC SaveEmoji @Name='flag-guatemala', @Path='flag/flag-guatemala.png', @Categories= 'flag,guatemala'
GO
EXEC SaveEmoji @Name='flag-guernsey', @Path='flag/flag-guernsey.png', @Categories= 'flag,guernsey'
GO
EXEC SaveEmoji @Name='flag-guinea-bissau', @Path='flag/flag-guinea-bissau.png', @Categories= 'bissau,flag,guinea'
GO
EXEC SaveEmoji @Name='flag-guinea', @Path='flag/flag-guinea.png', @Categories= 'flag,guinea'
GO
EXEC SaveEmoji @Name='flag-guyana', @Path='flag/flag-guyana.png', @Categories= 'flag,guyana'
GO
EXEC SaveEmoji @Name='flag-haiti', @Path='flag/flag-haiti.png', @Categories= 'flag,haiti'
GO
EXEC SaveEmoji @Name='flag-heard-mcdonald-islands', @Path='flag/flag-heard-mcdonald-islands.png', @Categories= 'flag,heard,islands,mcdonald'
GO
EXEC SaveEmoji @Name='flag-honduras', @Path='flag/flag-honduras.png', @Categories= 'flag,honduras'
GO
EXEC SaveEmoji @Name='flag-hong-kong-sar-china', @Path='flag/flag-hong-kong-sar-china.png', @Categories= 'china,flag,hong,kong,sar'
GO
EXEC SaveEmoji @Name='flag-hungary', @Path='flag/flag-hungary.png', @Categories= 'flag,hungary'
GO
EXEC SaveEmoji @Name='flag-iceland', @Path='flag/flag-iceland.png', @Categories= 'flag,iceland'
GO
EXEC SaveEmoji @Name='flag-in-hole', @Path='flag/flag-in-hole.png', @Categories= 'flag,hole,in'
GO
EXEC SaveEmoji @Name='flag-india', @Path='flag/flag-india.png', @Categories= 'flag,india'
GO
EXEC SaveEmoji @Name='flag-indonesia', @Path='flag/flag-indonesia.png', @Categories= 'flag,indonesia'
GO
EXEC SaveEmoji @Name='flag-iran', @Path='flag/flag-iran.png', @Categories= 'flag,iran'
GO
EXEC SaveEmoji @Name='flag-iraq', @Path='flag/flag-iraq.png', @Categories= 'flag,iraq'
GO
EXEC SaveEmoji @Name='flag-ireland', @Path='flag/flag-ireland.png', @Categories= 'flag,ireland'
GO
EXEC SaveEmoji @Name='flag-isle-of-man', @Path='flag/flag-isle-of-man.png', @Categories= 'flag,isle,man,of'
GO
EXEC SaveEmoji @Name='flag-israel', @Path='flag/flag-israel.png', @Categories= 'flag,israel'
GO
EXEC SaveEmoji @Name='flag-italy', @Path='flag/flag-italy.png', @Categories= 'flag,italy'
GO
EXEC SaveEmoji @Name='flag-jamaica', @Path='flag/flag-jamaica.png', @Categories= 'flag,jamaica'
GO
EXEC SaveEmoji @Name='flag-japan', @Path='flag/flag-japan.png', @Categories= 'flag,japan'
GO
EXEC SaveEmoji @Name='flag-jersey', @Path='flag/flag-jersey.png', @Categories= 'flag,jersey'
GO
EXEC SaveEmoji @Name='flag-jordan', @Path='flag/flag-jordan.png', @Categories= 'flag,jordan'
GO
EXEC SaveEmoji @Name='flag-kazakhstan', @Path='flag/flag-kazakhstan.png', @Categories= 'flag,kazakhstan'
GO
EXEC SaveEmoji @Name='flag-kenya', @Path='flag/flag-kenya.png', @Categories= 'flag,kenya'
GO
EXEC SaveEmoji @Name='flag-kiribati', @Path='flag/flag-kiribati.png', @Categories= 'flag,kiribati'
GO
EXEC SaveEmoji @Name='flag-kosovo', @Path='flag/flag-kosovo.png', @Categories= 'flag,kosovo'
GO
EXEC SaveEmoji @Name='flag-kuwait', @Path='flag/flag-kuwait.png', @Categories= 'flag,kuwait'
GO
EXEC SaveEmoji @Name='flag-kyrgyzstan', @Path='flag/flag-kyrgyzstan.png', @Categories= 'flag,kyrgyzstan'
GO
EXEC SaveEmoji @Name='flag-laos', @Path='flag/flag-laos.png', @Categories= 'flag,laos'
GO
EXEC SaveEmoji @Name='flag-latvia', @Path='flag/flag-latvia.png', @Categories= 'flag,latvia'
GO
EXEC SaveEmoji @Name='flag-lebanon', @Path='flag/flag-lebanon.png', @Categories= 'flag,lebanon'
GO
EXEC SaveEmoji @Name='flag-lesotho', @Path='flag/flag-lesotho.png', @Categories= 'flag,lesotho'
GO
EXEC SaveEmoji @Name='flag-liberia', @Path='flag/flag-liberia.png', @Categories= 'flag,liberia'
GO
EXEC SaveEmoji @Name='flag-libya', @Path='flag/flag-libya.png', @Categories= 'flag,libya'
GO
EXEC SaveEmoji @Name='flag-liechtenstein', @Path='flag/flag-liechtenstein.png', @Categories= 'flag,liechtenstein'
GO
EXEC SaveEmoji @Name='flag-lithuania', @Path='flag/flag-lithuania.png', @Categories= 'flag,lithuania'
GO
EXEC SaveEmoji @Name='flag-luxembourg', @Path='flag/flag-luxembourg.png', @Categories= 'flag,luxembourg'
GO
EXEC SaveEmoji @Name='flag-macao-sar-china', @Path='flag/flag-macao-sar-china.png', @Categories= 'china,flag,macao,sar'
GO
EXEC SaveEmoji @Name='flag-madagascar', @Path='flag/flag-madagascar.png', @Categories= 'flag,madagascar'
GO
EXEC SaveEmoji @Name='flag-malawi', @Path='flag/flag-malawi.png', @Categories= 'flag,malawi'
GO
EXEC SaveEmoji @Name='flag-malaysia', @Path='flag/flag-malaysia.png', @Categories= 'flag,malaysia'
GO
EXEC SaveEmoji @Name='flag-maldives', @Path='flag/flag-maldives.png', @Categories= 'flag,maldives'
GO
EXEC SaveEmoji @Name='flag-mali', @Path='flag/flag-mali.png', @Categories= 'flag,mali'
GO
EXEC SaveEmoji @Name='flag-malta', @Path='flag/flag-malta.png', @Categories= 'flag,malta'
GO
EXEC SaveEmoji @Name='flag-marshall-islands', @Path='flag/flag-marshall-islands.png', @Categories= 'flag,islands,marshall'
GO
EXEC SaveEmoji @Name='flag-martinique', @Path='flag/flag-martinique.png', @Categories= 'flag,martinique'
GO
EXEC SaveEmoji @Name='flag-mauritania', @Path='flag/flag-mauritania.png', @Categories= 'flag,mauritania'
GO
EXEC SaveEmoji @Name='flag-mauritius', @Path='flag/flag-mauritius.png', @Categories= 'flag,mauritius'
GO
EXEC SaveEmoji @Name='flag-mayotte', @Path='flag/flag-mayotte.png', @Categories= 'flag,mayotte'
GO
EXEC SaveEmoji @Name='flag-mexico', @Path='flag/flag-mexico.png', @Categories= 'flag,mexico'
GO
EXEC SaveEmoji @Name='flag-micronesia', @Path='flag/flag-micronesia.png', @Categories= 'flag,micronesia'
GO
EXEC SaveEmoji @Name='flag-moldova', @Path='flag/flag-moldova.png', @Categories= 'flag,moldova'
GO
EXEC SaveEmoji @Name='flag-monaco', @Path='flag/flag-monaco.png', @Categories= 'flag,monaco'
GO
EXEC SaveEmoji @Name='flag-mongolia', @Path='flag/flag-mongolia.png', @Categories= 'flag,mongolia'
GO
EXEC SaveEmoji @Name='flag-montenegro', @Path='flag/flag-montenegro.png', @Categories= 'flag,montenegro'
GO
EXEC SaveEmoji @Name='flag-montserrat', @Path='flag/flag-montserrat.png', @Categories= 'flag,montserrat'
GO
EXEC SaveEmoji @Name='flag-morocco', @Path='flag/flag-morocco.png', @Categories= 'flag,morocco'
GO
EXEC SaveEmoji @Name='flag-mozambique', @Path='flag/flag-mozambique.png', @Categories= 'flag,mozambique'
GO
EXEC SaveEmoji @Name='flag-myanmar-burma', @Path='flag/flag-myanmar-burma.png', @Categories= 'burma,flag,myanmar'
GO
EXEC SaveEmoji @Name='flag-namibia', @Path='flag/flag-namibia.png', @Categories= 'flag,namibia'
GO
EXEC SaveEmoji @Name='flag-nauru', @Path='flag/flag-nauru.png', @Categories= 'flag,nauru'
GO
EXEC SaveEmoji @Name='flag-nepal', @Path='flag/flag-nepal.png', @Categories= 'flag,nepal'
GO
EXEC SaveEmoji @Name='flag-netherlands', @Path='flag/flag-netherlands.png', @Categories= 'flag,netherlands'
GO
EXEC SaveEmoji @Name='flag-new-caledonia', @Path='flag/flag-new-caledonia.png', @Categories= 'caledonia,flag,new'
GO
EXEC SaveEmoji @Name='flag-new-zealand', @Path='flag/flag-new-zealand.png', @Categories= 'flag,new,zealand'
GO
EXEC SaveEmoji @Name='flag-nicaragua', @Path='flag/flag-nicaragua.png', @Categories= 'flag,nicaragua'
GO
EXEC SaveEmoji @Name='flag-niger', @Path='flag/flag-niger.png', @Categories= 'flag,niger'
GO
EXEC SaveEmoji @Name='flag-nigeria', @Path='flag/flag-nigeria.png', @Categories= 'flag,nigeria'
GO
EXEC SaveEmoji @Name='flag-niue', @Path='flag/flag-niue.png', @Categories= 'flag,niue'
GO
EXEC SaveEmoji @Name='flag-norfolk-island', @Path='flag/flag-norfolk-island.png', @Categories= 'flag,island,norfolk'
GO
EXEC SaveEmoji @Name='flag-north-korea', @Path='flag/flag-north-korea.png', @Categories= 'flag,korea,north'
GO
EXEC SaveEmoji @Name='flag-north-macedonia', @Path='flag/flag-north-macedonia.png', @Categories= 'flag,macedonia,north'
GO
EXEC SaveEmoji @Name='flag-northern-mariana-islands', @Path='flag/flag-northern-mariana-islands.png', @Categories= 'flag,islands,mariana,northern'
GO
EXEC SaveEmoji @Name='flag-norway', @Path='flag/flag-norway.png', @Categories= 'flag,norway'
GO
EXEC SaveEmoji @Name='flag-oman', @Path='flag/flag-oman.png', @Categories= 'flag,oman'
GO
EXEC SaveEmoji @Name='flag-pakistan', @Path='flag/flag-pakistan.png', @Categories= 'flag,pakistan'
GO
EXEC SaveEmoji @Name='flag-palau', @Path='flag/flag-palau.png', @Categories= 'flag,palau'
GO
EXEC SaveEmoji @Name='flag-palestinian-territories', @Path='flag/flag-palestinian-territories.png', @Categories= 'flag,palestinian,territories'
GO
EXEC SaveEmoji @Name='flag-panama', @Path='flag/flag-panama.png', @Categories= 'flag,panama'
GO
EXEC SaveEmoji @Name='flag-papua-new-guinea', @Path='flag/flag-papua-new-guinea.png', @Categories= 'flag,guinea,new,papua'
GO
EXEC SaveEmoji @Name='flag-paraguay', @Path='flag/flag-paraguay.png', @Categories= 'flag,paraguay'
GO
EXEC SaveEmoji @Name='flag-peru', @Path='flag/flag-peru.png', @Categories= 'flag,peru'
GO
EXEC SaveEmoji @Name='flag-philippines', @Path='flag/flag-philippines.png', @Categories= 'flag,philippines'
GO
EXEC SaveEmoji @Name='flag-pitcairn-islands', @Path='flag/flag-pitcairn-islands.png', @Categories= 'flag,islands,pitcairn'
GO
EXEC SaveEmoji @Name='flag-poland', @Path='flag/flag-poland.png', @Categories= 'flag,poland'
GO
EXEC SaveEmoji @Name='flag-portugal', @Path='flag/flag-portugal.png', @Categories= 'flag,portugal'
GO
EXEC SaveEmoji @Name='flag-puerto-rico', @Path='flag/flag-puerto-rico.png', @Categories= 'flag,puerto,rico'
GO
EXEC SaveEmoji @Name='flag-qatar', @Path='flag/flag-qatar.png', @Categories= 'flag,qatar'
GO
EXEC SaveEmoji @Name='flag-reunion', @Path='flag/flag-reunion.png', @Categories= 'flag,reunion'
GO
EXEC SaveEmoji @Name='flag-romania', @Path='flag/flag-romania.png', @Categories= 'flag,romania'
GO
EXEC SaveEmoji @Name='flag-russia', @Path='flag/flag-russia.png', @Categories= 'flag,russia'
GO
EXEC SaveEmoji @Name='flag-rwanda', @Path='flag/flag-rwanda.png', @Categories= 'flag,rwanda'
GO
EXEC SaveEmoji @Name='flag-samoa', @Path='flag/flag-samoa.png', @Categories= 'flag,samoa'
GO
EXEC SaveEmoji @Name='flag-san-marino', @Path='flag/flag-san-marino.png', @Categories= 'flag,marino,san'
GO
EXEC SaveEmoji @Name='flag-sao-tome-principe', @Path='flag/flag-sao-tome-principe.png', @Categories= 'flag,principe,sao,tome'
GO
EXEC SaveEmoji @Name='flag-saudi-arabia', @Path='flag/flag-saudi-arabia.png', @Categories= 'arabia,flag,saudi'
GO
EXEC SaveEmoji @Name='flag-scotland', @Path='flag/flag-scotland.png', @Categories= 'flag,scotland'
GO
EXEC SaveEmoji @Name='flag-senegal', @Path='flag/flag-senegal.png', @Categories= 'flag,senegal'
GO
EXEC SaveEmoji @Name='flag-serbia', @Path='flag/flag-serbia.png', @Categories= 'flag,serbia'
GO
EXEC SaveEmoji @Name='flag-seychelles', @Path='flag/flag-seychelles.png', @Categories= 'flag,seychelles'
GO
EXEC SaveEmoji @Name='flag-sierra-leone', @Path='flag/flag-sierra-leone.png', @Categories= 'flag,leone,sierra'
GO
EXEC SaveEmoji @Name='flag-singapore', @Path='flag/flag-singapore.png', @Categories= 'flag,singapore'
GO
EXEC SaveEmoji @Name='flag-sint-maarten', @Path='flag/flag-sint-maarten.png', @Categories= 'flag,maarten,sint'
GO
EXEC SaveEmoji @Name='flag-slovakia', @Path='flag/flag-slovakia.png', @Categories= 'flag,slovakia'
GO
EXEC SaveEmoji @Name='flag-slovenia', @Path='flag/flag-slovenia.png', @Categories= 'flag,slovenia'
GO
EXEC SaveEmoji @Name='flag-solomon-islands', @Path='flag/flag-solomon-islands.png', @Categories= 'flag,islands,solomon'
GO
EXEC SaveEmoji @Name='flag-somalia', @Path='flag/flag-somalia.png', @Categories= 'flag,somalia'
GO
EXEC SaveEmoji @Name='flag-south-africa', @Path='flag/flag-south-africa.png', @Categories= 'africa,flag,south'
GO
EXEC SaveEmoji @Name='flag-south-georgia-south-sandwich-islands', @Path='flag/flag-south-georgia-south-sandwich-islands.png', @Categories= 'flag,georgia,islands,sandwich,south'
GO
EXEC SaveEmoji @Name='flag-south-korea', @Path='flag/flag-south-korea.png', @Categories= 'flag,korea,south'
GO
EXEC SaveEmoji @Name='flag-south-sudan', @Path='flag/flag-south-sudan.png', @Categories= 'flag,south,sudan'
GO
EXEC SaveEmoji @Name='flag-spain', @Path='flag/flag-spain.png', @Categories= 'flag,spain'
GO
EXEC SaveEmoji @Name='flag-sri-lanka', @Path='flag/flag-sri-lanka.png', @Categories= 'flag,lanka,sri'
GO
EXEC SaveEmoji @Name='flag-st-barthelemy', @Path='flag/flag-st-barthelemy.png', @Categories= 'barthelemy,flag,st'
GO
EXEC SaveEmoji @Name='flag-st-helena', @Path='flag/flag-st-helena.png', @Categories= 'flag,helena,st'
GO
EXEC SaveEmoji @Name='flag-st-kitts-nevis', @Path='flag/flag-st-kitts-nevis.png', @Categories= 'flag,kitts,nevis,st'
GO
EXEC SaveEmoji @Name='flag-st-lucia', @Path='flag/flag-st-lucia.png', @Categories= 'flag,lucia,st'
GO
EXEC SaveEmoji @Name='flag-st-martin', @Path='flag/flag-st-martin.png', @Categories= 'flag,martin,st'
GO
EXEC SaveEmoji @Name='flag-st-pierre-miquelon', @Path='flag/flag-st-pierre-miquelon.png', @Categories= 'flag,miquelon,pierre,st'
GO
EXEC SaveEmoji @Name='flag-st-vincent-grenadines', @Path='flag/flag-st-vincent-grenadines.png', @Categories= 'flag,grenadines,st,vincent'
GO
EXEC SaveEmoji @Name='flag-sudan', @Path='flag/flag-sudan.png', @Categories= 'flag,sudan'
GO
EXEC SaveEmoji @Name='flag-suriname', @Path='flag/flag-suriname.png', @Categories= 'flag,suriname'
GO
EXEC SaveEmoji @Name='flag-svalbard-jan-mayen', @Path='flag/flag-svalbard-jan-mayen.png', @Categories= 'flag,jan,mayen,svalbard'
GO
EXEC SaveEmoji @Name='flag-sweden', @Path='flag/flag-sweden.png', @Categories= 'flag,sweden'
GO
EXEC SaveEmoji @Name='flag-switzerland', @Path='flag/flag-switzerland.png', @Categories= 'flag,switzerland'
GO
EXEC SaveEmoji @Name='flag-syria', @Path='flag/flag-syria.png', @Categories= 'flag,syria'
GO
EXEC SaveEmoji @Name='flag-taiwan', @Path='flag/flag-taiwan.png', @Categories= 'flag,taiwan'
GO
EXEC SaveEmoji @Name='flag-tajikistan', @Path='flag/flag-tajikistan.png', @Categories= 'flag,tajikistan'
GO
EXEC SaveEmoji @Name='flag-tanzania', @Path='flag/flag-tanzania.png', @Categories= 'flag,tanzania'
GO
EXEC SaveEmoji @Name='flag-thailand', @Path='flag/flag-thailand.png', @Categories= 'flag,thailand'
GO
EXEC SaveEmoji @Name='flag-timor-leste', @Path='flag/flag-timor-leste.png', @Categories= 'flag,leste,timor'
GO
EXEC SaveEmoji @Name='flag-togo', @Path='flag/flag-togo.png', @Categories= 'flag,togo'
GO
EXEC SaveEmoji @Name='flag-tokelau', @Path='flag/flag-tokelau.png', @Categories= 'flag,tokelau'
GO
EXEC SaveEmoji @Name='flag-tonga', @Path='flag/flag-tonga.png', @Categories= 'flag,tonga'
GO
EXEC SaveEmoji @Name='flag-trinidad-tobago', @Path='flag/flag-trinidad-tobago.png', @Categories= 'flag,tobago,trinidad'
GO
EXEC SaveEmoji @Name='flag-tristan-da-cunha', @Path='flag/flag-tristan-da-cunha.png', @Categories= 'cunha,da,flag,tristan'
GO
EXEC SaveEmoji @Name='flag-tunisia', @Path='flag/flag-tunisia.png', @Categories= 'flag,tunisia'
GO
EXEC SaveEmoji @Name='flag-turkey', @Path='flag/flag-turkey.png', @Categories= 'flag,turkey'
GO
EXEC SaveEmoji @Name='flag-turkmenistan', @Path='flag/flag-turkmenistan.png', @Categories= 'flag,turkmenistan'
GO
EXEC SaveEmoji @Name='flag-turks-caicos-islands', @Path='flag/flag-turks-caicos-islands.png', @Categories= 'caicos,flag,islands,turks'
GO
EXEC SaveEmoji @Name='flag-tuvalu', @Path='flag/flag-tuvalu.png', @Categories= 'flag,tuvalu'
GO
EXEC SaveEmoji @Name='flag-uganda', @Path='flag/flag-uganda.png', @Categories= 'flag,uganda'
GO
EXEC SaveEmoji @Name='flag-ukraine', @Path='flag/flag-ukraine.png', @Categories= 'flag,ukraine'
GO
EXEC SaveEmoji @Name='flag-united-arab-emirates', @Path='flag/flag-united-arab-emirates.png', @Categories= 'arab,emirates,flag,united'
GO
EXEC SaveEmoji @Name='flag-united-kingdom', @Path='flag/flag-united-kingdom.png', @Categories= 'flag,kingdom,united'
GO
EXEC SaveEmoji @Name='flag-united-nations', @Path='flag/flag-united-nations.png', @Categories= 'flag,nations,united'
GO
EXEC SaveEmoji @Name='flag-united-states', @Path='flag/flag-united-states.png', @Categories= 'flag,states,united'
GO
EXEC SaveEmoji @Name='flag-uruguay', @Path='flag/flag-uruguay.png', @Categories= 'flag,uruguay'
GO
EXEC SaveEmoji @Name='flag-us-outlying-islands', @Path='flag/flag-us-outlying-islands.png', @Categories= 'flag,islands,outlying,us'
GO
EXEC SaveEmoji @Name='flag-us-virgin-islands', @Path='flag/flag-us-virgin-islands.png', @Categories= 'flag,islands,us,virgin'
GO
EXEC SaveEmoji @Name='flag-uzbekistan', @Path='flag/flag-uzbekistan.png', @Categories= 'flag,uzbekistan'
GO
EXEC SaveEmoji @Name='flag-vanuatu', @Path='flag/flag-vanuatu.png', @Categories= 'flag,vanuatu'
GO
EXEC SaveEmoji @Name='flag-vatican-city', @Path='flag/flag-vatican-city.png', @Categories= 'city,flag,vatican'
GO
EXEC SaveEmoji @Name='flag-venezuela', @Path='flag/flag-venezuela.png', @Categories= 'flag,venezuela'
GO
EXEC SaveEmoji @Name='flag-vietnam', @Path='flag/flag-vietnam.png', @Categories= 'flag,vietnam'
GO
EXEC SaveEmoji @Name='flag-wales', @Path='flag/flag-wales.png', @Categories= 'flag,wales'
GO
EXEC SaveEmoji @Name='flag-wallis-futuna', @Path='flag/flag-wallis-futuna.png', @Categories= 'flag,futuna,wallis'
GO
EXEC SaveEmoji @Name='flag-western-sahara', @Path='flag/flag-western-sahara.png', @Categories= 'flag,sahara,western'
GO
EXEC SaveEmoji @Name='flag-yemen', @Path='flag/flag-yemen.png', @Categories= 'flag,yemen'
GO
EXEC SaveEmoji @Name='flag-zambia', @Path='flag/flag-zambia.png', @Categories= 'flag,zambia'
GO
EXEC SaveEmoji @Name='flag-zimbabwe', @Path='flag/flag-zimbabwe.png', @Categories= 'flag,zimbabwe'
GO
EXEC SaveEmoji @Name='open-mailbox-with-lowered-flag', @Path='flag/open-mailbox-with-lowered-flag.png', @Categories= 'flag,lowered,mailbox,open,with'
GO
EXEC SaveEmoji @Name='open-mailbox-with-raised-flag', @Path='flag/open-mailbox-with-raised-flag.png', @Categories= 'flag,mailbox,open,raised,with'
GO
EXEC SaveEmoji @Name='pirate-flag', @Path='flag/pirate-flag.png', @Categories= 'flag,pirate'
GO
EXEC SaveEmoji @Name='rainbow-flag', @Path='flag/rainbow-flag.png', @Categories= 'flag,rainbow'
GO
EXEC SaveEmoji @Name='transgender-flag', @Path='flag/transgender-flag.png', @Categories= 'flag,transgender'
GO
EXEC SaveEmoji @Name='triangular-flag', @Path='flag/triangular-flag.png', @Categories= 'flag,triangular'
GO
EXEC SaveEmoji @Name='white-flag', @Path='flag/white-flag.png', @Categories= 'flag,white'
GO
EXEC SaveEmoji @Name='avocado', @Path='food/avocado.png', @Categories= 'avocado,food'
GO
EXEC SaveEmoji @Name='baby-bottle', @Path='food/baby-bottle.png', @Categories= 'baby,bottle,food'
GO
EXEC SaveEmoji @Name='bacon', @Path='food/bacon.png', @Categories= 'bacon,food'
GO
EXEC SaveEmoji @Name='bagel', @Path='food/bagel.png', @Categories= 'bagel,food'
GO
EXEC SaveEmoji @Name='baguette-bread', @Path='food/baguette-bread.png', @Categories= 'baguette,bread,food'
GO
EXEC SaveEmoji @Name='banana', @Path='food/banana.png', @Categories= 'banana,food'
GO
EXEC SaveEmoji @Name='beans', @Path='food/beans.png', @Categories= 'beans,food'
GO
EXEC SaveEmoji @Name='beer-mug', @Path='food/beer-mug.png', @Categories= 'beer,food,mug'
GO
EXEC SaveEmoji @Name='bell-pepper', @Path='food/bell-pepper.png', @Categories= 'bell,food,pepper'
GO
EXEC SaveEmoji @Name='bento-box', @Path='food/bento-box.png', @Categories= 'bento,box,food'
GO
EXEC SaveEmoji @Name='beverage-box', @Path='food/beverage-box.png', @Categories= 'beverage,box,food'
GO
EXEC SaveEmoji @Name='birthday-cake', @Path='food/birthday-cake.png', @Categories= 'birthday,cake,food'
GO
EXEC SaveEmoji @Name='blueberries', @Path='food/blueberries.png', @Categories= 'blueberries,food'
GO
EXEC SaveEmoji @Name='bottle-with-popping-cork', @Path='food/bottle-with-popping-cork.png', @Categories= 'bottle,cork,food,popping,with'
GO
EXEC SaveEmoji @Name='bowl-with-spoon', @Path='food/bowl-with-spoon.png', @Categories= 'bowl,food,spoon,with'
GO
EXEC SaveEmoji @Name='bread', @Path='food/bread.png', @Categories= 'bread,food'
GO
EXEC SaveEmoji @Name='broccoli', @Path='food/broccoli.png', @Categories= 'broccoli,food'
GO
EXEC SaveEmoji @Name='bubble-tea', @Path='food/bubble-tea.png', @Categories= 'bubble,food,tea'
GO
EXEC SaveEmoji @Name='burrito', @Path='food/burrito.png', @Categories= 'burrito,food'
GO
EXEC SaveEmoji @Name='butter', @Path='food/butter.png', @Categories= 'butter,food'
GO
EXEC SaveEmoji @Name='candy', @Path='food/candy.png', @Categories= 'candy,food'
GO
EXEC SaveEmoji @Name='canned-food', @Path='food/canned-food.png', @Categories= 'canned,food'
GO
EXEC SaveEmoji @Name='carrot', @Path='food/carrot.png', @Categories= 'carrot,food'
GO
EXEC SaveEmoji @Name='cheese-wedge', @Path='food/cheese-wedge.png', @Categories= 'cheese,food,wedge'
GO
EXEC SaveEmoji @Name='cherries', @Path='food/cherries.png', @Categories= 'cherries,food'
GO
EXEC SaveEmoji @Name='chestnut', @Path='food/chestnut.png', @Categories= 'chestnut,food'
GO
EXEC SaveEmoji @Name='chocolate-bar', @Path='food/chocolate-bar.png', @Categories= 'bar,chocolate,food'
GO
EXEC SaveEmoji @Name='chopsticks', @Path='food/chopsticks.png', @Categories= 'chopsticks,food'
GO
EXEC SaveEmoji @Name='clinking-beer-mugs', @Path='food/clinking-beer-mugs.png', @Categories= 'beer,clinking,food,mugs'
GO
EXEC SaveEmoji @Name='clinking-glasses', @Path='food/clinking-glasses.png', @Categories= 'clinking,food,glasses'
GO
EXEC SaveEmoji @Name='cocktail-glass', @Path='food/cocktail-glass.png', @Categories= 'cocktail,food,glass'
GO
EXEC SaveEmoji @Name='coconut', @Path='food/coconut.png', @Categories= 'coconut,food'
GO
EXEC SaveEmoji @Name='cooked-rice', @Path='food/cooked-rice.png', @Categories= 'cooked,food,rice'
GO
EXEC SaveEmoji @Name='cookie', @Path='food/cookie.png', @Categories= 'cookie,food'
GO
EXEC SaveEmoji @Name='cooking', @Path='food/cooking.png', @Categories= 'cooking,food'
GO
EXEC SaveEmoji @Name='croissant', @Path='food/croissant.png', @Categories= 'croissant,food'
GO
EXEC SaveEmoji @Name='cucumber', @Path='food/cucumber.png', @Categories= 'cucumber,food'
GO
EXEC SaveEmoji @Name='cup-with-straw', @Path='food/cup-with-straw.png', @Categories= 'cup,food,straw,with'
GO
EXEC SaveEmoji @Name='cupcake', @Path='food/cupcake.png', @Categories= 'cupcake,food'
GO
EXEC SaveEmoji @Name='curry-rice', @Path='food/curry-rice.png', @Categories= 'curry,food,rice'
GO
EXEC SaveEmoji @Name='custard', @Path='food/custard.png', @Categories= 'custard,food'
GO
EXEC SaveEmoji @Name='cut-of-meat', @Path='food/cut-of-meat.png', @Categories= 'cut,food,meat,of'
GO
EXEC SaveEmoji @Name='dango', @Path='food/dango.png', @Categories= 'dango,food'
GO
EXEC SaveEmoji @Name='doughnut', @Path='food/doughnut.png', @Categories= 'doughnut,food'
GO
EXEC SaveEmoji @Name='dumpling', @Path='food/dumpling.png', @Categories= 'dumpling,food'
GO
EXEC SaveEmoji @Name='ear-of-corn', @Path='food/ear-of-corn.png', @Categories= 'corn,ear,food,of'
GO
EXEC SaveEmoji @Name='egg', @Path='food/egg.png', @Categories= 'egg,food'
GO
EXEC SaveEmoji @Name='eggplant', @Path='food/eggplant.png', @Categories= 'eggplant,food'
GO
EXEC SaveEmoji @Name='falafel', @Path='food/falafel.png', @Categories= 'falafel,food'
GO
EXEC SaveEmoji @Name='fish-cake-with-swirl', @Path='food/fish-cake-with-swirl.png', @Categories= 'cake,fish,food,swirl,with'
GO
EXEC SaveEmoji @Name='flatbread', @Path='food/flatbread.png', @Categories= 'flatbread,food'
GO
EXEC SaveEmoji @Name='fondue', @Path='food/fondue.png', @Categories= 'fondue,food'
GO
EXEC SaveEmoji @Name='fork-and-knife-with-plate', @Path='food/fork-and-knife-with-plate.png', @Categories= 'and,food,fork,knife,plate,with'
GO
EXEC SaveEmoji @Name='fork-and-knife', @Path='food/fork-and-knife.png', @Categories= 'and,food,fork,knife'
GO
EXEC SaveEmoji @Name='fortune-cookie', @Path='food/fortune-cookie.png', @Categories= 'cookie,food,fortune'
GO
EXEC SaveEmoji @Name='french-fries', @Path='food/french-fries.png', @Categories= 'food,french,fries'
GO
EXEC SaveEmoji @Name='fried-shrimp', @Path='food/fried-shrimp.png', @Categories= 'food,fried,shrimp'
GO
EXEC SaveEmoji @Name='garlic', @Path='food/garlic.png', @Categories= 'food,garlic'
GO
EXEC SaveEmoji @Name='ginger', @Path='food/ginger.png', @Categories= 'food,ginger'
GO
EXEC SaveEmoji @Name='glass-of-milk', @Path='food/glass-of-milk.png', @Categories= 'food,glass,milk,of'
GO
EXEC SaveEmoji @Name='grapes', @Path='food/grapes.png', @Categories= 'food,grapes'
GO
EXEC SaveEmoji @Name='green-apple', @Path='food/green-apple.png', @Categories= 'apple,food,green'
GO
EXEC SaveEmoji @Name='green-salad', @Path='food/green-salad.png', @Categories= 'food,green,salad'
GO
EXEC SaveEmoji @Name='hamburger', @Path='food/hamburger.png', @Categories= 'food,hamburger'
GO
EXEC SaveEmoji @Name='hot-beverage', @Path='food/hot-beverage.png', @Categories= 'beverage,food,hot'
GO
EXEC SaveEmoji @Name='hot-dog', @Path='food/hot-dog.png', @Categories= 'dog,food,hot'
GO
EXEC SaveEmoji @Name='hot-pepper', @Path='food/hot-pepper.png', @Categories= 'food,hot,pepper'
GO
EXEC SaveEmoji @Name='ice-cream', @Path='food/ice-cream.png', @Categories= 'cream,food,ice'
GO
EXEC SaveEmoji @Name='ice', @Path='food/ice.png', @Categories= 'food,ice'
GO
EXEC SaveEmoji @Name='kiwi-fruit', @Path='food/kiwi-fruit.png', @Categories= 'food,fruit,kiwi'
GO
EXEC SaveEmoji @Name='leaf-fluttering-in-wind', @Path='food/leaf-fluttering-in-wind.png', @Categories= 'fluttering,food,in,leaf,wind'
GO
EXEC SaveEmoji @Name='leafy-green', @Path='food/leafy-green.png', @Categories= 'food,green,leafy'
GO
EXEC SaveEmoji @Name='lemon', @Path='food/lemon.png', @Categories= 'food,lemon'
GO
EXEC SaveEmoji @Name='lollipop', @Path='food/lollipop.png', @Categories= 'food,lollipop'
GO
EXEC SaveEmoji @Name='mango', @Path='food/mango.png', @Categories= 'food,mango'
GO
EXEC SaveEmoji @Name='mate', @Path='food/mate.png', @Categories= 'food,mate'
GO
EXEC SaveEmoji @Name='meat-on-bone', @Path='food/meat-on-bone.png', @Categories= 'bone,food,meat,on'
GO
EXEC SaveEmoji @Name='melon', @Path='food/melon.png', @Categories= 'food,melon'
GO
EXEC SaveEmoji @Name='moon-cake', @Path='food/moon-cake.png', @Categories= 'cake,food,moon'
GO
EXEC SaveEmoji @Name='mushroom', @Path='food/mushroom.png', @Categories= 'food,mushroom'
GO
EXEC SaveEmoji @Name='oden', @Path='food/oden.png', @Categories= 'food,oden'
GO
EXEC SaveEmoji @Name='olive', @Path='food/olive.png', @Categories= 'food,olive'
GO
EXEC SaveEmoji @Name='onion', @Path='food/onion.png', @Categories= 'food,onion'
GO
EXEC SaveEmoji @Name='oyster', @Path='food/oyster.png', @Categories= 'food,oyster'
GO
EXEC SaveEmoji @Name='pancakes', @Path='food/pancakes.png', @Categories= 'food,pancakes'
GO
EXEC SaveEmoji @Name='pea-pod', @Path='food/pea-pod.png', @Categories= 'food,pea,pod'
GO
EXEC SaveEmoji @Name='peach', @Path='food/peach.png', @Categories= 'food,peach'
GO
EXEC SaveEmoji @Name='peanuts', @Path='food/peanuts.png', @Categories= 'food,peanuts'
GO
EXEC SaveEmoji @Name='pear', @Path='food/pear.png', @Categories= 'food,pear'
GO
EXEC SaveEmoji @Name='pie', @Path='food/pie.png', @Categories= 'food,pie'
GO
EXEC SaveEmoji @Name='pineapple', @Path='food/pineapple.png', @Categories= 'food,pineapple'
GO
EXEC SaveEmoji @Name='pizza', @Path='food/pizza.png', @Categories= 'food,pizza'
GO
EXEC SaveEmoji @Name='popcorn', @Path='food/popcorn.png', @Categories= 'food,popcorn'
GO
EXEC SaveEmoji @Name='pot-of-food', @Path='food/pot-of-food.png', @Categories= 'food,of,pot'
GO
EXEC SaveEmoji @Name='potable-water', @Path='food/potable-water.png', @Categories= 'food,potable,water'
GO
EXEC SaveEmoji @Name='potato', @Path='food/potato.png', @Categories= 'food,potato'
GO
EXEC SaveEmoji @Name='poultry-leg', @Path='food/poultry-leg.png', @Categories= 'food,leg,poultry'
GO
EXEC SaveEmoji @Name='pretzel', @Path='food/pretzel.png', @Categories= 'food,pretzel'
GO
EXEC SaveEmoji @Name='red-apple', @Path='food/red-apple.png', @Categories= 'apple,food,red'
GO
EXEC SaveEmoji @Name='rice-ball', @Path='food/rice-ball.png', @Categories= 'ball,food,rice'
GO
EXEC SaveEmoji @Name='rice-cracker', @Path='food/rice-cracker.png', @Categories= 'cracker,food,rice'
GO
EXEC SaveEmoji @Name='roasted-sweet-potato', @Path='food/roasted-sweet-potato.png', @Categories= 'food,potato,roasted,sweet'
GO
EXEC SaveEmoji @Name='sake', @Path='food/sake.png', @Categories= 'food,sake'
GO
EXEC SaveEmoji @Name='salt', @Path='food/salt.png', @Categories= 'food,salt'
GO
EXEC SaveEmoji @Name='sandwich', @Path='food/sandwich.png', @Categories= 'food,sandwich'
GO
EXEC SaveEmoji @Name='shallow-pan-of-food', @Path='food/shallow-pan-of-food.png', @Categories= 'food,of,pan,shallow'
GO
EXEC SaveEmoji @Name='shaved-ice', @Path='food/shaved-ice.png', @Categories= 'food,ice,shaved'
GO
EXEC SaveEmoji @Name='sheaf-of-rice', @Path='food/sheaf-of-rice.png', @Categories= 'food,of,rice,sheaf'
GO
EXEC SaveEmoji @Name='shortcake', @Path='food/shortcake.png', @Categories= 'food,shortcake'
GO
EXEC SaveEmoji @Name='soft-ice-cream', @Path='food/soft-ice-cream.png', @Categories= 'cream,food,ice,soft'
GO
EXEC SaveEmoji @Name='spaghetti', @Path='food/spaghetti.png', @Categories= 'food,spaghetti'
GO
EXEC SaveEmoji @Name='spoon', @Path='food/spoon.png', @Categories= 'food,spoon'
GO
EXEC SaveEmoji @Name='steaming-bowl', @Path='food/steaming-bowl.png', @Categories= 'bowl,food,steaming'
GO
EXEC SaveEmoji @Name='strawberry', @Path='food/strawberry.png', @Categories= 'food,strawberry'
GO
EXEC SaveEmoji @Name='stuffed-flatbread', @Path='food/stuffed-flatbread.png', @Categories= 'flatbread,food,stuffed'
GO
EXEC SaveEmoji @Name='sushi', @Path='food/sushi.png', @Categories= 'food,sushi'
GO
EXEC SaveEmoji @Name='taco', @Path='food/taco.png', @Categories= 'food,taco'
GO
EXEC SaveEmoji @Name='takeout-box', @Path='food/takeout-box.png', @Categories= 'box,food,takeout'
GO
EXEC SaveEmoji @Name='tamale', @Path='food/tamale.png', @Categories= 'food,tamale'
GO
EXEC SaveEmoji @Name='tangerine', @Path='food/tangerine.png', @Categories= 'food,tangerine'
GO
EXEC SaveEmoji @Name='teacup-without-handle', @Path='food/teacup-without-handle.png', @Categories= 'food,handle,teacup,without'
GO
EXEC SaveEmoji @Name='teapot', @Path='food/teapot.png', @Categories= 'food,teapot'
GO
EXEC SaveEmoji @Name='tomato', @Path='food/tomato.png', @Categories= 'food,tomato'
GO
EXEC SaveEmoji @Name='tropical-drink', @Path='food/tropical-drink.png', @Categories= 'drink,food,tropical'
GO
EXEC SaveEmoji @Name='tumbler-glass', @Path='food/tumbler-glass.png', @Categories= 'food,glass,tumbler'
GO
EXEC SaveEmoji @Name='waffle', @Path='food/waffle.png', @Categories= 'food,waffle'
GO
EXEC SaveEmoji @Name='watermelon', @Path='food/watermelon.png', @Categories= 'food,watermelon'
GO
EXEC SaveEmoji @Name='wine-glass', @Path='food/wine-glass.png', @Categories= 'food,glass,wine'
GO
EXEC SaveEmoji @Name='backhand-index-pointing-down', @Path='gesture/backhand-index-pointing-down.png', @Categories= 'backhand,down,gesture,index,pointing'
GO
EXEC SaveEmoji @Name='backhand-index-pointing-left', @Path='gesture/backhand-index-pointing-left.png', @Categories= 'backhand,gesture,index,left,pointing'
GO
EXEC SaveEmoji @Name='backhand-index-pointing-right', @Path='gesture/backhand-index-pointing-right.png', @Categories= 'backhand,gesture,index,pointing,right'
GO
EXEC SaveEmoji @Name='backhand-index-pointing-up', @Path='gesture/backhand-index-pointing-up.png', @Categories= 'backhand,gesture,index,pointing,up'
GO
EXEC SaveEmoji @Name='call-me-hand', @Path='gesture/call-me-hand.png', @Categories= 'call,gesture,hand,me'
GO
EXEC SaveEmoji @Name='clapping-hands', @Path='gesture/clapping-hands.png', @Categories= 'clapping,gesture,hands'
GO
EXEC SaveEmoji @Name='crossed-fingers', @Path='gesture/crossed-fingers.png', @Categories= 'crossed,fingers,gesture'
GO
EXEC SaveEmoji @Name='flexed-biceps', @Path='gesture/flexed-biceps.png', @Categories= 'biceps,flexed,gesture'
GO
EXEC SaveEmoji @Name='folded-hands', @Path='gesture/folded-hands.png', @Categories= 'folded,gesture,hands'
GO
EXEC SaveEmoji @Name='foot', @Path='gesture/foot.png', @Categories= 'foot,gesture'
GO
EXEC SaveEmoji @Name='hand-with-fingers-splayed', @Path='gesture/hand-with-fingers-splayed.png', @Categories= 'fingers,gesture,hand,splayed,with'
GO
EXEC SaveEmoji @Name='hand-with-index-finger-and-thumb-crossed', @Path='gesture/hand-with-index-finger-and-thumb-crossed.png', @Categories= 'and,crossed,finger,gesture,hand,index,thumb,with'
GO
EXEC SaveEmoji @Name='handshake', @Path='gesture/handshake.png', @Categories= 'gesture,handshake'
GO
EXEC SaveEmoji @Name='heart-hands', @Path='gesture/heart-hands.png', @Categories= 'gesture,hands,heart'
GO
EXEC SaveEmoji @Name='index-pointing-at-the-viewer', @Path='gesture/index-pointing-at-the-viewer.png', @Categories= 'at,gesture,index,pointing,the,viewer'
GO
EXEC SaveEmoji @Name='index-pointing-up', @Path='gesture/index-pointing-up.png', @Categories= 'gesture,index,pointing,up'
GO
EXEC SaveEmoji @Name='left-facing-fist', @Path='gesture/left-facing-fist.png', @Categories= 'facing,fist,gesture,left'
GO
EXEC SaveEmoji @Name='leftwards-hand', @Path='gesture/leftwards-hand.png', @Categories= 'gesture,hand,leftwards'
GO
EXEC SaveEmoji @Name='leg', @Path='gesture/leg.png', @Categories= 'gesture,leg'
GO
EXEC SaveEmoji @Name='love-you-gesture', @Path='gesture/love-you-gesture.png', @Categories= 'gesture,love,you'
GO
EXEC SaveEmoji @Name='middle-finger', @Path='gesture/middle-finger.png', @Categories= 'finger,gesture,middle'
GO
EXEC SaveEmoji @Name='nail-polish', @Path='gesture/nail-polish.png', @Categories= 'gesture,nail,polish'
GO
EXEC SaveEmoji @Name='ok-hand', @Path='gesture/ok-hand.png', @Categories= 'gesture,hand,ok'
GO
EXEC SaveEmoji @Name='oncoming-fist', @Path='gesture/oncoming-fist.png', @Categories= 'fist,gesture,oncoming'
GO
EXEC SaveEmoji @Name='open-hands', @Path='gesture/open-hands.png', @Categories= 'gesture,hands,open'
GO
EXEC SaveEmoji @Name='palm-down-hand', @Path='gesture/palm-down-hand.png', @Categories= 'down,gesture,hand,palm'
GO
EXEC SaveEmoji @Name='palm-up-hand', @Path='gesture/palm-up-hand.png', @Categories= 'gesture,hand,palm,up'
GO
EXEC SaveEmoji @Name='palms-up-together', @Path='gesture/palms-up-together.png', @Categories= 'gesture,palms,together,up'
GO
EXEC SaveEmoji @Name='pinched-fingers', @Path='gesture/pinched-fingers.png', @Categories= 'fingers,gesture,pinched'
GO
EXEC SaveEmoji @Name='pinching-hand', @Path='gesture/pinching-hand.png', @Categories= 'gesture,hand,pinching'
GO
EXEC SaveEmoji @Name='raised-back-of-hand', @Path='gesture/raised-back-of-hand.png', @Categories= 'back,gesture,hand,of,raised'
GO
EXEC SaveEmoji @Name='raised-fist', @Path='gesture/raised-fist.png', @Categories= 'fist,gesture,raised'
GO
EXEC SaveEmoji @Name='raised-hand', @Path='gesture/raised-hand.png', @Categories= 'gesture,hand,raised'
GO
EXEC SaveEmoji @Name='raising-hands', @Path='gesture/raising-hands.png', @Categories= 'gesture,hands,raising'
GO
EXEC SaveEmoji @Name='right-facing-fist', @Path='gesture/right-facing-fist.png', @Categories= 'facing,fist,gesture,right'
GO
EXEC SaveEmoji @Name='rightwards-hand', @Path='gesture/rightwards-hand.png', @Categories= 'gesture,hand,rightwards'
GO
EXEC SaveEmoji @Name='selfie', @Path='gesture/selfie.png', @Categories= 'gesture,selfie'
GO
EXEC SaveEmoji @Name='sign-of-the-horns', @Path='gesture/sign-of-the-horns.png', @Categories= 'gesture,horns,of,sign,the'
GO
EXEC SaveEmoji @Name='thumbs-down', @Path='gesture/thumbs-down.png', @Categories= 'down,gesture,thumbs'
GO
EXEC SaveEmoji @Name='thumbs-up', @Path='gesture/thumbs-up.png', @Categories= 'gesture,thumbs,up'
GO
EXEC SaveEmoji @Name='victory-hand', @Path='gesture/victory-hand.png', @Categories= 'gesture,hand,victory'
GO
EXEC SaveEmoji @Name='vulcan-salute', @Path='gesture/vulcan-salute.png', @Categories= 'gesture,salute,vulcan'
GO
EXEC SaveEmoji @Name='waving-hand', @Path='gesture/waving-hand.png', @Categories= 'gesture,hand,waving'
GO
EXEC SaveEmoji @Name='writing-hand', @Path='gesture/writing-hand.png', @Categories= 'gesture,hand,writing'
GO
EXEC SaveEmoji @Name='brain', @Path='health/brain.png', @Categories= 'brain,health'
GO
EXEC SaveEmoji @Name='coffin', @Path='health/coffin.png', @Categories= 'coffin,health'
GO
EXEC SaveEmoji @Name='dna', @Path='health/dna.png', @Categories= 'dna,health'
GO
EXEC SaveEmoji @Name='drop-of-blood', @Path='health/drop-of-blood.png', @Categories= 'blood,drop,health,of'
GO
EXEC SaveEmoji @Name='funeral-urn', @Path='health/funeral-urn.png', @Categories= 'funeral,health,urn'
GO
EXEC SaveEmoji @Name='lungs', @Path='health/lungs.png', @Categories= 'health,lungs'
GO
EXEC SaveEmoji @Name='petri-dish', @Path='health/petri-dish.png', @Categories= 'dish,health,petri'
GO
EXEC SaveEmoji @Name='pill', @Path='health/pill.png', @Categories= 'health,pill'
GO
EXEC SaveEmoji @Name='razor', @Path='health/razor.png', @Categories= 'health,razor'
GO
EXEC SaveEmoji @Name='shower', @Path='health/shower.png', @Categories= 'health,shower'
GO
EXEC SaveEmoji @Name='soap', @Path='health/soap.png', @Categories= 'health,soap'
GO
EXEC SaveEmoji @Name='sponge', @Path='health/sponge.png', @Categories= 'health,sponge'
GO
EXEC SaveEmoji @Name='toilet', @Path='health/toilet.png', @Categories= 'health,toilet'
GO
EXEC SaveEmoji @Name='tooth', @Path='health/tooth.png', @Categories= 'health,tooth'
GO
EXEC SaveEmoji @Name='toothbrush', @Path='health/toothbrush.png', @Categories= 'health,toothbrush'
GO
EXEC SaveEmoji @Name='1st-place-medal', @Path='misc/1st-place-medal.png', @Categories= '1st,medal,misc,place'
GO
EXEC SaveEmoji @Name='2nd-place-medal', @Path='misc/2nd-place-medal.png', @Categories= '2nd,medal,misc,place'
GO
EXEC SaveEmoji @Name='3rd-place-medal', @Path='misc/3rd-place-medal.png', @Categories= '3rd,medal,misc,place'
GO
EXEC SaveEmoji @Name='abacus', @Path='misc/abacus.png', @Categories= 'abacus,misc'
GO
EXEC SaveEmoji @Name='admission-tickets', @Path='misc/admission-tickets.png', @Categories= 'admission,misc,tickets'
GO
EXEC SaveEmoji @Name='amphora', @Path='misc/amphora.png', @Categories= 'amphora,misc'
GO
EXEC SaveEmoji @Name='anchor', @Path='misc/anchor.png', @Categories= 'anchor,misc'
GO
EXEC SaveEmoji @Name='axe', @Path='misc/axe.png', @Categories= 'axe,misc'
GO
EXEC SaveEmoji @Name='balance-scale', @Path='misc/balance-scale.png', @Categories= 'balance,misc,scale'
GO
EXEC SaveEmoji @Name='balloon', @Path='misc/balloon.png', @Categories= 'balloon,misc'
GO
EXEC SaveEmoji @Name='ballot-box-with-ballot', @Path='misc/ballot-box-with-ballot.png', @Categories= 'ballot,box,misc,with'
GO
EXEC SaveEmoji @Name='bar-chart', @Path='misc/bar-chart.png', @Categories= 'bar,chart,misc'
GO
EXEC SaveEmoji @Name='basket', @Path='misc/basket.png', @Categories= 'basket,misc'
GO
EXEC SaveEmoji @Name='black-nib', @Path='misc/black-nib.png', @Categories= 'black,misc,nib'
GO
EXEC SaveEmoji @Name='blue-book', @Path='misc/blue-book.png', @Categories= 'blue,book,misc'
GO
EXEC SaveEmoji @Name='bomb', @Path='misc/bomb.png', @Categories= 'bomb,misc'
GO
EXEC SaveEmoji @Name='bone', @Path='misc/bone.png', @Categories= 'bone,misc'
GO
EXEC SaveEmoji @Name='bookmark-tabs', @Path='misc/bookmark-tabs.png', @Categories= 'bookmark,misc,tabs'
GO
EXEC SaveEmoji @Name='bookmark', @Path='misc/bookmark.png', @Categories= 'bookmark,misc'
GO
EXEC SaveEmoji @Name='books', @Path='misc/books.png', @Categories= 'books,misc'
GO
EXEC SaveEmoji @Name='brick', @Path='misc/brick.png', @Categories= 'brick,misc'
GO
EXEC SaveEmoji @Name='broom', @Path='misc/broom.png', @Categories= 'broom,misc'
GO
EXEC SaveEmoji @Name='bubbles', @Path='misc/bubbles.png', @Categories= 'bubbles,misc'
GO
EXEC SaveEmoji @Name='bucket', @Path='misc/bucket.png', @Categories= 'bucket,misc'
GO
EXEC SaveEmoji @Name='building-construction', @Path='misc/building-construction.png', @Categories= 'building,construction,misc'
GO
EXEC SaveEmoji @Name='candle', @Path='misc/candle.png', @Categories= 'candle,misc'
GO
EXEC SaveEmoji @Name='carpentry-saw', @Path='misc/carpentry-saw.png', @Categories= 'carpentry,misc,saw'
GO
EXEC SaveEmoji @Name='chains', @Path='misc/chains.png', @Categories= 'chains,misc'
GO
EXEC SaveEmoji @Name='chair', @Path='misc/chair.png', @Categories= 'chair,misc'
GO
EXEC SaveEmoji @Name='chart-decreasing', @Path='misc/chart-decreasing.png', @Categories= 'chart,decreasing,misc'
GO
EXEC SaveEmoji @Name='chart-increasing', @Path='misc/chart-increasing.png', @Categories= 'chart,increasing,misc'
GO
EXEC SaveEmoji @Name='chess-pawn', @Path='misc/chess-pawn.png', @Categories= 'chess,misc,pawn'
GO
EXEC SaveEmoji @Name='children-crossing', @Path='misc/children-crossing.png', @Categories= 'children,crossing,misc'
GO
EXEC SaveEmoji @Name='cigarette', @Path='misc/cigarette.png', @Categories= 'cigarette,misc'
GO
EXEC SaveEmoji @Name='circus-tent', @Path='misc/circus-tent.png', @Categories= 'circus,misc,tent'
GO
EXEC SaveEmoji @Name='clamp', @Path='misc/clamp.png', @Categories= 'clamp,misc'
GO
EXEC SaveEmoji @Name='clapper-board', @Path='misc/clapper-board.png', @Categories= 'board,clapper,misc'
GO
EXEC SaveEmoji @Name='clipboard', @Path='misc/clipboard.png', @Categories= 'clipboard,misc'
GO
EXEC SaveEmoji @Name='closed-book', @Path='misc/closed-book.png', @Categories= 'book,closed,misc'
GO
EXEC SaveEmoji @Name='closed-mailbox-with-lowered-flag', @Path='misc/closed-mailbox-with-lowered-flag.png', @Categories= 'closed,flag,lowered,mailbox,misc,with'
GO
EXEC SaveEmoji @Name='closed-mailbox-with-raised-flag', @Path='misc/closed-mailbox-with-raised-flag.png', @Categories= 'closed,flag,mailbox,misc,raised,with'
GO
EXEC SaveEmoji @Name='coin', @Path='misc/coin.png', @Categories= 'coin,misc'
GO
EXEC SaveEmoji @Name='confetti-ball', @Path='misc/confetti-ball.png', @Categories= 'ball,confetti,misc'
GO
EXEC SaveEmoji @Name='construction', @Path='misc/construction.png', @Categories= 'construction,misc'
GO
EXEC SaveEmoji @Name='couch-and-lamp', @Path='misc/couch-and-lamp.png', @Categories= 'and,couch,lamp,misc'
GO
EXEC SaveEmoji @Name='crayon', @Path='misc/crayon.png', @Categories= 'crayon,misc'
GO
EXEC SaveEmoji @Name='cricket-game', @Path='misc/cricket-game.png', @Categories= 'cricket,game,misc'
GO
EXEC SaveEmoji @Name='crown', @Path='misc/crown.png', @Categories= 'crown,misc'
GO
EXEC SaveEmoji @Name='crutch', @Path='misc/crutch.png', @Categories= 'crutch,misc'
GO
EXEC SaveEmoji @Name='diamond-with-a-dot', @Path='misc/diamond-with-a-dot.png', @Categories= 'a,diamond,dot,misc,with'
GO
EXEC SaveEmoji @Name='direct-hit', @Path='misc/direct-hit.png', @Categories= 'direct,hit,misc'
GO
EXEC SaveEmoji @Name='diya-lamp', @Path='misc/diya-lamp.png', @Categories= 'diya,lamp,misc'
GO
EXEC SaveEmoji @Name='dizzy', @Path='misc/dizzy.png', @Categories= 'dizzy,misc'
GO
EXEC SaveEmoji @Name='dollar-banknote', @Path='misc/dollar-banknote.png', @Categories= 'banknote,dollar,misc'
GO
EXEC SaveEmoji @Name='door', @Path='misc/door.png', @Categories= 'door,misc'
GO
EXEC SaveEmoji @Name='envelope', @Path='misc/envelope.png', @Categories= 'envelope,misc'
GO
EXEC SaveEmoji @Name='euro-banknote', @Path='misc/euro-banknote.png', @Categories= 'banknote,euro,misc'
GO
EXEC SaveEmoji @Name='file-cabinet', @Path='misc/file-cabinet.png', @Categories= 'cabinet,file,misc'
GO
EXEC SaveEmoji @Name='file-folder', @Path='misc/file-folder.png', @Categories= 'file,folder,misc'
GO
EXEC SaveEmoji @Name='fire-extinguisher', @Path='misc/fire-extinguisher.png', @Categories= 'extinguisher,fire,misc'
GO
EXEC SaveEmoji @Name='firecracker', @Path='misc/firecracker.png', @Categories= 'firecracker,misc'
GO
EXEC SaveEmoji @Name='fireworks', @Path='misc/fireworks.png', @Categories= 'fireworks,misc'
GO
EXEC SaveEmoji @Name='fleur-de-lis', @Path='misc/fleur-de-lis.png', @Categories= 'de,fleur,lis,misc'
GO
EXEC SaveEmoji @Name='flying-saucer', @Path='misc/flying-saucer.png', @Categories= 'flying,misc,saucer'
GO
EXEC SaveEmoji @Name='footprints', @Path='misc/footprints.png', @Categories= 'footprints,misc'
GO
EXEC SaveEmoji @Name='fountain', @Path='misc/fountain.png', @Categories= 'fountain,misc'
GO
EXEC SaveEmoji @Name='framed-picture', @Path='misc/framed-picture.png', @Categories= 'framed,misc,picture'
GO
EXEC SaveEmoji @Name='gem-stone', @Path='misc/gem-stone.png', @Categories= 'gem,misc,stone'
GO
EXEC SaveEmoji @Name='goal-net', @Path='misc/goal-net.png', @Categories= 'goal,misc,net'
GO
EXEC SaveEmoji @Name='green-book', @Path='misc/green-book.png', @Categories= 'book,green,misc'
GO
EXEC SaveEmoji @Name='headstone', @Path='misc/headstone.png', @Categories= 'headstone,misc'
GO
EXEC SaveEmoji @Name='hole', @Path='misc/hole.png', @Categories= 'hole,misc'
GO
EXEC SaveEmoji @Name='honey-pot', @Path='misc/honey-pot.png', @Categories= 'honey,misc,pot'
GO
EXEC SaveEmoji @Name='hook', @Path='misc/hook.png', @Categories= 'hook,misc'
GO
EXEC SaveEmoji @Name='identification-card', @Path='misc/identification-card.png', @Categories= 'card,identification,misc'
GO
EXEC SaveEmoji @Name='inbox-tray', @Path='misc/inbox-tray.png', @Categories= 'inbox,misc,tray'
GO
EXEC SaveEmoji @Name='incoming-envelope', @Path='misc/incoming-envelope.png', @Categories= 'envelope,incoming,misc'
GO
EXEC SaveEmoji @Name='japanese-dolls', @Path='misc/japanese-dolls.png', @Categories= 'dolls,japanese,misc'
GO
EXEC SaveEmoji @Name='jar', @Path='misc/jar.png', @Categories= 'jar,misc'
GO
EXEC SaveEmoji @Name='joker', @Path='misc/joker.png', @Categories= 'joker,misc'
GO
EXEC SaveEmoji @Name='key', @Path='misc/key.png', @Categories= 'key,misc'
GO
EXEC SaveEmoji @Name='keyboard', @Path='misc/keyboard.png', @Categories= 'keyboard,misc'
GO
EXEC SaveEmoji @Name='kiss-mark', @Path='misc/kiss-mark.png', @Categories= 'kiss,mark,misc'
GO
EXEC SaveEmoji @Name='kitchen-knife', @Path='misc/kitchen-knife.png', @Categories= 'kitchen,knife,misc'
GO
EXEC SaveEmoji @Name='knot', @Path='misc/knot.png', @Categories= 'knot,misc'
GO
EXEC SaveEmoji @Name='label', @Path='misc/label.png', @Categories= 'label,misc'
GO
EXEC SaveEmoji @Name='ladder', @Path='misc/ladder.png', @Categories= 'ladder,misc'
GO
EXEC SaveEmoji @Name='ledger', @Path='misc/ledger.png', @Categories= 'ledger,misc'
GO
EXEC SaveEmoji @Name='left-speech-bubble', @Path='misc/left-speech-bubble.png', @Categories= 'bubble,left,misc,speech'
GO
EXEC SaveEmoji @Name='link', @Path='misc/link.png', @Categories= 'link,misc'
GO
EXEC SaveEmoji @Name='linked-paperclips', @Path='misc/linked-paperclips.png', @Categories= 'linked,misc,paperclips'
GO
EXEC SaveEmoji @Name='locked-with-key', @Path='misc/locked-with-key.png', @Categories= 'key,locked,misc,with'
GO
EXEC SaveEmoji @Name='locked-with-pen', @Path='misc/locked-with-pen.png', @Categories= 'locked,misc,pen,with'
GO
EXEC SaveEmoji @Name='locked', @Path='misc/locked.png', @Categories= 'locked,misc'
GO
EXEC SaveEmoji @Name='long-drum', @Path='misc/long-drum.png', @Categories= 'drum,long,misc'
GO
EXEC SaveEmoji @Name='lotion-bottle', @Path='misc/lotion-bottle.png', @Categories= 'bottle,lotion,misc'
GO
EXEC SaveEmoji @Name='love-letter', @Path='misc/love-letter.png', @Categories= 'letter,love,misc'
GO
EXEC SaveEmoji @Name='magic-wand', @Path='misc/magic-wand.png', @Categories= 'magic,misc,wand'
GO
EXEC SaveEmoji @Name='magnet', @Path='misc/magnet.png', @Categories= 'magnet,misc'
GO
EXEC SaveEmoji @Name='magnifying-glass-tilted-left', @Path='misc/magnifying-glass-tilted-left.png', @Categories= 'glass,left,magnifying,misc,tilted'
GO
EXEC SaveEmoji @Name='magnifying-glass-tilted-right', @Path='misc/magnifying-glass-tilted-right.png', @Categories= 'glass,magnifying,misc,right,tilted'
GO
EXEC SaveEmoji @Name='megaphone', @Path='misc/megaphone.png', @Categories= 'megaphone,misc'
GO
EXEC SaveEmoji @Name='memo', @Path='misc/memo.png', @Categories= 'memo,misc'
GO
EXEC SaveEmoji @Name='military-medal', @Path='misc/military-medal.png', @Categories= 'medal,military,misc'
GO
EXEC SaveEmoji @Name='mirror-ball', @Path='misc/mirror-ball.png', @Categories= 'ball,mirror,misc'
GO
EXEC SaveEmoji @Name='mirror', @Path='misc/mirror.png', @Categories= 'mirror,misc'
GO
EXEC SaveEmoji @Name='moai', @Path='misc/moai.png', @Categories= 'misc,moai'
GO
EXEC SaveEmoji @Name='money-bag', @Path='misc/money-bag.png', @Categories= 'bag,misc,money'
GO
EXEC SaveEmoji @Name='money-with-wings', @Path='misc/money-with-wings.png', @Categories= 'misc,money,wings,with'
GO
EXEC SaveEmoji @Name='mouse-trap', @Path='misc/mouse-trap.png', @Categories= 'misc,mouse,trap'
GO
EXEC SaveEmoji @Name='nazar-amulet', @Path='misc/nazar-amulet.png', @Categories= 'amulet,misc,nazar'
GO
EXEC SaveEmoji @Name='nesting-dolls', @Path='misc/nesting-dolls.png', @Categories= 'dolls,misc,nesting'
GO
EXEC SaveEmoji @Name='newspaper', @Path='misc/newspaper.png', @Categories= 'misc,newspaper'
GO
EXEC SaveEmoji @Name='nut-and-bolt', @Path='misc/nut-and-bolt.png', @Categories= 'and,bolt,misc,nut'
GO
EXEC SaveEmoji @Name='oil-drum', @Path='misc/oil-drum.png', @Categories= 'drum,misc,oil'
GO
EXEC SaveEmoji @Name='old-key', @Path='misc/old-key.png', @Categories= 'key,misc,old'
GO
EXEC SaveEmoji @Name='open-file-folder', @Path='misc/open-file-folder.png', @Categories= 'file,folder,misc,open'
GO
EXEC SaveEmoji @Name='outbox-tray', @Path='misc/outbox-tray.png', @Categories= 'misc,outbox,tray'
GO
EXEC SaveEmoji @Name='package', @Path='misc/package.png', @Categories= 'misc,package'
GO
EXEC SaveEmoji @Name='paperclip', @Path='misc/paperclip.png', @Categories= 'misc,paperclip'
GO
EXEC SaveEmoji @Name='part-alternation-mark', @Path='misc/part-alternation-mark.png', @Categories= 'alternation,mark,misc,part'
GO
EXEC SaveEmoji @Name='party-popper', @Path='misc/party-popper.png', @Categories= 'misc,party,popper'
GO
EXEC SaveEmoji @Name='paw-prints', @Path='misc/paw-prints.png', @Categories= 'misc,paw,prints'
GO
EXEC SaveEmoji @Name='pick', @Path='misc/pick.png', @Categories= 'misc,pick'
GO
EXEC SaveEmoji @Name='pistol', @Path='misc/pistol.png', @Categories= 'misc,pistol'
GO
EXEC SaveEmoji @Name='playground-slide', @Path='misc/playground-slide.png', @Categories= 'misc,playground,slide'
GO
EXEC SaveEmoji @Name='plunger', @Path='misc/plunger.png', @Categories= 'misc,plunger'
GO
EXEC SaveEmoji @Name='police-car-light', @Path='misc/police-car-light.png', @Categories= 'car,light,misc,police'
GO
EXEC SaveEmoji @Name='postbox', @Path='misc/postbox.png', @Categories= 'misc,postbox'
GO
EXEC SaveEmoji @Name='pound-banknote', @Path='misc/pound-banknote.png', @Categories= 'banknote,misc,pound'
GO
EXEC SaveEmoji @Name='pouring-liquid', @Path='misc/pouring-liquid.png', @Categories= 'liquid,misc,pouring'
GO
EXEC SaveEmoji @Name='puzzle-piece', @Path='misc/puzzle-piece.png', @Categories= 'misc,piece,puzzle'
GO
EXEC SaveEmoji @Name='receipt', @Path='misc/receipt.png', @Categories= 'misc,receipt'
GO
EXEC SaveEmoji @Name='red-envelope', @Path='misc/red-envelope.png', @Categories= 'envelope,misc,red'
GO
EXEC SaveEmoji @Name='red-paper-lantern', @Path='misc/red-paper-lantern.png', @Categories= 'lantern,misc,paper,red'
GO
EXEC SaveEmoji @Name='right-anger-bubble', @Path='misc/right-anger-bubble.png', @Categories= 'anger,bubble,misc,right'
GO
EXEC SaveEmoji @Name='ring-buoy', @Path='misc/ring-buoy.png', @Categories= 'buoy,misc,ring'
GO
EXEC SaveEmoji @Name='roll-of-paper', @Path='misc/roll-of-paper.png', @Categories= 'misc,of,paper,roll'
GO
EXEC SaveEmoji @Name='rolled-up-newspaper', @Path='misc/rolled-up-newspaper.png', @Categories= 'misc,newspaper,rolled,up'
GO
EXEC SaveEmoji @Name='round-pushpin', @Path='misc/round-pushpin.png', @Categories= 'misc,pushpin,round'
GO
EXEC SaveEmoji @Name='safety-pin', @Path='misc/safety-pin.png', @Categories= 'misc,pin,safety'
GO
EXEC SaveEmoji @Name='screwdriver', @Path='misc/screwdriver.png', @Categories= 'misc,screwdriver'
GO
EXEC SaveEmoji @Name='scroll', @Path='misc/scroll.png', @Categories= 'misc,scroll'
GO
EXEC SaveEmoji @Name='sewing-needle', @Path='misc/sewing-needle.png', @Categories= 'misc,needle,sewing'
GO
EXEC SaveEmoji @Name='shield', @Path='misc/shield.png', @Categories= 'misc,shield'
GO
EXEC SaveEmoji @Name='shinto-shrine', @Path='misc/shinto-shrine.png', @Categories= 'misc,shinto,shrine'
GO
EXEC SaveEmoji @Name='shopping-cart', @Path='misc/shopping-cart.png', @Categories= 'cart,misc,shopping'
GO
EXEC SaveEmoji @Name='slot-machine', @Path='misc/slot-machine.png', @Categories= 'machine,misc,slot'
GO
EXEC SaveEmoji @Name='sparkler', @Path='misc/sparkler.png', @Categories= 'misc,sparkler'
GO
EXEC SaveEmoji @Name='speech-balloon', @Path='misc/speech-balloon.png', @Categories= 'balloon,misc,speech'
GO
EXEC SaveEmoji @Name='spider-web', @Path='misc/spider-web.png', @Categories= 'misc,spider,web'
GO
EXEC SaveEmoji @Name='spiral-shell', @Path='misc/spiral-shell.png', @Categories= 'misc,shell,spiral'
GO
EXEC SaveEmoji @Name='statue-of-liberty', @Path='misc/statue-of-liberty.png', @Categories= 'liberty,misc,of,statue'
GO
EXEC SaveEmoji @Name='tear-off-calendar', @Path='misc/tear-off-calendar.png', @Categories= 'calendar,misc,off,tear'
GO
EXEC SaveEmoji @Name='thought-balloon', @Path='misc/thought-balloon.png', @Categories= 'balloon,misc,thought'
GO
EXEC SaveEmoji @Name='thread', @Path='misc/thread.png', @Categories= 'misc,thread'
GO
EXEC SaveEmoji @Name='ticket', @Path='misc/ticket.png', @Categories= 'misc,ticket'
GO
EXEC SaveEmoji @Name='tokyo-tower', @Path='misc/tokyo-tower.png', @Categories= 'misc,tokyo,tower'
GO
EXEC SaveEmoji @Name='trident-emblem', @Path='misc/trident-emblem.png', @Categories= 'emblem,misc,trident'
GO
EXEC SaveEmoji @Name='trophy', @Path='misc/trophy.png', @Categories= 'misc,trophy'
GO
EXEC SaveEmoji @Name='unlocked', @Path='misc/unlocked.png', @Categories= 'misc,unlocked'
GO
EXEC SaveEmoji @Name='wastebasket', @Path='misc/wastebasket.png', @Categories= 'misc,wastebasket'
GO
EXEC SaveEmoji @Name='wavy-dash', @Path='misc/wavy-dash.png', @Categories= 'dash,misc,wavy'
GO
EXEC SaveEmoji @Name='white-cane', @Path='misc/white-cane.png', @Categories= 'cane,misc,white'
GO
EXEC SaveEmoji @Name='window', @Path='misc/window.png', @Categories= 'misc,window'
GO
EXEC SaveEmoji @Name='wing', @Path='misc/wing.png', @Categories= 'misc,wing'
GO
EXEC SaveEmoji @Name='wrapped-gift', @Path='misc/wrapped-gift.png', @Categories= 'gift,misc,wrapped'
GO
EXEC SaveEmoji @Name='wrench', @Path='misc/wrench.png', @Categories= 'misc,wrench'
GO
EXEC SaveEmoji @Name='yarn', @Path='misc/yarn.png', @Categories= 'misc,yarn'
GO
EXEC SaveEmoji @Name='yen-banknote', @Path='misc/yen-banknote.png', @Categories= 'banknote,misc,yen'
GO
EXEC SaveEmoji @Name='beach-with-umbrella', @Path='nature/beach-with-umbrella.png', @Categories= 'beach,nature,umbrella,with'
GO
EXEC SaveEmoji @Name='blossom', @Path='nature/blossom.png', @Categories= 'blossom,nature'
GO
EXEC SaveEmoji @Name='bouquet', @Path='nature/bouquet.png', @Categories= 'bouquet,nature'
GO
EXEC SaveEmoji @Name='bridge-at-night', @Path='nature/bridge-at-night.png', @Categories= 'at,bridge,nature,night'
GO
EXEC SaveEmoji @Name='cactus', @Path='nature/cactus.png', @Categories= 'cactus,nature'
GO
EXEC SaveEmoji @Name='cherry-blossom', @Path='nature/cherry-blossom.png', @Categories= 'blossom,cherry,nature'
GO
EXEC SaveEmoji @Name='christmas-tree', @Path='nature/christmas-tree.png', @Categories= 'christmas,nature,tree'
GO
EXEC SaveEmoji @Name='cityscape-at-dusk', @Path='nature/cityscape-at-dusk.png', @Categories= 'at,cityscape,dusk,nature'
GO
EXEC SaveEmoji @Name='cityscape', @Path='nature/cityscape.png', @Categories= 'cityscape,nature'
GO
EXEC SaveEmoji @Name='closed-umbrella', @Path='nature/closed-umbrella.png', @Categories= 'closed,nature,umbrella'
GO
EXEC SaveEmoji @Name='cloud-with-lightning-and-rain', @Path='nature/cloud-with-lightning-and-rain.png', @Categories= 'and,cloud,lightning,nature,rain,with'
GO
EXEC SaveEmoji @Name='cloud-with-lightning', @Path='nature/cloud-with-lightning.png', @Categories= 'cloud,lightning,nature,with'
GO
EXEC SaveEmoji @Name='cloud-with-rain', @Path='nature/cloud-with-rain.png', @Categories= 'cloud,nature,rain,with'
GO
EXEC SaveEmoji @Name='cloud-with-snow', @Path='nature/cloud-with-snow.png', @Categories= 'cloud,nature,snow,with'
GO
EXEC SaveEmoji @Name='cloud', @Path='nature/cloud.png', @Categories= 'cloud,nature'
GO
EXEC SaveEmoji @Name='collision', @Path='nature/collision.png', @Categories= 'collision,nature'
GO
EXEC SaveEmoji @Name='comet', @Path='nature/comet.png', @Categories= 'comet,nature'
GO
EXEC SaveEmoji @Name='coral', @Path='nature/coral.png', @Categories= 'coral,nature'
GO
EXEC SaveEmoji @Name='crescent-moon', @Path='nature/crescent-moon.png', @Categories= 'crescent,moon,nature'
GO
EXEC SaveEmoji @Name='crystal-ball', @Path='nature/crystal-ball.png', @Categories= 'ball,crystal,nature'
GO
EXEC SaveEmoji @Name='dashing-away', @Path='nature/dashing-away.png', @Categories= 'away,dashing,nature'
GO
EXEC SaveEmoji @Name='deciduous-tree', @Path='nature/deciduous-tree.png', @Categories= 'deciduous,nature,tree'
GO
EXEC SaveEmoji @Name='desert-island', @Path='nature/desert-island.png', @Categories= 'desert,island,nature'
GO
EXEC SaveEmoji @Name='desert', @Path='nature/desert.png', @Categories= 'desert,nature'
GO
EXEC SaveEmoji @Name='droplet', @Path='nature/droplet.png', @Categories= 'droplet,nature'
GO
EXEC SaveEmoji @Name='empty-nest', @Path='nature/empty-nest.png', @Categories= 'empty,nature,nest'
GO
EXEC SaveEmoji @Name='evergreen-tree', @Path='nature/evergreen-tree.png', @Categories= 'evergreen,nature,tree'
GO
EXEC SaveEmoji @Name='fallen-leaf', @Path='nature/fallen-leaf.png', @Categories= 'fallen,leaf,nature'
GO
EXEC SaveEmoji @Name='feather', @Path='nature/feather.png', @Categories= 'feather,nature'
GO
EXEC SaveEmoji @Name='fire', @Path='nature/fire.png', @Categories= 'fire,nature'
GO
EXEC SaveEmoji @Name='first-quarter-moon', @Path='nature/first-quarter-moon.png', @Categories= 'first,moon,nature,quarter'
GO
EXEC SaveEmoji @Name='fog', @Path='nature/fog.png', @Categories= 'fog,nature'
GO
EXEC SaveEmoji @Name='foggy', @Path='nature/foggy.png', @Categories= 'foggy,nature'
GO
EXEC SaveEmoji @Name='four-leaf-clover', @Path='nature/four-leaf-clover.png', @Categories= 'clover,four,leaf,nature'
GO
EXEC SaveEmoji @Name='full-moon', @Path='nature/full-moon.png', @Categories= 'full,moon,nature'
GO
EXEC SaveEmoji @Name='globe-showing-americas', @Path='nature/globe-showing-americas.png', @Categories= 'americas,globe,nature,showing'
GO
EXEC SaveEmoji @Name='globe-showing-asia-australia', @Path='nature/globe-showing-asia-australia.png', @Categories= 'asia,australia,globe,nature,showing'
GO
EXEC SaveEmoji @Name='globe-showing-europe-africa', @Path='nature/globe-showing-europe-africa.png', @Categories= 'africa,europe,globe,nature,showing'
GO
EXEC SaveEmoji @Name='globe-with-meridians', @Path='nature/globe-with-meridians.png', @Categories= 'globe,meridians,nature,with'
GO
EXEC SaveEmoji @Name='herb', @Path='nature/herb.png', @Categories= 'herb,nature'
GO
EXEC SaveEmoji @Name='hibiscus', @Path='nature/hibiscus.png', @Categories= 'hibiscus,nature'
GO
EXEC SaveEmoji @Name='house-with-garden', @Path='nature/house-with-garden.png', @Categories= 'garden,house,nature,with'
GO
EXEC SaveEmoji @Name='hyacinth', @Path='nature/hyacinth.png', @Categories= 'hyacinth,nature'
GO
EXEC SaveEmoji @Name='jack-o-lantern', @Path='nature/jack-o-lantern.png', @Categories= 'jack,lantern,nature,o'
GO
EXEC SaveEmoji @Name='last-quarter-moon', @Path='nature/last-quarter-moon.png', @Categories= 'last,moon,nature,quarter'
GO
EXEC SaveEmoji @Name='lotus', @Path='nature/lotus.png', @Categories= 'lotus,nature'
GO
EXEC SaveEmoji @Name='map-of-japan', @Path='nature/map-of-japan.png', @Categories= 'japan,map,nature,of'
GO
EXEC SaveEmoji @Name='maple-leaf', @Path='nature/maple-leaf.png', @Categories= 'leaf,maple,nature'
GO
EXEC SaveEmoji @Name='microbe', @Path='nature/microbe.png', @Categories= 'microbe,nature'
GO
EXEC SaveEmoji @Name='milky-way', @Path='nature/milky-way.png', @Categories= 'milky,nature,way'
GO
EXEC SaveEmoji @Name='moon-viewing-ceremony', @Path='nature/moon-viewing-ceremony.png', @Categories= 'ceremony,moon,nature,viewing'
GO
EXEC SaveEmoji @Name='mount-fuji', @Path='nature/mount-fuji.png', @Categories= 'fuji,mount,nature'
GO
EXEC SaveEmoji @Name='mountain', @Path='nature/mountain.png', @Categories= 'mountain,nature'
GO
EXEC SaveEmoji @Name='national-park', @Path='nature/national-park.png', @Categories= 'national,nature,park'
GO
EXEC SaveEmoji @Name='nest-with-eggs', @Path='nature/nest-with-eggs.png', @Categories= 'eggs,nature,nest,with'
GO
EXEC SaveEmoji @Name='new-moon', @Path='nature/new-moon.png', @Categories= 'moon,nature,new'
GO
EXEC SaveEmoji @Name='night-with-stars', @Path='nature/night-with-stars.png', @Categories= 'nature,night,stars,with'
GO
EXEC SaveEmoji @Name='palm-tree', @Path='nature/palm-tree.png', @Categories= 'nature,palm,tree'
GO
EXEC SaveEmoji @Name='potted-plant', @Path='nature/potted-plant.png', @Categories= 'nature,plant,potted'
GO
EXEC SaveEmoji @Name='rainbow', @Path='nature/rainbow.png', @Categories= 'nature,rainbow'
GO
EXEC SaveEmoji @Name='ringed-planet', @Path='nature/ringed-planet.png', @Categories= 'nature,planet,ringed'
GO
EXEC SaveEmoji @Name='rock', @Path='nature/rock.png', @Categories= 'nature,rock'
GO
EXEC SaveEmoji @Name='rose', @Path='nature/rose.png', @Categories= 'nature,rose'
GO
EXEC SaveEmoji @Name='rosette', @Path='nature/rosette.png', @Categories= 'nature,rosette'
GO
EXEC SaveEmoji @Name='seedling', @Path='nature/seedling.png', @Categories= 'nature,seedling'
GO
EXEC SaveEmoji @Name='shamrock', @Path='nature/shamrock.png', @Categories= 'nature,shamrock'
GO
EXEC SaveEmoji @Name='shooting-star', @Path='nature/shooting-star.png', @Categories= 'nature,shooting,star'
GO
EXEC SaveEmoji @Name='snow-capped-mountain', @Path='nature/snow-capped-mountain.png', @Categories= 'capped,mountain,nature,snow'
GO
EXEC SaveEmoji @Name='snowflake', @Path='nature/snowflake.png', @Categories= 'nature,snowflake'
GO
EXEC SaveEmoji @Name='star', @Path='nature/star.png', @Categories= 'nature,star'
GO
EXEC SaveEmoji @Name='sun-behind-cloud', @Path='nature/sun-behind-cloud.png', @Categories= 'behind,cloud,nature,sun'
GO
EXEC SaveEmoji @Name='sun-behind-large-cloud', @Path='nature/sun-behind-large-cloud.png', @Categories= 'behind,cloud,large,nature,sun'
GO
EXEC SaveEmoji @Name='sun-behind-rain-cloud', @Path='nature/sun-behind-rain-cloud.png', @Categories= 'behind,cloud,nature,rain,sun'
GO
EXEC SaveEmoji @Name='sun-behind-small-cloud', @Path='nature/sun-behind-small-cloud.png', @Categories= 'behind,cloud,nature,small,sun'
GO
EXEC SaveEmoji @Name='sun', @Path='nature/sun.png', @Categories= 'nature,sun'
GO
EXEC SaveEmoji @Name='sunflower', @Path='nature/sunflower.png', @Categories= 'nature,sunflower'
GO
EXEC SaveEmoji @Name='sunrise-over-mountains', @Path='nature/sunrise-over-mountains.png', @Categories= 'mountains,nature,over,sunrise'
GO
EXEC SaveEmoji @Name='sunrise', @Path='nature/sunrise.png', @Categories= 'nature,sunrise'
GO
EXEC SaveEmoji @Name='sunset', @Path='nature/sunset.png', @Categories= 'nature,sunset'
GO
EXEC SaveEmoji @Name='sweat-droplets', @Path='nature/sweat-droplets.png', @Categories= 'droplets,nature,sweat'
GO
EXEC SaveEmoji @Name='tanabata-tree', @Path='nature/tanabata-tree.png', @Categories= 'nature,tanabata,tree'
GO
EXEC SaveEmoji @Name='tornado', @Path='nature/tornado.png', @Categories= 'nature,tornado'
GO
EXEC SaveEmoji @Name='tulip', @Path='nature/tulip.png', @Categories= 'nature,tulip'
GO
EXEC SaveEmoji @Name='umbrella-on-ground', @Path='nature/umbrella-on-ground.png', @Categories= 'ground,nature,on,umbrella'
GO
EXEC SaveEmoji @Name='umbrella-with-rain-drops', @Path='nature/umbrella-with-rain-drops.png', @Categories= 'drops,nature,rain,umbrella,with'
GO
EXEC SaveEmoji @Name='umbrella', @Path='nature/umbrella.png', @Categories= 'nature,umbrella'
GO
EXEC SaveEmoji @Name='volcano', @Path='nature/volcano.png', @Categories= 'nature,volcano'
GO
EXEC SaveEmoji @Name='waning-crescent-moon', @Path='nature/waning-crescent-moon.png', @Categories= 'crescent,moon,nature,waning'
GO
EXEC SaveEmoji @Name='waning-gibbous-moon', @Path='nature/waning-gibbous-moon.png', @Categories= 'gibbous,moon,nature,waning'
GO
EXEC SaveEmoji @Name='water-wave', @Path='nature/water-wave.png', @Categories= 'nature,water,wave'
GO
EXEC SaveEmoji @Name='waxing-crescent-moon', @Path='nature/waxing-crescent-moon.png', @Categories= 'crescent,moon,nature,waxing'
GO
EXEC SaveEmoji @Name='waxing-gibbous-moon', @Path='nature/waxing-gibbous-moon.png', @Categories= 'gibbous,moon,nature,waxing'
GO
EXEC SaveEmoji @Name='wilted-flower', @Path='nature/wilted-flower.png', @Categories= 'flower,nature,wilted'
GO
EXEC SaveEmoji @Name='wind-chime', @Path='nature/wind-chime.png', @Categories= 'chime,nature,wind'
GO
EXEC SaveEmoji @Name='wind-face', @Path='nature/wind-face.png', @Categories= 'face,nature,wind'
GO
EXEC SaveEmoji @Name='wood', @Path='nature/wood.png', @Categories= 'nature,wood'
GO
EXEC SaveEmoji @Name='world-map', @Path='nature/world-map.png', @Categories= 'map,nature,world'
GO
EXEC SaveEmoji @Name='artist', @Path='person/artist.png', @Categories= 'artist,person'
GO
EXEC SaveEmoji @Name='astronaut', @Path='person/astronaut.png', @Categories= 'astronaut,person'
GO
EXEC SaveEmoji @Name='baby-angel', @Path='person/baby-angel.png', @Categories= 'angel,baby,person'
GO
EXEC SaveEmoji @Name='baby', @Path='person/baby.png', @Categories= 'baby,person'
GO
EXEC SaveEmoji @Name='bald', @Path='person/bald.png', @Categories= 'bald,person'
GO
EXEC SaveEmoji @Name='boy', @Path='person/boy.png', @Categories= 'boy,person'
GO
EXEC SaveEmoji @Name='bust-in-silhouette', @Path='person/bust-in-silhouette.png', @Categories= 'bust,in,person,silhouette'
GO
EXEC SaveEmoji @Name='busts-in-silhouette', @Path='person/busts-in-silhouette.png', @Categories= 'busts,in,person,silhouette'
GO
EXEC SaveEmoji @Name='child', @Path='person/child.png', @Categories= 'child,person'
GO
EXEC SaveEmoji @Name='construction-worker', @Path='person/construction-worker.png', @Categories= 'construction,person,worker'
GO
EXEC SaveEmoji @Name='cook', @Path='person/cook.png', @Categories= 'cook,person'
GO
EXEC SaveEmoji @Name='curly-hair', @Path='person/curly-hair.png', @Categories= 'curly,hair,person'
GO
EXEC SaveEmoji @Name='deaf-man', @Path='person/deaf-man.png', @Categories= 'deaf,man,person'
GO
EXEC SaveEmoji @Name='deaf-person', @Path='person/deaf-person.png', @Categories= 'deaf,person'
GO
EXEC SaveEmoji @Name='deaf-woman', @Path='person/deaf-woman.png', @Categories= 'deaf,person,woman'
GO
EXEC SaveEmoji @Name='detective', @Path='person/detective.png', @Categories= 'detective,person'
GO
EXEC SaveEmoji @Name='elf', @Path='person/elf.png', @Categories= 'elf,person'
GO
EXEC SaveEmoji @Name='factory-worker', @Path='person/factory-worker.png', @Categories= 'factory,person,worker'
GO
EXEC SaveEmoji @Name='fairy', @Path='person/fairy.png', @Categories= 'fairy,person'
GO
EXEC SaveEmoji @Name='family-man-boy-boy', @Path='person/family-man-boy-boy.png', @Categories= 'boy,family,man,person'
GO
EXEC SaveEmoji @Name='family-man-boy', @Path='person/family-man-boy.png', @Categories= 'boy,family,man,person'
GO
EXEC SaveEmoji @Name='family-man-girl-boy', @Path='person/family-man-girl-boy.png', @Categories= 'boy,family,girl,man,person'
GO
EXEC SaveEmoji @Name='family-man-girl-girl', @Path='person/family-man-girl-girl.png', @Categories= 'family,girl,man,person'
GO
EXEC SaveEmoji @Name='family-man-girl', @Path='person/family-man-girl.png', @Categories= 'family,girl,man,person'
GO
EXEC SaveEmoji @Name='family-man-man-boy-boy', @Path='person/family-man-man-boy-boy.png', @Categories= 'boy,family,man,person'
GO
EXEC SaveEmoji @Name='family-man-man-boy', @Path='person/family-man-man-boy.png', @Categories= 'boy,family,man,person'
GO
EXEC SaveEmoji @Name='family-man-man-girl-boy', @Path='person/family-man-man-girl-boy.png', @Categories= 'boy,family,girl,man,person'
GO
EXEC SaveEmoji @Name='family-man-man-girl-girl', @Path='person/family-man-man-girl-girl.png', @Categories= 'family,girl,man,person'
GO
EXEC SaveEmoji @Name='family-man-man-girl', @Path='person/family-man-man-girl.png', @Categories= 'family,girl,man,person'
GO
EXEC SaveEmoji @Name='family-man-woman-boy-boy', @Path='person/family-man-woman-boy-boy.png', @Categories= 'boy,family,man,person,woman'
GO
EXEC SaveEmoji @Name='family-man-woman-boy', @Path='person/family-man-woman-boy.png', @Categories= 'boy,family,man,person,woman'
GO
EXEC SaveEmoji @Name='family-man-woman-girl-boy', @Path='person/family-man-woman-girl-boy.png', @Categories= 'boy,family,girl,man,person,woman'
GO
EXEC SaveEmoji @Name='family-man-woman-girl-girl', @Path='person/family-man-woman-girl-girl.png', @Categories= 'family,girl,man,person,woman'
GO
EXEC SaveEmoji @Name='family-man-woman-girl', @Path='person/family-man-woman-girl.png', @Categories= 'family,girl,man,person,woman'
GO
EXEC SaveEmoji @Name='family-woman-boy-boy', @Path='person/family-woman-boy-boy.png', @Categories= 'boy,family,person,woman'
GO
EXEC SaveEmoji @Name='family-woman-boy', @Path='person/family-woman-boy.png', @Categories= 'boy,family,person,woman'
GO
EXEC SaveEmoji @Name='family-woman-girl-boy', @Path='person/family-woman-girl-boy.png', @Categories= 'boy,family,girl,person,woman'
GO
EXEC SaveEmoji @Name='family-woman-girl-girl', @Path='person/family-woman-girl-girl.png', @Categories= 'family,girl,person,woman'
GO
EXEC SaveEmoji @Name='family-woman-girl', @Path='person/family-woman-girl.png', @Categories= 'family,girl,person,woman'
GO
EXEC SaveEmoji @Name='family-woman-woman-boy-boy', @Path='person/family-woman-woman-boy-boy.png', @Categories= 'boy,family,person,woman'
GO
EXEC SaveEmoji @Name='family-woman-woman-boy', @Path='person/family-woman-woman-boy.png', @Categories= 'boy,family,person,woman'
GO
EXEC SaveEmoji @Name='family-woman-woman-girl-boy', @Path='person/family-woman-woman-girl-boy.png', @Categories= 'boy,family,girl,person,woman'
GO
EXEC SaveEmoji @Name='family-woman-woman-girl-girl', @Path='person/family-woman-woman-girl-girl.png', @Categories= 'family,girl,person,woman'
GO
EXEC SaveEmoji @Name='family-woman-woman-girl', @Path='person/family-woman-woman-girl.png', @Categories= 'family,girl,person,woman'
GO
EXEC SaveEmoji @Name='family', @Path='person/family.png', @Categories= 'family,person'
GO
EXEC SaveEmoji @Name='farmer', @Path='person/farmer.png', @Categories= 'farmer,person'
GO
EXEC SaveEmoji @Name='firefighter', @Path='person/firefighter.png', @Categories= 'firefighter,person'
GO
EXEC SaveEmoji @Name='genie', @Path='person/genie.png', @Categories= 'genie,person'
GO
EXEC SaveEmoji @Name='girl', @Path='person/girl.png', @Categories= 'girl,person'
GO
EXEC SaveEmoji @Name='guard', @Path='person/guard.png', @Categories= 'guard,person'
GO
EXEC SaveEmoji @Name='health-worker', @Path='person/health-worker.png', @Categories= 'health,person,worker'
GO
EXEC SaveEmoji @Name='judge', @Path='person/judge.png', @Categories= 'judge,person'
GO
EXEC SaveEmoji @Name='kiss-man-man', @Path='person/kiss-man-man.png', @Categories= 'kiss,man,person'
GO
EXEC SaveEmoji @Name='kiss-man-person', @Path='person/kiss-man-person.png', @Categories= 'kiss,man,person'
GO
EXEC SaveEmoji @Name='kiss-man-woman', @Path='person/kiss-man-woman.png', @Categories= 'kiss,man,person,woman'
GO
EXEC SaveEmoji @Name='kiss-person-man', @Path='person/kiss-person-man.png', @Categories= 'kiss,man,person'
GO
EXEC SaveEmoji @Name='kiss-person-person', @Path='person/kiss-person-person.png', @Categories= 'kiss,person'
GO
EXEC SaveEmoji @Name='kiss-person-woman', @Path='person/kiss-person-woman.png', @Categories= 'kiss,person,woman'
GO
EXEC SaveEmoji @Name='kiss-woman-man', @Path='person/kiss-woman-man.png', @Categories= 'kiss,man,person,woman'
GO
EXEC SaveEmoji @Name='kiss-woman-person', @Path='person/kiss-woman-person.png', @Categories= 'kiss,person,woman'
GO
EXEC SaveEmoji @Name='kiss-woman-woman', @Path='person/kiss-woman-woman.png', @Categories= 'kiss,person,woman'
GO
EXEC SaveEmoji @Name='kiss', @Path='person/kiss.png', @Categories= 'kiss,person'
GO
EXEC SaveEmoji @Name='mage', @Path='person/mage.png', @Categories= 'mage,person'
GO
EXEC SaveEmoji @Name='man-artist', @Path='person/man-artist.png', @Categories= 'artist,man,person'
GO
EXEC SaveEmoji @Name='man-astronaut', @Path='person/man-astronaut.png', @Categories= 'astronaut,man,person'
GO
EXEC SaveEmoji @Name='man-bald', @Path='person/man-bald.png', @Categories= 'bald,man,person'
GO
EXEC SaveEmoji @Name='man-beard', @Path='person/man-beard.png', @Categories= 'beard,man,person'
GO
EXEC SaveEmoji @Name='man-blond-hair', @Path='person/man-blond-hair.png', @Categories= 'blond,hair,man,person'
GO
EXEC SaveEmoji @Name='man-bowing', @Path='person/man-bowing.png', @Categories= 'bowing,man,person'
GO
EXEC SaveEmoji @Name='man-construction-worker', @Path='person/man-construction-worker.png', @Categories= 'construction,man,person,worker'
GO
EXEC SaveEmoji @Name='man-cook', @Path='person/man-cook.png', @Categories= 'cook,man,person'
GO
EXEC SaveEmoji @Name='man-curly-hair', @Path='person/man-curly-hair.png', @Categories= 'curly,hair,man,person'
GO
EXEC SaveEmoji @Name='man-detective', @Path='person/man-detective.png', @Categories= 'detective,man,person'
GO
EXEC SaveEmoji @Name='man-elf', @Path='person/man-elf.png', @Categories= 'elf,man,person'
GO
EXEC SaveEmoji @Name='man-facepalming', @Path='person/man-facepalming.png', @Categories= 'facepalming,man,person'
GO
EXEC SaveEmoji @Name='man-factory-worker', @Path='person/man-factory-worker.png', @Categories= 'factory,man,person,worker'
GO
EXEC SaveEmoji @Name='man-fairy', @Path='person/man-fairy.png', @Categories= 'fairy,man,person'
GO
EXEC SaveEmoji @Name='man-farmer', @Path='person/man-farmer.png', @Categories= 'farmer,man,person'
GO
EXEC SaveEmoji @Name='man-feeding-baby', @Path='person/man-feeding-baby.png', @Categories= 'baby,feeding,man,person'
GO
EXEC SaveEmoji @Name='man-firefighter', @Path='person/man-firefighter.png', @Categories= 'firefighter,man,person'
GO
EXEC SaveEmoji @Name='man-frowning', @Path='person/man-frowning.png', @Categories= 'frowning,man,person'
GO
EXEC SaveEmoji @Name='man-genie', @Path='person/man-genie.png', @Categories= 'genie,man,person'
GO
EXEC SaveEmoji @Name='man-gesturing-no', @Path='person/man-gesturing-no.png', @Categories= 'gesturing,man,no,person'
GO
EXEC SaveEmoji @Name='man-gesturing-ok', @Path='person/man-gesturing-ok.png', @Categories= 'gesturing,man,ok,person'
GO
EXEC SaveEmoji @Name='man-getting-haircut', @Path='person/man-getting-haircut.png', @Categories= 'getting,haircut,man,person'
GO
EXEC SaveEmoji @Name='man-getting-massage', @Path='person/man-getting-massage.png', @Categories= 'getting,man,massage,person'
GO
EXEC SaveEmoji @Name='man-guard', @Path='person/man-guard.png', @Categories= 'guard,man,person'
GO
EXEC SaveEmoji @Name='man-health-worker', @Path='person/man-health-worker.png', @Categories= 'health,man,person,worker'
GO
EXEC SaveEmoji @Name='man-in-lotus-position', @Path='person/man-in-lotus-position.png', @Categories= 'in,lotus,man,person,position'
GO
EXEC SaveEmoji @Name='man-in-steamy-room', @Path='person/man-in-steamy-room.png', @Categories= 'in,man,person,room,steamy'
GO
EXEC SaveEmoji @Name='man-in-tuxedo', @Path='person/man-in-tuxedo.png', @Categories= 'in,man,person,tuxedo'
GO
EXEC SaveEmoji @Name='man-judge', @Path='person/man-judge.png', @Categories= 'judge,man,person'
GO
EXEC SaveEmoji @Name='man-juggling', @Path='person/man-juggling.png', @Categories= 'juggling,man,person'
GO
EXEC SaveEmoji @Name='man-mage', @Path='person/man-mage.png', @Categories= 'mage,man,person'
GO
EXEC SaveEmoji @Name='man-mechanic', @Path='person/man-mechanic.png', @Categories= 'man,mechanic,person'
GO
EXEC SaveEmoji @Name='man-mountain-biking', @Path='person/man-mountain-biking.png', @Categories= 'biking,man,mountain,person'
GO
EXEC SaveEmoji @Name='man-office-worker', @Path='person/man-office-worker.png', @Categories= 'man,office,person,worker'
GO
EXEC SaveEmoji @Name='man-pilot', @Path='person/man-pilot.png', @Categories= 'man,person,pilot'
GO
EXEC SaveEmoji @Name='man-police-officer', @Path='person/man-police-officer.png', @Categories= 'man,officer,person,police'
GO
EXEC SaveEmoji @Name='man-pouting', @Path='person/man-pouting.png', @Categories= 'man,person,pouting'
GO
EXEC SaveEmoji @Name='man-raising-hand', @Path='person/man-raising-hand.png', @Categories= 'hand,man,person,raising'
GO
EXEC SaveEmoji @Name='man-red-hair', @Path='person/man-red-hair.png', @Categories= 'hair,man,person,red'
GO
EXEC SaveEmoji @Name='man-scientist', @Path='person/man-scientist.png', @Categories= 'man,person,scientist'
GO
EXEC SaveEmoji @Name='man-shrugging', @Path='person/man-shrugging.png', @Categories= 'man,person,shrugging'
GO
EXEC SaveEmoji @Name='man-singer', @Path='person/man-singer.png', @Categories= 'man,person,singer'
GO
EXEC SaveEmoji @Name='man-student', @Path='person/man-student.png', @Categories= 'man,person,student'
GO
EXEC SaveEmoji @Name='man-superhero', @Path='person/man-superhero.png', @Categories= 'man,person,superhero'
GO
EXEC SaveEmoji @Name='man-supervillain', @Path='person/man-supervillain.png', @Categories= 'man,person,supervillain'
GO
EXEC SaveEmoji @Name='man-teacher', @Path='person/man-teacher.png', @Categories= 'man,person,teacher'
GO
EXEC SaveEmoji @Name='man-technologist', @Path='person/man-technologist.png', @Categories= 'man,person,technologist'
GO
EXEC SaveEmoji @Name='man-tipping-hand', @Path='person/man-tipping-hand.png', @Categories= 'hand,man,person,tipping'
GO
EXEC SaveEmoji @Name='man-vampire', @Path='person/man-vampire.png', @Categories= 'man,person,vampire'
GO
EXEC SaveEmoji @Name='man-wearing-turban', @Path='person/man-wearing-turban.png', @Categories= 'man,person,turban,wearing'
GO
EXEC SaveEmoji @Name='man-white-hair', @Path='person/man-white-hair.png', @Categories= 'hair,man,person,white'
GO
EXEC SaveEmoji @Name='man-with-veil', @Path='person/man-with-veil.png', @Categories= 'man,person,veil,with'
GO
EXEC SaveEmoji @Name='man-zombie', @Path='person/man-zombie.png', @Categories= 'man,person,zombie'
GO
EXEC SaveEmoji @Name='man', @Path='person/man.png', @Categories= 'man,person'
GO
EXEC SaveEmoji @Name='mechanic', @Path='person/mechanic.png', @Categories= 'mechanic,person'
GO
EXEC SaveEmoji @Name='men-holding-hands', @Path='person/men-holding-hands.png', @Categories= 'hands,holding,men,person'
GO
EXEC SaveEmoji @Name='men-with-bunny-ears', @Path='person/men-with-bunny-ears.png', @Categories= 'bunny,ears,men,person,with'
GO
EXEC SaveEmoji @Name='mermaid', @Path='person/mermaid.png', @Categories= 'mermaid,person'
GO
EXEC SaveEmoji @Name='merman', @Path='person/merman.png', @Categories= 'merman,person'
GO
EXEC SaveEmoji @Name='merperson', @Path='person/merperson.png', @Categories= 'merperson,person'
GO
EXEC SaveEmoji @Name='mrs-claus', @Path='person/mrs-claus.png', @Categories= 'claus,mrs,person'
GO
EXEC SaveEmoji @Name='mx-claus', @Path='person/mx-claus.png', @Categories= 'claus,mx,person'
GO
EXEC SaveEmoji @Name='ninja', @Path='person/ninja.png', @Categories= 'ninja,person'
GO
EXEC SaveEmoji @Name='office-worker', @Path='person/office-worker.png', @Categories= 'office,person,worker'
GO
EXEC SaveEmoji @Name='old-man', @Path='person/old-man.png', @Categories= 'man,old,person'
GO
EXEC SaveEmoji @Name='old-woman', @Path='person/old-woman.png', @Categories= 'old,person,woman'
GO
EXEC SaveEmoji @Name='older-person', @Path='person/older-person.png', @Categories= 'older,person'
GO
EXEC SaveEmoji @Name='people-hugging', @Path='person/people-hugging.png', @Categories= 'hugging,people,person'
GO
EXEC SaveEmoji @Name='person-bald', @Path='person/person-bald.png', @Categories= 'bald,person'
GO
EXEC SaveEmoji @Name='person-beard', @Path='person/person-beard.png', @Categories= 'beard,person'
GO
EXEC SaveEmoji @Name='person-blond-hair', @Path='person/person-blond-hair.png', @Categories= 'blond,hair,person'
GO
EXEC SaveEmoji @Name='person-bowing', @Path='person/person-bowing.png', @Categories= 'bowing,person'
GO
EXEC SaveEmoji @Name='person-curly-hair', @Path='person/person-curly-hair.png', @Categories= 'curly,hair,person'
GO
EXEC SaveEmoji @Name='person-facepalming', @Path='person/person-facepalming.png', @Categories= 'facepalming,person'
GO
EXEC SaveEmoji @Name='person-frowning', @Path='person/person-frowning.png', @Categories= 'frowning,person'
GO
EXEC SaveEmoji @Name='person-gesturing-no', @Path='person/person-gesturing-no.png', @Categories= 'gesturing,no,person'
GO
EXEC SaveEmoji @Name='person-gesturing-ok', @Path='person/person-gesturing-ok.png', @Categories= 'gesturing,ok,person'
GO
EXEC SaveEmoji @Name='person-getting-haircut', @Path='person/person-getting-haircut.png', @Categories= 'getting,haircut,person'
GO
EXEC SaveEmoji @Name='person-getting-massage', @Path='person/person-getting-massage.png', @Categories= 'getting,massage,person'
GO
EXEC SaveEmoji @Name='person-in-steamy-room', @Path='person/person-in-steamy-room.png', @Categories= 'in,person,room,steamy'
GO
EXEC SaveEmoji @Name='person-in-tuxedo', @Path='person/person-in-tuxedo.png', @Categories= 'in,person,tuxedo'
GO
EXEC SaveEmoji @Name='person-pouting', @Path='person/person-pouting.png', @Categories= 'person,pouting'
GO
EXEC SaveEmoji @Name='person-raising-hand', @Path='person/person-raising-hand.png', @Categories= 'hand,person,raising'
GO
EXEC SaveEmoji @Name='person-red-hair', @Path='person/person-red-hair.png', @Categories= 'hair,person,red'
GO
EXEC SaveEmoji @Name='person-shrugging', @Path='person/person-shrugging.png', @Categories= 'person,shrugging'
GO
EXEC SaveEmoji @Name='person-tipping-hand', @Path='person/person-tipping-hand.png', @Categories= 'hand,person,tipping'
GO
EXEC SaveEmoji @Name='person-wearing-turban', @Path='person/person-wearing-turban.png', @Categories= 'person,turban,wearing'
GO
EXEC SaveEmoji @Name='person-white-hair', @Path='person/person-white-hair.png', @Categories= 'hair,person,white'
GO
EXEC SaveEmoji @Name='person-with-crown', @Path='person/person-with-crown.png', @Categories= 'crown,person,with'
GO
EXEC SaveEmoji @Name='person-with-headscarf', @Path='person/person-with-headscarf.png', @Categories= 'headscarf,person,with'
GO
EXEC SaveEmoji @Name='person-with-skullcap', @Path='person/person-with-skullcap.png', @Categories= 'person,skullcap,with'
GO
EXEC SaveEmoji @Name='person-with-veil', @Path='person/person-with-veil.png', @Categories= 'person,veil,with'
GO
EXEC SaveEmoji @Name='person', @Path='person/person.png', @Categories= 'person'
GO
EXEC SaveEmoji @Name='pilot', @Path='person/pilot.png', @Categories= 'person,pilot'
GO
EXEC SaveEmoji @Name='police-officer', @Path='person/police-officer.png', @Categories= 'officer,person,police'
GO
EXEC SaveEmoji @Name='pregnant-man', @Path='person/pregnant-man.png', @Categories= 'man,person,pregnant'
GO
EXEC SaveEmoji @Name='pregnant-person', @Path='person/pregnant-person.png', @Categories= 'person,pregnant'
GO
EXEC SaveEmoji @Name='pregnant-woman', @Path='person/pregnant-woman.png', @Categories= 'person,pregnant,woman'
GO
EXEC SaveEmoji @Name='prince', @Path='person/prince.png', @Categories= 'person,prince'
GO
EXEC SaveEmoji @Name='princess', @Path='person/princess.png', @Categories= 'person,princess'
GO
EXEC SaveEmoji @Name='red-hair', @Path='person/red-hair.png', @Categories= 'hair,person,red'
GO
EXEC SaveEmoji @Name='santa-claus', @Path='person/santa-claus.png', @Categories= 'claus,person,santa'
GO
EXEC SaveEmoji @Name='scientist', @Path='person/scientist.png', @Categories= 'person,scientist'
GO
EXEC SaveEmoji @Name='singer', @Path='person/singer.png', @Categories= 'person,singer'
GO
EXEC SaveEmoji @Name='snowman-without-snow', @Path='person/snowman-without-snow.png', @Categories= 'person,snow,snowman,without'
GO
EXEC SaveEmoji @Name='snowman', @Path='person/snowman.png', @Categories= 'person,snowman'
GO
EXEC SaveEmoji @Name='student', @Path='person/student.png', @Categories= 'person,student'
GO
EXEC SaveEmoji @Name='superhero', @Path='person/superhero.png', @Categories= 'person,superhero'
GO
EXEC SaveEmoji @Name='supervillain', @Path='person/supervillain.png', @Categories= 'person,supervillain'
GO
EXEC SaveEmoji @Name='teacher', @Path='person/teacher.png', @Categories= 'person,teacher'
GO
EXEC SaveEmoji @Name='technologist', @Path='person/technologist.png', @Categories= 'person,technologist'
GO
EXEC SaveEmoji @Name='troll', @Path='person/troll.png', @Categories= 'person,troll'
GO
EXEC SaveEmoji @Name='vampire', @Path='person/vampire.png', @Categories= 'person,vampire'
GO
EXEC SaveEmoji @Name='white-hair', @Path='person/white-hair.png', @Categories= 'hair,person,white'
GO
EXEC SaveEmoji @Name='woman-and-man-holding-hands', @Path='person/woman-and-man-holding-hands.png', @Categories= 'and,hands,holding,man,person,woman'
GO
EXEC SaveEmoji @Name='woman-artist', @Path='person/woman-artist.png', @Categories= 'artist,person,woman'
GO
EXEC SaveEmoji @Name='woman-astronaut', @Path='person/woman-astronaut.png', @Categories= 'astronaut,person,woman'
GO
EXEC SaveEmoji @Name='woman-bald', @Path='person/woman-bald.png', @Categories= 'bald,person,woman'
GO
EXEC SaveEmoji @Name='woman-beard', @Path='person/woman-beard.png', @Categories= 'beard,person,woman'
GO
EXEC SaveEmoji @Name='woman-blond-hair', @Path='person/woman-blond-hair.png', @Categories= 'blond,hair,person,woman'
GO
EXEC SaveEmoji @Name='woman-bowing', @Path='person/woman-bowing.png', @Categories= 'bowing,person,woman'
GO
EXEC SaveEmoji @Name='woman-construction-worker', @Path='person/woman-construction-worker.png', @Categories= 'construction,person,woman,worker'
GO
EXEC SaveEmoji @Name='woman-cook', @Path='person/woman-cook.png', @Categories= 'cook,person,woman'
GO
EXEC SaveEmoji @Name='woman-curly-hair', @Path='person/woman-curly-hair.png', @Categories= 'curly,hair,person,woman'
GO
EXEC SaveEmoji @Name='woman-detective', @Path='person/woman-detective.png', @Categories= 'detective,person,woman'
GO
EXEC SaveEmoji @Name='woman-elf', @Path='person/woman-elf.png', @Categories= 'elf,person,woman'
GO
EXEC SaveEmoji @Name='woman-facepalming', @Path='person/woman-facepalming.png', @Categories= 'facepalming,person,woman'
GO
EXEC SaveEmoji @Name='woman-factory-worker', @Path='person/woman-factory-worker.png', @Categories= 'factory,person,woman,worker'
GO
EXEC SaveEmoji @Name='woman-fairy', @Path='person/woman-fairy.png', @Categories= 'fairy,person,woman'
GO
EXEC SaveEmoji @Name='woman-farmer', @Path='person/woman-farmer.png', @Categories= 'farmer,person,woman'
GO
EXEC SaveEmoji @Name='woman-feeding-baby', @Path='person/woman-feeding-baby.png', @Categories= 'baby,feeding,person,woman'
GO
EXEC SaveEmoji @Name='woman-firefighter', @Path='person/woman-firefighter.png', @Categories= 'firefighter,person,woman'
GO
EXEC SaveEmoji @Name='woman-frowning', @Path='person/woman-frowning.png', @Categories= 'frowning,person,woman'
GO
EXEC SaveEmoji @Name='woman-genie', @Path='person/woman-genie.png', @Categories= 'genie,person,woman'
GO
EXEC SaveEmoji @Name='woman-gesturing-no', @Path='person/woman-gesturing-no.png', @Categories= 'gesturing,no,person,woman'
GO
EXEC SaveEmoji @Name='woman-gesturing-ok', @Path='person/woman-gesturing-ok.png', @Categories= 'gesturing,ok,person,woman'
GO
EXEC SaveEmoji @Name='woman-getting-haircut', @Path='person/woman-getting-haircut.png', @Categories= 'getting,haircut,person,woman'
GO
EXEC SaveEmoji @Name='woman-getting-massage', @Path='person/woman-getting-massage.png', @Categories= 'getting,massage,person,woman'
GO
EXEC SaveEmoji @Name='woman-guard', @Path='person/woman-guard.png', @Categories= 'guard,person,woman'
GO
EXEC SaveEmoji @Name='woman-health-worker', @Path='person/woman-health-worker.png', @Categories= 'health,person,woman,worker'
GO
EXEC SaveEmoji @Name='woman-in-steamy-room', @Path='person/woman-in-steamy-room.png', @Categories= 'in,person,room,steamy,woman'
GO
EXEC SaveEmoji @Name='woman-in-tuxedo', @Path='person/woman-in-tuxedo.png', @Categories= 'in,person,tuxedo,woman'
GO
EXEC SaveEmoji @Name='woman-judge', @Path='person/woman-judge.png', @Categories= 'judge,person,woman'
GO
EXEC SaveEmoji @Name='woman-mage', @Path='person/woman-mage.png', @Categories= 'mage,person,woman'
GO
EXEC SaveEmoji @Name='woman-mechanic', @Path='person/woman-mechanic.png', @Categories= 'mechanic,person,woman'
GO
EXEC SaveEmoji @Name='woman-office-worker', @Path='person/woman-office-worker.png', @Categories= 'office,person,woman,worker'
GO
EXEC SaveEmoji @Name='woman-pilot', @Path='person/woman-pilot.png', @Categories= 'person,pilot,woman'
GO
EXEC SaveEmoji @Name='woman-police-officer', @Path='person/woman-police-officer.png', @Categories= 'officer,person,police,woman'
GO
EXEC SaveEmoji @Name='woman-pouting', @Path='person/woman-pouting.png', @Categories= 'person,pouting,woman'
GO
EXEC SaveEmoji @Name='woman-raising-hand', @Path='person/woman-raising-hand.png', @Categories= 'hand,person,raising,woman'
GO
EXEC SaveEmoji @Name='woman-red-hair', @Path='person/woman-red-hair.png', @Categories= 'hair,person,red,woman'
GO
EXEC SaveEmoji @Name='woman-scientist', @Path='person/woman-scientist.png', @Categories= 'person,scientist,woman'
GO
EXEC SaveEmoji @Name='woman-shrugging', @Path='person/woman-shrugging.png', @Categories= 'person,shrugging,woman'
GO
EXEC SaveEmoji @Name='woman-singer', @Path='person/woman-singer.png', @Categories= 'person,singer,woman'
GO
EXEC SaveEmoji @Name='woman-student', @Path='person/woman-student.png', @Categories= 'person,student,woman'
GO
EXEC SaveEmoji @Name='woman-superhero', @Path='person/woman-superhero.png', @Categories= 'person,superhero,woman'
GO
EXEC SaveEmoji @Name='woman-supervillain', @Path='person/woman-supervillain.png', @Categories= 'person,supervillain,woman'
GO
EXEC SaveEmoji @Name='woman-teacher', @Path='person/woman-teacher.png', @Categories= 'person,teacher,woman'
GO
EXEC SaveEmoji @Name='woman-technologist', @Path='person/woman-technologist.png', @Categories= 'person,technologist,woman'
GO
EXEC SaveEmoji @Name='woman-tipping-hand', @Path='person/woman-tipping-hand.png', @Categories= 'hand,person,tipping,woman'
GO
EXEC SaveEmoji @Name='woman-vampire', @Path='person/woman-vampire.png', @Categories= 'person,vampire,woman'
GO
EXEC SaveEmoji @Name='woman-wearing-turban', @Path='person/woman-wearing-turban.png', @Categories= 'person,turban,wearing,woman'
GO
EXEC SaveEmoji @Name='woman-white-hair', @Path='person/woman-white-hair.png', @Categories= 'hair,person,white,woman'
GO
EXEC SaveEmoji @Name='woman-with-veil', @Path='person/woman-with-veil.png', @Categories= 'person,veil,with,woman'
GO
EXEC SaveEmoji @Name='woman-zombie', @Path='person/woman-zombie.png', @Categories= 'person,woman,zombie'
GO
EXEC SaveEmoji @Name='woman', @Path='person/woman.png', @Categories= 'person,woman'
GO
EXEC SaveEmoji @Name='women-holding-hands', @Path='person/women-holding-hands.png', @Categories= 'hands,holding,person,women'
GO
EXEC SaveEmoji @Name='women-with-bunny-ears', @Path='person/women-with-bunny-ears.png', @Categories= 'bunny,ears,person,with,women'
GO
EXEC SaveEmoji @Name='zombie', @Path='person/zombie.png', @Categories= 'person,zombie'
GO
EXEC SaveEmoji @Name='bank', @Path='places/bank.png', @Categories= 'bank,places'
GO
EXEC SaveEmoji @Name='barber-pole', @Path='places/barber-pole.png', @Categories= 'barber,places,pole'
GO
EXEC SaveEmoji @Name='bus-stop', @Path='places/bus-stop.png', @Categories= 'bus,places,stop'
GO
EXEC SaveEmoji @Name='castle', @Path='places/castle.png', @Categories= 'castle,places'
GO
EXEC SaveEmoji @Name='church', @Path='places/church.png', @Categories= 'church,places'
GO
EXEC SaveEmoji @Name='classical-building', @Path='places/classical-building.png', @Categories= 'building,classical,places'
GO
EXEC SaveEmoji @Name='convenience-store', @Path='places/convenience-store.png', @Categories= 'convenience,places,store'
GO
EXEC SaveEmoji @Name='department-store', @Path='places/department-store.png', @Categories= 'department,places,store'
GO
EXEC SaveEmoji @Name='derelict-house', @Path='places/derelict-house.png', @Categories= 'derelict,house,places'
GO
EXEC SaveEmoji @Name='factory', @Path='places/factory.png', @Categories= 'factory,places'
GO
EXEC SaveEmoji @Name='hindu-temple', @Path='places/hindu-temple.png', @Categories= 'hindu,places,temple'
GO
EXEC SaveEmoji @Name='hospital', @Path='places/hospital.png', @Categories= 'hospital,places'
GO
EXEC SaveEmoji @Name='hotel', @Path='places/hotel.png', @Categories= 'hotel,places'
GO
EXEC SaveEmoji @Name='house', @Path='places/house.png', @Categories= 'house,places'
GO
EXEC SaveEmoji @Name='houses', @Path='places/houses.png', @Categories= 'houses,places'
GO
EXEC SaveEmoji @Name='hut', @Path='places/hut.png', @Categories= 'hut,places'
GO
EXEC SaveEmoji @Name='japanese-castle', @Path='places/japanese-castle.png', @Categories= 'castle,japanese,places'
GO
EXEC SaveEmoji @Name='japanese-post-office', @Path='places/japanese-post-office.png', @Categories= 'japanese,office,places,post'
GO
EXEC SaveEmoji @Name='kaaba', @Path='places/kaaba.png', @Categories= 'kaaba,places'
GO
EXEC SaveEmoji @Name='love-hotel', @Path='places/love-hotel.png', @Categories= 'hotel,love,places'
GO
EXEC SaveEmoji @Name='mosque', @Path='places/mosque.png', @Categories= 'mosque,places'
GO
EXEC SaveEmoji @Name='office-building', @Path='places/office-building.png', @Categories= 'building,office,places'
GO
EXEC SaveEmoji @Name='post-office', @Path='places/post-office.png', @Categories= 'office,places,post'
GO
EXEC SaveEmoji @Name='school', @Path='places/school.png', @Categories= 'places,school'
GO
EXEC SaveEmoji @Name='stadium', @Path='places/stadium.png', @Categories= 'places,stadium'
GO
EXEC SaveEmoji @Name='synagogue', @Path='places/synagogue.png', @Categories= 'places,synagogue'
GO
EXEC SaveEmoji @Name='wedding', @Path='places/wedding.png', @Categories= 'places,wedding'
GO
EXEC SaveEmoji @Name='black-circle', @Path='shape/black-circle.png', @Categories= 'black,circle,shape'
GO
EXEC SaveEmoji @Name='black-large-square', @Path='shape/black-large-square.png', @Categories= 'black,large,shape,square'
GO
EXEC SaveEmoji @Name='black-medium-small-square', @Path='shape/black-medium-small-square.png', @Categories= 'black,medium,shape,small,square'
GO
EXEC SaveEmoji @Name='black-medium-square', @Path='shape/black-medium-square.png', @Categories= 'black,medium,shape,square'
GO
EXEC SaveEmoji @Name='black-small-square', @Path='shape/black-small-square.png', @Categories= 'black,shape,small,square'
GO
EXEC SaveEmoji @Name='black-square-button', @Path='shape/black-square-button.png', @Categories= 'black,button,shape,square'
GO
EXEC SaveEmoji @Name='cyclone', @Path='shape/cyclone.png', @Categories= 'cyclone,shape'
GO
EXEC SaveEmoji @Name='eight-pointed-star', @Path='shape/eight-pointed-star.png', @Categories= 'eight,pointed,shape,star'
GO
EXEC SaveEmoji @Name='eight-spoked-asterisk', @Path='shape/eight-spoked-asterisk.png', @Categories= 'asterisk,eight,shape,spoked'
GO
EXEC SaveEmoji @Name='hollow-red-circle', @Path='shape/hollow-red-circle.png', @Categories= 'circle,hollow,red,shape'
GO
EXEC SaveEmoji @Name='large-blue-circle', @Path='shape/large-blue-circle.png', @Categories= 'blue,circle,large,shape'
GO
EXEC SaveEmoji @Name='large-blue-diamond', @Path='shape/large-blue-diamond.png', @Categories= 'blue,diamond,large,shape'
GO
EXEC SaveEmoji @Name='large-blue-square', @Path='shape/large-blue-square.png', @Categories= 'blue,large,shape,square'
GO
EXEC SaveEmoji @Name='large-brown-circle', @Path='shape/large-brown-circle.png', @Categories= 'brown,circle,large,shape'
GO
EXEC SaveEmoji @Name='large-brown-square', @Path='shape/large-brown-square.png', @Categories= 'brown,large,shape,square'
GO
EXEC SaveEmoji @Name='large-green-circle', @Path='shape/large-green-circle.png', @Categories= 'circle,green,large,shape'
GO
EXEC SaveEmoji @Name='large-green-square', @Path='shape/large-green-square.png', @Categories= 'green,large,shape,square'
GO
EXEC SaveEmoji @Name='large-orange-circle', @Path='shape/large-orange-circle.png', @Categories= 'circle,large,orange,shape'
GO
EXEC SaveEmoji @Name='large-orange-diamond', @Path='shape/large-orange-diamond.png', @Categories= 'diamond,large,orange,shape'
GO
EXEC SaveEmoji @Name='large-orange-square', @Path='shape/large-orange-square.png', @Categories= 'large,orange,shape,square'
GO
EXEC SaveEmoji @Name='large-purple-circle', @Path='shape/large-purple-circle.png', @Categories= 'circle,large,purple,shape'
GO
EXEC SaveEmoji @Name='large-purple-square', @Path='shape/large-purple-square.png', @Categories= 'large,purple,shape,square'
GO
EXEC SaveEmoji @Name='large-red-circle', @Path='shape/large-red-circle.png', @Categories= 'circle,large,red,shape'
GO
EXEC SaveEmoji @Name='large-red-square', @Path='shape/large-red-square.png', @Categories= 'large,red,shape,square'
GO
EXEC SaveEmoji @Name='large-yellow-circle', @Path='shape/large-yellow-circle.png', @Categories= 'circle,large,shape,yellow'
GO
EXEC SaveEmoji @Name='large-yellow-square', @Path='shape/large-yellow-square.png', @Categories= 'large,shape,square,yellow'
GO
EXEC SaveEmoji @Name='small-blue-diamond', @Path='shape/small-blue-diamond.png', @Categories= 'blue,diamond,shape,small'
GO
EXEC SaveEmoji @Name='small-orange-diamond', @Path='shape/small-orange-diamond.png', @Categories= 'diamond,orange,shape,small'
GO
EXEC SaveEmoji @Name='stop-sign', @Path='shape/stop-sign.png', @Categories= 'shape,sign,stop'
GO
EXEC SaveEmoji @Name='white-circle', @Path='shape/white-circle.png', @Categories= 'circle,shape,white'
GO
EXEC SaveEmoji @Name='white-large-square', @Path='shape/white-large-square.png', @Categories= 'large,shape,square,white'
GO
EXEC SaveEmoji @Name='white-medium-small-square', @Path='shape/white-medium-small-square.png', @Categories= 'medium,shape,small,square,white'
GO
EXEC SaveEmoji @Name='white-medium-square', @Path='shape/white-medium-square.png', @Categories= 'medium,shape,square,white'
GO
EXEC SaveEmoji @Name='white-small-square', @Path='shape/white-small-square.png', @Categories= 'shape,small,square,white'
GO
EXEC SaveEmoji @Name='white-square-button', @Path='shape/white-square-button.png', @Categories= 'button,shape,square,white'
GO
EXEC SaveEmoji @Name='a-button-blood-type', @Path='symbol/a-button-blood-type.png', @Categories= 'a,blood,button,symbol,type'
GO
EXEC SaveEmoji @Name='ab-button-blood-type', @Path='symbol/ab-button-blood-type.png', @Categories= 'ab,blood,button,symbol,type'
GO
EXEC SaveEmoji @Name='anger-symbol', @Path='symbol/anger-symbol.png', @Categories= 'anger,symbol'
GO
EXEC SaveEmoji @Name='aquarius', @Path='symbol/aquarius.png', @Categories= 'aquarius,symbol'
GO
EXEC SaveEmoji @Name='aries', @Path='symbol/aries.png', @Categories= 'aries,symbol'
GO
EXEC SaveEmoji @Name='atm-sign', @Path='symbol/atm-sign.png', @Categories= 'atm,sign,symbol'
GO
EXEC SaveEmoji @Name='atom-symbol', @Path='symbol/atom-symbol.png', @Categories= 'atom,symbol'
GO
EXEC SaveEmoji @Name='b-button-blood-type', @Path='symbol/b-button-blood-type.png', @Categories= 'b,blood,button,symbol,type'
GO
EXEC SaveEmoji @Name='baby-symbol', @Path='symbol/baby-symbol.png', @Categories= 'baby,symbol'
GO
EXEC SaveEmoji @Name='baggage-claim', @Path='symbol/baggage-claim.png', @Categories= 'baggage,claim,symbol'
GO
EXEC SaveEmoji @Name='biohazard', @Path='symbol/biohazard.png', @Categories= 'biohazard,symbol'
GO
EXEC SaveEmoji @Name='bright-button', @Path='symbol/bright-button.png', @Categories= 'bright,button,symbol'
GO
EXEC SaveEmoji @Name='caller.333cc8d0cd59d65514da', @Path='symbol/caller.333cc8d0cd59d65514da.png', @Categories= 'caller.333cc8d0cd59d65514da,symbol'
GO
EXEC SaveEmoji @Name='cancer', @Path='symbol/cancer.png', @Categories= 'cancer,symbol'
GO
EXEC SaveEmoji @Name='capricorn', @Path='symbol/capricorn.png', @Categories= 'capricorn,symbol'
GO
EXEC SaveEmoji @Name='chart-increasing-with-yen', @Path='symbol/chart-increasing-with-yen.png', @Categories= 'chart,increasing,symbol,with,yen'
GO
EXEC SaveEmoji @Name='check-box-with-check', @Path='symbol/check-box-with-check.png', @Categories= 'box,check,symbol,with'
GO
EXEC SaveEmoji @Name='check-mark-button', @Path='symbol/check-mark-button.png', @Categories= 'button,check,mark,symbol'
GO
EXEC SaveEmoji @Name='check-mark', @Path='symbol/check-mark.png', @Categories= 'check,mark,symbol'
GO
EXEC SaveEmoji @Name='circled-m', @Path='symbol/circled-m.png', @Categories= 'circled,m,symbol'
GO
EXEC SaveEmoji @Name='cl-button', @Path='symbol/cl-button.png', @Categories= 'button,cl,symbol'
GO
EXEC SaveEmoji @Name='club-suit', @Path='symbol/club-suit.png', @Categories= 'club,suit,symbol'
GO
EXEC SaveEmoji @Name='copyright', @Path='symbol/copyright.png', @Categories= 'copyright,symbol'
GO
EXEC SaveEmoji @Name='cross-mark-button', @Path='symbol/cross-mark-button.png', @Categories= 'button,cross,mark,symbol'
GO
EXEC SaveEmoji @Name='cross-mark', @Path='symbol/cross-mark.png', @Categories= 'cross,mark,symbol'
GO
EXEC SaveEmoji @Name='curly-loop', @Path='symbol/curly-loop.png', @Categories= 'curly,loop,symbol'
GO
EXEC SaveEmoji @Name='currency-exchange', @Path='symbol/currency-exchange.png', @Categories= 'currency,exchange,symbol'
GO
EXEC SaveEmoji @Name='customs', @Path='symbol/customs.png', @Categories= 'customs,symbol'
GO
EXEC SaveEmoji @Name='diamond-suit', @Path='symbol/diamond-suit.png', @Categories= 'diamond,suit,symbol'
GO
EXEC SaveEmoji @Name='dim-button', @Path='symbol/dim-button.png', @Categories= 'button,dim,symbol'
GO
EXEC SaveEmoji @Name='divide', @Path='symbol/divide.png', @Categories= 'divide,symbol'
GO
EXEC SaveEmoji @Name='dotted-six-pointed-star', @Path='symbol/dotted-six-pointed-star.png', @Categories= 'dotted,pointed,six,star,symbol'
GO
EXEC SaveEmoji @Name='double-curly-loop', @Path='symbol/double-curly-loop.png', @Categories= 'curly,double,loop,symbol'
GO
EXEC SaveEmoji @Name='double-exclamation-mark', @Path='symbol/double-exclamation-mark.png', @Categories= 'double,exclamation,mark,symbol'
GO
EXEC SaveEmoji @Name='elevator', @Path='symbol/elevator.png', @Categories= 'elevator,symbol'
GO
EXEC SaveEmoji @Name='exclamation-mark', @Path='symbol/exclamation-mark.png', @Categories= 'exclamation,mark,symbol'
GO
EXEC SaveEmoji @Name='exclamation-question-mark', @Path='symbol/exclamation-question-mark.png', @Categories= 'exclamation,mark,question,symbol'
GO
EXEC SaveEmoji @Name='eye-in-speech-bubble', @Path='symbol/eye-in-speech-bubble.png', @Categories= 'bubble,eye,in,speech,symbol'
GO
EXEC SaveEmoji @Name='gemini', @Path='symbol/gemini.png', @Categories= 'gemini,symbol'
GO
EXEC SaveEmoji @Name='glowing-star', @Path='symbol/glowing-star.png', @Categories= 'glowing,star,symbol'
GO
EXEC SaveEmoji @Name='hamsa', @Path='symbol/hamsa.png', @Categories= 'hamsa,symbol'
GO
EXEC SaveEmoji @Name='heavy-dollar-sign', @Path='symbol/heavy-dollar-sign.png', @Categories= 'dollar,heavy,sign,symbol'
GO
EXEC SaveEmoji @Name='heavy-equals-sign', @Path='symbol/heavy-equals-sign.png', @Categories= 'equals,heavy,sign,symbol'
GO
EXEC SaveEmoji @Name='high-voltage', @Path='symbol/high-voltage.png', @Categories= 'high,symbol,voltage'
GO
EXEC SaveEmoji @Name='horizontal-traffic-light', @Path='symbol/horizontal-traffic-light.png', @Categories= 'horizontal,light,symbol,traffic'
GO
EXEC SaveEmoji @Name='hot-springs', @Path='symbol/hot-springs.png', @Categories= 'hot,springs,symbol'
GO
EXEC SaveEmoji @Name='hundred-points', @Path='symbol/hundred-points.png', @Categories= 'hundred,points,symbol'
GO
EXEC SaveEmoji @Name='id-button', @Path='symbol/id-button.png', @Categories= 'button,id,symbol'
GO
EXEC SaveEmoji @Name='infinity', @Path='symbol/infinity.png', @Categories= 'infinity,symbol'
GO
EXEC SaveEmoji @Name='information', @Path='symbol/information.png', @Categories= 'information,symbol'
GO
EXEC SaveEmoji @Name='input-latin-letters', @Path='symbol/input-latin-letters.png', @Categories= 'input,latin,letters,symbol'
GO
EXEC SaveEmoji @Name='input-latin-lowercase', @Path='symbol/input-latin-lowercase.png', @Categories= 'input,latin,lowercase,symbol'
GO
EXEC SaveEmoji @Name='input-latin-uppercase', @Path='symbol/input-latin-uppercase.png', @Categories= 'input,latin,symbol,uppercase'
GO
EXEC SaveEmoji @Name='input-numbers', @Path='symbol/input-numbers.png', @Categories= 'input,numbers,symbol'
GO
EXEC SaveEmoji @Name='input-symbols', @Path='symbol/input-symbols.png', @Categories= 'input,symbol,symbols'
GO
EXEC SaveEmoji @Name='japanese-acceptable-button', @Path='symbol/japanese-acceptable-button.png', @Categories= 'acceptable,button,japanese,symbol'
GO
EXEC SaveEmoji @Name='japanese-application-button', @Path='symbol/japanese-application-button.png', @Categories= 'application,button,japanese,symbol'
GO
EXEC SaveEmoji @Name='japanese-bargain-button', @Path='symbol/japanese-bargain-button.png', @Categories= 'bargain,button,japanese,symbol'
GO
EXEC SaveEmoji @Name='japanese-congratulations-button', @Path='symbol/japanese-congratulations-button.png', @Categories= 'button,congratulations,japanese,symbol'
GO
EXEC SaveEmoji @Name='japanese-discount-button', @Path='symbol/japanese-discount-button.png', @Categories= 'button,discount,japanese,symbol'
GO
EXEC SaveEmoji @Name='japanese-free-of-charge-button', @Path='symbol/japanese-free-of-charge-button.png', @Categories= 'button,charge,free,japanese,of,symbol'
GO
EXEC SaveEmoji @Name='japanese-here-button', @Path='symbol/japanese-here-button.png', @Categories= 'button,here,japanese,symbol'
GO
EXEC SaveEmoji @Name='japanese-monthly-amount-button', @Path='symbol/japanese-monthly-amount-button.png', @Categories= 'amount,button,japanese,monthly,symbol'
GO
EXEC SaveEmoji @Name='japanese-no-vacancy-button', @Path='symbol/japanese-no-vacancy-button.png', @Categories= 'button,japanese,no,symbol,vacancy'
GO
EXEC SaveEmoji @Name='japanese-not-free-of-charge-button', @Path='symbol/japanese-not-free-of-charge-button.png', @Categories= 'button,charge,free,japanese,not,of,symbol'
GO
EXEC SaveEmoji @Name='japanese-open-for-business-button', @Path='symbol/japanese-open-for-business-button.png', @Categories= 'business,button,for,japanese,open,symbol'
GO
EXEC SaveEmoji @Name='japanese-passing-grade-button', @Path='symbol/japanese-passing-grade-button.png', @Categories= 'button,grade,japanese,passing,symbol'
GO
EXEC SaveEmoji @Name='japanese-prohibited-button', @Path='symbol/japanese-prohibited-button.png', @Categories= 'button,japanese,prohibited,symbol'
GO
EXEC SaveEmoji @Name='japanese-reserved-button', @Path='symbol/japanese-reserved-button.png', @Categories= 'button,japanese,reserved,symbol'
GO
EXEC SaveEmoji @Name='japanese-secret-button', @Path='symbol/japanese-secret-button.png', @Categories= 'button,japanese,secret,symbol'
GO
EXEC SaveEmoji @Name='japanese-service-charge-button', @Path='symbol/japanese-service-charge-button.png', @Categories= 'button,charge,japanese,service,symbol'
GO
EXEC SaveEmoji @Name='japanese-symbol-for-beginner', @Path='symbol/japanese-symbol-for-beginner.png', @Categories= 'beginner,for,japanese,symbol'
GO
EXEC SaveEmoji @Name='japanese-vacancy-button', @Path='symbol/japanese-vacancy-button.png', @Categories= 'button,japanese,symbol,vacancy'
GO
EXEC SaveEmoji @Name='khanda', @Path='symbol/khanda.png', @Categories= 'khanda,symbol'
GO
EXEC SaveEmoji @Name='latin-cross', @Path='symbol/latin-cross.png', @Categories= 'cross,latin,symbol'
GO
EXEC SaveEmoji @Name='left-luggage', @Path='symbol/left-luggage.png', @Categories= 'left,luggage,symbol'
GO
EXEC SaveEmoji @Name='leo', @Path='symbol/leo.png', @Categories= 'leo,symbol'
GO
EXEC SaveEmoji @Name='libra', @Path='symbol/libra.png', @Categories= 'libra,symbol'
GO
EXEC SaveEmoji @Name='litter-in-bin-sign', @Path='symbol/litter-in-bin-sign.png', @Categories= 'bin,in,litter,sign,symbol'
GO
EXEC SaveEmoji @Name='mahjong-red-dragon', @Path='symbol/mahjong-red-dragon.png', @Categories= 'dragon,mahjong,red,symbol'
GO
EXEC SaveEmoji @Name='menorah', @Path='symbol/menorah.png', @Categories= 'menorah,symbol'
GO
EXEC SaveEmoji @Name='mens-room', @Path='symbol/mens-room.png', @Categories= 'mens,room,symbol'
GO
EXEC SaveEmoji @Name='minus', @Path='symbol/minus.png', @Categories= 'minus,symbol'
GO
EXEC SaveEmoji @Name='multiply', @Path='symbol/multiply.png', @Categories= 'multiply,symbol'
GO
EXEC SaveEmoji @Name='name-badge', @Path='symbol/name-badge.png', @Categories= 'badge,name,symbol'
GO
EXEC SaveEmoji @Name='no-bicycles', @Path='symbol/no-bicycles.png', @Categories= 'bicycles,no,symbol'
GO
EXEC SaveEmoji @Name='no-entry', @Path='symbol/no-entry.png', @Categories= 'entry,no,symbol'
GO
EXEC SaveEmoji @Name='no-littering', @Path='symbol/no-littering.png', @Categories= 'littering,no,symbol'
GO
EXEC SaveEmoji @Name='no-mobile-phones', @Path='symbol/no-mobile-phones.png', @Categories= 'mobile,no,phones,symbol'
GO
EXEC SaveEmoji @Name='no-one-under-eighteen', @Path='symbol/no-one-under-eighteen.png', @Categories= 'eighteen,no,one,symbol,under'
GO
EXEC SaveEmoji @Name='no-pedestrians', @Path='symbol/no-pedestrians.png', @Categories= 'no,pedestrians,symbol'
GO
EXEC SaveEmoji @Name='no-smoking', @Path='symbol/no-smoking.png', @Categories= 'no,smoking,symbol'
GO
EXEC SaveEmoji @Name='non-potable-water', @Path='symbol/non-potable-water.png', @Categories= 'non,potable,symbol,water'
GO
EXEC SaveEmoji @Name='o-button-blood-type', @Path='symbol/o-button-blood-type.png', @Categories= 'blood,button,o,symbol,type'
GO
EXEC SaveEmoji @Name='om', @Path='symbol/om.png', @Categories= 'om,symbol'
GO
EXEC SaveEmoji @Name='ophiuchus', @Path='symbol/ophiuchus.png', @Categories= 'ophiuchus,symbol'
GO
EXEC SaveEmoji @Name='orthodox-cross', @Path='symbol/orthodox-cross.png', @Categories= 'cross,orthodox,symbol'
GO
EXEC SaveEmoji @Name='p-button', @Path='symbol/p-button.png', @Categories= 'button,p,symbol'
GO
EXEC SaveEmoji @Name='passport-control', @Path='symbol/passport-control.png', @Categories= 'control,passport,symbol'
GO
EXEC SaveEmoji @Name='peace-symbol', @Path='symbol/peace-symbol.png', @Categories= 'peace,symbol'
GO
EXEC SaveEmoji @Name='pisces', @Path='symbol/pisces.png', @Categories= 'pisces,symbol'
GO
EXEC SaveEmoji @Name='place-of-worship', @Path='symbol/place-of-worship.png', @Categories= 'of,place,symbol,worship'
GO
EXEC SaveEmoji @Name='plus', @Path='symbol/plus.png', @Categories= 'plus,symbol'
GO
EXEC SaveEmoji @Name='prohibited', @Path='symbol/prohibited.png', @Categories= 'prohibited,symbol'
GO
EXEC SaveEmoji @Name='question-mark', @Path='symbol/question-mark.png', @Categories= 'mark,question,symbol'
GO
EXEC SaveEmoji @Name='radioactive', @Path='symbol/radioactive.png', @Categories= 'radioactive,symbol'
GO
EXEC SaveEmoji @Name='recycling-symbol', @Path='symbol/recycling-symbol.png', @Categories= 'recycling,symbol'
GO
EXEC SaveEmoji @Name='registered', @Path='symbol/registered.png', @Categories= 'registered,symbol'
GO
EXEC SaveEmoji @Name='restroom', @Path='symbol/restroom.png', @Categories= 'restroom,symbol'
GO
EXEC SaveEmoji @Name='sagittarius', @Path='symbol/sagittarius.png', @Categories= 'sagittarius,symbol'
GO
EXEC SaveEmoji @Name='scorpio', @Path='symbol/scorpio.png', @Categories= 'scorpio,symbol'
GO
EXEC SaveEmoji @Name='sos-button', @Path='symbol/sos-button.png', @Categories= 'button,sos,symbol'
GO
EXEC SaveEmoji @Name='spade-suit', @Path='symbol/spade-suit.png', @Categories= 'spade,suit,symbol'
GO
EXEC SaveEmoji @Name='sparkle', @Path='symbol/sparkle.png', @Categories= 'sparkle,symbol'
GO
EXEC SaveEmoji @Name='sparkles', @Path='symbol/sparkles.png', @Categories= 'sparkles,symbol'
GO
EXEC SaveEmoji @Name='speaking-head', @Path='symbol/speaking-head.png', @Categories= 'head,speaking,symbol'
GO
EXEC SaveEmoji @Name='star-and-crescent', @Path='symbol/star-and-crescent.png', @Categories= 'and,crescent,star,symbol'
GO
EXEC SaveEmoji @Name='star-of-david', @Path='symbol/star-of-david.png', @Categories= 'david,of,star,symbol'
GO
EXEC SaveEmoji @Name='taurus', @Path='symbol/taurus.png', @Categories= 'symbol,taurus'
GO
EXEC SaveEmoji @Name='trade-mark', @Path='symbol/trade-mark.png', @Categories= 'mark,symbol,trade'
GO
EXEC SaveEmoji @Name='transgender-symbol', @Path='symbol/transgender-symbol.png', @Categories= 'symbol,transgender'
GO
EXEC SaveEmoji @Name='variation-selector-16', @Path='symbol/variation-selector-16.png', @Categories= '16,selector,symbol,variation'
GO
EXEC SaveEmoji @Name='vertical-traffic-light', @Path='symbol/vertical-traffic-light.png', @Categories= 'light,symbol,traffic,vertical'
GO
EXEC SaveEmoji @Name='vibration-mode', @Path='symbol/vibration-mode.png', @Categories= 'mode,symbol,vibration'
GO
EXEC SaveEmoji @Name='virgo', @Path='symbol/virgo.png', @Categories= 'symbol,virgo'
GO
EXEC SaveEmoji @Name='vs-button', @Path='symbol/vs-button.png', @Categories= 'button,symbol,vs'
GO
EXEC SaveEmoji @Name='warning', @Path='symbol/warning.png', @Categories= 'symbol,warning'
GO
EXEC SaveEmoji @Name='water-closet', @Path='symbol/water-closet.png', @Categories= 'closet,symbol,water'
GO
EXEC SaveEmoji @Name='wheel-of-dharma', @Path='symbol/wheel-of-dharma.png', @Categories= 'dharma,of,symbol,wheel'
GO
EXEC SaveEmoji @Name='wheelchair-symbol', @Path='symbol/wheelchair-symbol.png', @Categories= 'symbol,wheelchair'
GO
EXEC SaveEmoji @Name='white-exclamation-mark', @Path='symbol/white-exclamation-mark.png', @Categories= 'exclamation,mark,symbol,white'
GO
EXEC SaveEmoji @Name='white-flower', @Path='symbol/white-flower.png', @Categories= 'flower,symbol,white'
GO
EXEC SaveEmoji @Name='white-question-mark', @Path='symbol/white-question-mark.png', @Categories= 'mark,question,symbol,white'
GO
EXEC SaveEmoji @Name='wireless', @Path='symbol/wireless.png', @Categories= 'symbol,wireless'
GO
EXEC SaveEmoji @Name='womens-room', @Path='symbol/womens-room.png', @Categories= 'room,symbol,womens'
GO
EXEC SaveEmoji @Name='yin-yang', @Path='symbol/yin-yang.png', @Categories= 'symbol,yang,yin'
GO
EXEC SaveEmoji @Name='zzz', @Path='symbol/zzz.png', @Categories= 'symbol,zzz'
GO
EXEC SaveEmoji @Name='alembic', @Path='technology/alembic.png', @Categories= 'alembic,technology'
GO
EXEC SaveEmoji @Name='battery', @Path='technology/battery.png', @Categories= 'battery,technology'
GO
EXEC SaveEmoji @Name='camera-with-flash', @Path='technology/camera-with-flash.png', @Categories= 'camera,flash,technology,with'
GO
EXEC SaveEmoji @Name='camera', @Path='technology/camera.png', @Categories= 'camera,technology'
GO
EXEC SaveEmoji @Name='card-file-box', @Path='technology/card-file-box.png', @Categories= 'box,card,file,technology'
GO
EXEC SaveEmoji @Name='card-index-dividers', @Path='technology/card-index-dividers.png', @Categories= 'card,dividers,index,technology'
GO
EXEC SaveEmoji @Name='card-index', @Path='technology/card-index.png', @Categories= 'card,index,technology'
GO
EXEC SaveEmoji @Name='compass', @Path='technology/compass.png', @Categories= 'compass,technology'
GO
EXEC SaveEmoji @Name='computer-disk', @Path='technology/computer-disk.png', @Categories= 'computer,disk,technology'
GO
EXEC SaveEmoji @Name='computer-mouse', @Path='technology/computer-mouse.png', @Categories= 'computer,mouse,technology'
GO
EXEC SaveEmoji @Name='control-knobs', @Path='technology/control-knobs.png', @Categories= 'control,knobs,technology'
GO
EXEC SaveEmoji @Name='credit-card', @Path='technology/credit-card.png', @Categories= 'card,credit,technology'
GO
EXEC SaveEmoji @Name='desktop-computer', @Path='technology/desktop-computer.png', @Categories= 'computer,desktop,technology'
GO
EXEC SaveEmoji @Name='dvd', @Path='technology/dvd.png', @Categories= 'dvd,technology'
GO
EXEC SaveEmoji @Name='e-mail', @Path='technology/e-mail.png', @Categories= 'e,mail,technology'
GO
EXEC SaveEmoji @Name='electric-plug', @Path='technology/electric-plug.png', @Categories= 'electric,plug,technology'
GO
EXEC SaveEmoji @Name='fax-machine', @Path='technology/fax-machine.png', @Categories= 'fax,machine,technology'
GO
EXEC SaveEmoji @Name='film-projector', @Path='technology/film-projector.png', @Categories= 'film,projector,technology'
GO
EXEC SaveEmoji @Name='flashlight', @Path='technology/flashlight.png', @Categories= 'flashlight,technology'
GO
EXEC SaveEmoji @Name='floppy-disk', @Path='technology/floppy-disk.png', @Categories= 'disk,floppy,technology'
GO
EXEC SaveEmoji @Name='gear', @Path='technology/gear.png', @Categories= 'gear,technology'
GO
EXEC SaveEmoji @Name='headphone', @Path='technology/headphone.png', @Categories= 'headphone,technology'
GO
EXEC SaveEmoji @Name='joystick', @Path='technology/joystick.png', @Categories= 'joystick,technology'
GO
EXEC SaveEmoji @Name='laptop', @Path='technology/laptop.png', @Categories= 'laptop,technology'
GO
EXEC SaveEmoji @Name='level-slider', @Path='technology/level-slider.png', @Categories= 'level,slider,technology'
GO
EXEC SaveEmoji @Name='light-bulb', @Path='technology/light-bulb.png', @Categories= 'bulb,light,technology'
GO
EXEC SaveEmoji @Name='loudspeaker', @Path='technology/loudspeaker.png', @Categories= 'loudspeaker,technology'
GO
EXEC SaveEmoji @Name='low-battery', @Path='technology/low-battery.png', @Categories= 'battery,low,technology'
GO
EXEC SaveEmoji @Name='mechanical-arm', @Path='technology/mechanical-arm.png', @Categories= 'arm,mechanical,technology'
GO
EXEC SaveEmoji @Name='mechanical-leg', @Path='technology/mechanical-leg.png', @Categories= 'leg,mechanical,technology'
GO
EXEC SaveEmoji @Name='microphone', @Path='technology/microphone.png', @Categories= 'microphone,technology'
GO
EXEC SaveEmoji @Name='microscope', @Path='technology/microscope.png', @Categories= 'microscope,technology'
GO
EXEC SaveEmoji @Name='mobile-phone-off', @Path='technology/mobile-phone-off.png', @Categories= 'mobile,off,phone,technology'
GO
EXEC SaveEmoji @Name='mobile-phone', @Path='technology/mobile-phone.png', @Categories= 'mobile,phone,technology'
GO
EXEC SaveEmoji @Name='movie-camera', @Path='technology/movie-camera.png', @Categories= 'camera,movie,technology'
GO
EXEC SaveEmoji @Name='muted-speaker', @Path='technology/muted-speaker.png', @Categories= 'muted,speaker,technology'
GO
EXEC SaveEmoji @Name='optical-disk', @Path='technology/optical-disk.png', @Categories= 'disk,optical,technology'
GO
EXEC SaveEmoji @Name='pager', @Path='technology/pager.png', @Categories= 'pager,technology'
GO
EXEC SaveEmoji @Name='printer', @Path='technology/printer.png', @Categories= 'printer,technology'
GO
EXEC SaveEmoji @Name='radio', @Path='technology/radio.png', @Categories= 'radio,technology'
GO
EXEC SaveEmoji @Name='satellite-antenna', @Path='technology/satellite-antenna.png', @Categories= 'antenna,satellite,technology'
GO
EXEC SaveEmoji @Name='satellite', @Path='technology/satellite.png', @Categories= 'satellite,technology'
GO
EXEC SaveEmoji @Name='speaker-high-volume', @Path='technology/speaker-high-volume.png', @Categories= 'high,speaker,technology,volume'
GO
EXEC SaveEmoji @Name='speaker-low-volume', @Path='technology/speaker-low-volume.png', @Categories= 'low,speaker,technology,volume'
GO
EXEC SaveEmoji @Name='speaker-medium-volume', @Path='technology/speaker-medium-volume.png', @Categories= 'medium,speaker,technology,volume'
GO
EXEC SaveEmoji @Name='stethoscope', @Path='technology/stethoscope.png', @Categories= 'stethoscope,technology'
GO
EXEC SaveEmoji @Name='studio-microphone', @Path='technology/studio-microphone.png', @Categories= 'microphone,studio,technology'
GO
EXEC SaveEmoji @Name='syringe', @Path='technology/syringe.png', @Categories= 'syringe,technology'
GO
EXEC SaveEmoji @Name='telephone-receiver', @Path='technology/telephone-receiver.png', @Categories= 'receiver,technology,telephone'
GO
EXEC SaveEmoji @Name='telephone', @Path='technology/telephone.png', @Categories= 'technology,telephone'
GO
EXEC SaveEmoji @Name='telescope', @Path='technology/telescope.png', @Categories= 'technology,telescope'
GO
EXEC SaveEmoji @Name='television', @Path='technology/television.png', @Categories= 'technology,television'
GO
EXEC SaveEmoji @Name='test-tube', @Path='technology/test-tube.png', @Categories= 'technology,test,tube'
GO
EXEC SaveEmoji @Name='thermometer', @Path='technology/thermometer.png', @Categories= 'technology,thermometer'
GO
EXEC SaveEmoji @Name='toolbox', @Path='technology/toolbox.png', @Categories= 'technology,toolbox'
GO
EXEC SaveEmoji @Name='trackball', @Path='technology/trackball.png', @Categories= 'technology,trackball'
GO
EXEC SaveEmoji @Name='video-camera', @Path='technology/video-camera.png', @Categories= 'camera,technology,video'
GO
EXEC SaveEmoji @Name='video-game', @Path='technology/video-game.png', @Categories= 'game,technology,video'
GO
EXEC SaveEmoji @Name='videocassette', @Path='technology/videocassette.png', @Categories= 'technology,videocassette'
GO
EXEC SaveEmoji @Name='x-ray', @Path='technology/x-ray.png', @Categories= 'ray,technology,x'
GO
EXEC SaveEmoji @Name='alarm-clock', @Path='time/alarm-clock.png', @Categories= 'alarm,clock,time'
GO
EXEC SaveEmoji @Name='bell-with-slash', @Path='time/bell-with-slash.png', @Categories= 'bell,slash,time,with'
GO
EXEC SaveEmoji @Name='bell', @Path='time/bell.png', @Categories= 'bell,time'
GO
EXEC SaveEmoji @Name='bellhop-bell', @Path='time/bellhop-bell.png', @Categories= 'bell,bellhop,time'
GO
EXEC SaveEmoji @Name='calendar', @Path='time/calendar.png', @Categories= 'calendar,time'
GO
EXEC SaveEmoji @Name='eight-oclock', @Path='time/eight-oclock.png', @Categories= 'eight,oclock,time'
GO
EXEC SaveEmoji @Name='eight-thirty', @Path='time/eight-thirty.png', @Categories= 'eight,thirty,time'
GO
EXEC SaveEmoji @Name='eleven-oclock', @Path='time/eleven-oclock.png', @Categories= 'eleven,oclock,time'
GO
EXEC SaveEmoji @Name='eleven-thirty', @Path='time/eleven-thirty.png', @Categories= 'eleven,thirty,time'
GO
EXEC SaveEmoji @Name='five-oclock', @Path='time/five-oclock.png', @Categories= 'five,oclock,time'
GO
EXEC SaveEmoji @Name='five-thirty', @Path='time/five-thirty.png', @Categories= 'five,thirty,time'
GO
EXEC SaveEmoji @Name='four-oclock', @Path='time/four-oclock.png', @Categories= 'four,oclock,time'
GO
EXEC SaveEmoji @Name='four-thirty', @Path='time/four-thirty.png', @Categories= 'four,thirty,time'
GO
EXEC SaveEmoji @Name='hourglass-done', @Path='time/hourglass-done.png', @Categories= 'done,hourglass,time'
GO
EXEC SaveEmoji @Name='hourglass-not-done', @Path='time/hourglass-not-done.png', @Categories= 'done,hourglass,not,time'
GO
EXEC SaveEmoji @Name='mantelpiece-clock', @Path='time/mantelpiece-clock.png', @Categories= 'clock,mantelpiece,time'
GO
EXEC SaveEmoji @Name='nine-oclock', @Path='time/nine-oclock.png', @Categories= 'nine,oclock,time'
GO
EXEC SaveEmoji @Name='nine-thirty', @Path='time/nine-thirty.png', @Categories= 'nine,thirty,time'
GO
EXEC SaveEmoji @Name='one-oclock', @Path='time/one-oclock.png', @Categories= 'oclock,one,time'
GO
EXEC SaveEmoji @Name='one-thirty', @Path='time/one-thirty.png', @Categories= 'one,thirty,time'
GO
EXEC SaveEmoji @Name='seven-oclock', @Path='time/seven-oclock.png', @Categories= 'oclock,seven,time'
GO
EXEC SaveEmoji @Name='seven-thirty', @Path='time/seven-thirty.png', @Categories= 'seven,thirty,time'
GO
EXEC SaveEmoji @Name='six-oclock', @Path='time/six-oclock.png', @Categories= 'oclock,six,time'
GO
EXEC SaveEmoji @Name='six-thirty', @Path='time/six-thirty.png', @Categories= 'six,thirty,time'
GO
EXEC SaveEmoji @Name='spiral-calendar', @Path='time/spiral-calendar.png', @Categories= 'calendar,spiral,time'
GO
EXEC SaveEmoji @Name='stopwatch', @Path='time/stopwatch.png', @Categories= 'stopwatch,time'
GO
EXEC SaveEmoji @Name='ten-oclock', @Path='time/ten-oclock.png', @Categories= 'oclock,ten,time'
GO
EXEC SaveEmoji @Name='ten-thirty', @Path='time/ten-thirty.png', @Categories= 'ten,thirty,time'
GO
EXEC SaveEmoji @Name='three-oclock', @Path='time/three-oclock.png', @Categories= 'oclock,three,time'
GO
EXEC SaveEmoji @Name='three-thirty', @Path='time/three-thirty.png', @Categories= 'thirty,three,time'
GO
EXEC SaveEmoji @Name='timer-clock', @Path='time/timer-clock.png', @Categories= 'clock,time,timer'
GO
EXEC SaveEmoji @Name='twelve-oclock', @Path='time/twelve-oclock.png', @Categories= 'oclock,time,twelve'
GO
EXEC SaveEmoji @Name='twelve-thirty', @Path='time/twelve-thirty.png', @Categories= 'thirty,time,twelve'
GO
EXEC SaveEmoji @Name='two-oclocktime', @Path='time/two-oclocktime.png', @Categories= 'oclocktime,time,two'
GO
EXEC SaveEmoji @Name='two-thirty', @Path='time/two-thirty.png', @Categories= 'thirty,time,two'
GO
EXEC SaveEmoji @Name='watch', @Path='time/watch.png', @Categories= 'time,watch'
GO
EXEC SaveEmoji @Name='aerial-tramway', @Path='travel/aerial-tramway.png', @Categories= 'aerial,tramway,travel'
GO
EXEC SaveEmoji @Name='airplane-arrival', @Path='travel/airplane-arrival.png', @Categories= 'airplane,arrival,travel'
GO
EXEC SaveEmoji @Name='airplane-departure', @Path='travel/airplane-departure.png', @Categories= 'airplane,departure,travel'
GO
EXEC SaveEmoji @Name='airplane', @Path='travel/airplane.png', @Categories= 'airplane,travel'
GO
EXEC SaveEmoji @Name='ambulance', @Path='travel/ambulance.png', @Categories= 'ambulance,travel'
GO
EXEC SaveEmoji @Name='articulated-lorry', @Path='travel/articulated-lorry.png', @Categories= 'articulated,lorry,travel'
GO
EXEC SaveEmoji @Name='auto-rickshaw', @Path='travel/auto-rickshaw.png', @Categories= 'auto,rickshaw,travel'
GO
EXEC SaveEmoji @Name='automobile', @Path='travel/automobile.png', @Categories= 'automobile,travel'
GO
EXEC SaveEmoji @Name='bicycle', @Path='travel/bicycle.png', @Categories= 'bicycle,travel'
GO
EXEC SaveEmoji @Name='bullet-train', @Path='travel/bullet-train.png', @Categories= 'bullet,train,travel'
GO
EXEC SaveEmoji @Name='bus', @Path='travel/bus.png', @Categories= 'bus,travel'
GO
EXEC SaveEmoji @Name='delivery-truck', @Path='travel/delivery-truck.png', @Categories= 'delivery,travel,truck'
GO
EXEC SaveEmoji @Name='ferry', @Path='travel/ferry.png', @Categories= 'ferry,travel'
GO
EXEC SaveEmoji @Name='fire-engine', @Path='travel/fire-engine.png', @Categories= 'engine,fire,travel'
GO
EXEC SaveEmoji @Name='fuel-pump', @Path='travel/fuel-pump.png', @Categories= 'fuel,pump,travel'
GO
EXEC SaveEmoji @Name='helicopter', @Path='travel/helicopter.png', @Categories= 'helicopter,travel'
GO
EXEC SaveEmoji @Name='high-speed-train', @Path='travel/high-speed-train.png', @Categories= 'high,speed,train,travel'
GO
EXEC SaveEmoji @Name='kick-scooter', @Path='travel/kick-scooter.png', @Categories= 'kick,scooter,travel'
GO
EXEC SaveEmoji @Name='light-rail', @Path='travel/light-rail.png', @Categories= 'light,rail,travel'
GO
EXEC SaveEmoji @Name='locomotive', @Path='travel/locomotive.png', @Categories= 'locomotive,travel'
GO
EXEC SaveEmoji @Name='manual-wheelchair', @Path='travel/manual-wheelchair.png', @Categories= 'manual,travel,wheelchair'
GO
EXEC SaveEmoji @Name='metro', @Path='travel/metro.png', @Categories= 'metro,travel'
GO
EXEC SaveEmoji @Name='minibus', @Path='travel/minibus.png', @Categories= 'minibus,travel'
GO
EXEC SaveEmoji @Name='monorail', @Path='travel/monorail.png', @Categories= 'monorail,travel'
GO
EXEC SaveEmoji @Name='motor-boat', @Path='travel/motor-boat.png', @Categories= 'boat,motor,travel'
GO
EXEC SaveEmoji @Name='motor-scooter', @Path='travel/motor-scooter.png', @Categories= 'motor,scooter,travel'
GO
EXEC SaveEmoji @Name='motorcycle', @Path='travel/motorcycle.png', @Categories= 'motorcycle,travel'
GO
EXEC SaveEmoji @Name='motorized-wheelchair', @Path='travel/motorized-wheelchair.png', @Categories= 'motorized,travel,wheelchair'
GO
EXEC SaveEmoji @Name='motorway', @Path='travel/motorway.png', @Categories= 'motorway,travel'
GO
EXEC SaveEmoji @Name='mountain-cableway', @Path='travel/mountain-cableway.png', @Categories= 'cableway,mountain,travel'
GO
EXEC SaveEmoji @Name='mountain-railway', @Path='travel/mountain-railway.png', @Categories= 'mountain,railway,travel'
GO
EXEC SaveEmoji @Name='oncoming-automobile', @Path='travel/oncoming-automobile.png', @Categories= 'automobile,oncoming,travel'
GO
EXEC SaveEmoji @Name='oncoming-bus', @Path='travel/oncoming-bus.png', @Categories= 'bus,oncoming,travel'
GO
EXEC SaveEmoji @Name='oncoming-police-car', @Path='travel/oncoming-police-car.png', @Categories= 'car,oncoming,police,travel'
GO
EXEC SaveEmoji @Name='oncoming-taxi', @Path='travel/oncoming-taxi.png', @Categories= 'oncoming,taxi,travel'
GO
EXEC SaveEmoji @Name='parachute', @Path='travel/parachute.png', @Categories= 'parachute,travel'
GO
EXEC SaveEmoji @Name='passenger-ship', @Path='travel/passenger-ship.png', @Categories= 'passenger,ship,travel'
GO
EXEC SaveEmoji @Name='pickup-truck', @Path='travel/pickup-truck.png', @Categories= 'pickup,travel,truck'
GO
EXEC SaveEmoji @Name='police-car', @Path='travel/police-car.png', @Categories= 'car,police,travel'
GO
EXEC SaveEmoji @Name='racing-car', @Path='travel/racing-car.png', @Categories= 'car,racing,travel'
GO
EXEC SaveEmoji @Name='railway-car', @Path='travel/railway-car.png', @Categories= 'car,railway,travel'
GO
EXEC SaveEmoji @Name='railway-track', @Path='travel/railway-track.png', @Categories= 'railway,track,travel'
GO
EXEC SaveEmoji @Name='rocket', @Path='travel/rocket.png', @Categories= 'rocket,travel'
GO
EXEC SaveEmoji @Name='roller-coaster', @Path='travel/roller-coaster.png', @Categories= 'coaster,roller,travel'
GO
EXEC SaveEmoji @Name='sailboat', @Path='travel/sailboat.png', @Categories= 'sailboat,travel'
GO
EXEC SaveEmoji @Name='seat', @Path='travel/seat.png', @Categories= 'seat,travel'
GO
EXEC SaveEmoji @Name='ship', @Path='travel/ship.png', @Categories= 'ship,travel'
GO
EXEC SaveEmoji @Name='small-airplane', @Path='travel/small-airplane.png', @Categories= 'airplane,small,travel'
GO
EXEC SaveEmoji @Name='speedboat', @Path='travel/speedboat.png', @Categories= 'speedboat,travel'
GO
EXEC SaveEmoji @Name='sport-utility-vehicle', @Path='travel/sport-utility-vehicle.png', @Categories= 'sport,travel,utility,vehicle'
GO
EXEC SaveEmoji @Name='station', @Path='travel/station.png', @Categories= 'station,travel'
GO
EXEC SaveEmoji @Name='suspension-railway', @Path='travel/suspension-railway.png', @Categories= 'railway,suspension,travel'
GO
EXEC SaveEmoji @Name='taxi', @Path='travel/taxi.png', @Categories= 'taxi,travel'
GO
EXEC SaveEmoji @Name='tractor', @Path='travel/tractor.png', @Categories= 'tractor,travel'
GO
EXEC SaveEmoji @Name='train', @Path='travel/train.png', @Categories= 'train,travel'
GO
EXEC SaveEmoji @Name='tram-car', @Path='travel/tram-car.png', @Categories= 'car,tram,travel'
GO
EXEC SaveEmoji @Name='tram', @Path='travel/tram.png', @Categories= 'tram,travel'
GO
EXEC SaveEmoji @Name='trolleybus', @Path='travel/trolleybus.png', @Categories= 'travel,trolleybus'
GO
EXEC SaveEmoji @Name='wheel', @Path='travel/wheel.png', @Categories= 'travel,wheel'
GO
EXEC SaveEmoji @Name='alien-monster', @Path='face/alien-monster.png', @Categories= 'activity,alien,face,game,monster'
GO
