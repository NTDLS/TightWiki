IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'PageReferenceType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[PageReferenceType] AS TABLE(
	[PageName] [nvarchar](128) NULL,
	[Namespace] [nvarchar](128) NULL,
	[Navigation] [nvarchar](128) NULL
)
GO
IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'PageTokenType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[PageTokenType] AS TABLE(
	[PageId] [int] NULL,
	[Token] [nvarchar](128) NULL,
	[DoubleMetaphone] [varchar](16) NULL,
	[Weight] [decimal](6, 2) NULL
)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ConfigurationGroup]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ConfigurationGroup](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](128) NOT NULL,
	[Description] [nvarchar](1000) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CryptoCheck]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CryptoCheck](
	[Content] [varbinary](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DataType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DataType](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Emoji]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Emoji](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](128) NOT NULL,
	[ImageData] [varbinary](max) NULL,
	[MimeType] [nvarchar](50) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Exception]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Exception](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Text] [nvarchar](max) NULL,
	[ExceptionText] [nvarchar](max) NULL,
	[StackTrace] [nvarchar](max) NULL,
	[CreatedDate] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MenuItem]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MenuItem](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](128) NOT NULL,
	[Link] [nvarchar](128) NOT NULL,
	[Ordinal] [int] NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Role]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Role](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](128) NOT NULL,
	[Description] [nvarchar](1000) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ConfigurationEntry]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ConfigurationEntry](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ConfigurationGroupId] [int] NOT NULL,
	[Name] [nvarchar](128) NOT NULL,
	[Value] [nvarchar](max) NULL,
	[DataTypeId] [int] NOT NULL,
	[Description] [nvarchar](1000) NULL,
	[IsEncrypted] [bit] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_ConfigurationEntry_IsEncrypted]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[ConfigurationEntry] ADD  CONSTRAINT [DF_ConfigurationEntry_IsEncrypted]  DEFAULT ((0)) FOR [IsEncrypted]
END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EmojiCategory]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EmojiCategory](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EmojiId] [int] NOT NULL,
	[Category] [nvarchar](128) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[User]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[User](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EmailAddress] [nvarchar](128) NOT NULL,
	[AccountName] [nvarchar](128) NOT NULL,
	[Navigation] [nvarchar](128) NULL,
	[PasswordHash] [nvarchar](128) NULL,
	[FirstName] [nvarchar](128) NULL,
	[LastName] [nvarchar](128) NULL,
	[Country] [nvarchar](128) NOT NULL,
	[Language] [nvarchar](128) NOT NULL,
	[TimeZone] [nvarchar](128) NOT NULL,
	[AboutMe] [nvarchar](max) NULL,
	[Avatar] [varbinary](max) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,
	[LastLoginDate] [datetime] NOT NULL,
	[VerificationCode] [varchar](20) NULL,
	[EmailVerified] [bit] NOT NULL,
	[RoleId] [int] NOT NULL,
	[Provider] [varchar](20) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_User_CreatedDate]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[User] ADD  CONSTRAINT [DF_User_CreatedDate]  DEFAULT (getutcdate()) FOR [CreatedDate]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_User_ModifiedDate]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[User] ADD  CONSTRAINT [DF_User_ModifiedDate]  DEFAULT (getutcdate()) FOR [ModifiedDate]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_User_EmailVerified]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[User] ADD  CONSTRAINT [DF_User_EmailVerified]  DEFAULT ((0)) FOR [EmailVerified]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_User_Provider]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[User] ADD  CONSTRAINT [DF_User_Provider]  DEFAULT (N'Login') FOR [Provider]
END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Page]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Page](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](128) NOT NULL,
	[Namespace] [nvarchar](128) NULL,
	[Navigation] [nvarchar](128) NOT NULL,
	[Description] [nvarchar](max) NULL,
	[Revision] [int] NOT NULL,
	[CreatedByUserId] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[ModifiedByUserId] [int] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_Page_Revision]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Page] ADD  CONSTRAINT [DF_Page_Revision]  DEFAULT ((1)) FOR [Revision]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_Page_CreatedDate]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Page] ADD  CONSTRAINT [DF_Page_CreatedDate]  DEFAULT (getdate()) FOR [CreatedDate]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_Page_ModifiedDate]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Page] ADD  CONSTRAINT [DF_Page_ModifiedDate]  DEFAULT (getdate()) FOR [ModifiedDate]
END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PageFile]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PageFile](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PageId] [int] NOT NULL,
	[Name] [nvarchar](250) NOT NULL,
	[Navigation] [nvarchar](250) NOT NULL,
	[Revision] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PageProcessingInstruction]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PageProcessingInstruction](
	[PageId] [int] NOT NULL,
	[Instruction] [nvarchar](128) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PageReference]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PageReference](
	[PageId] [int] NOT NULL,
	[ReferencesPageName] [nvarchar](128) NOT NULL,
	[ReferencesPageNavigation] [nvarchar](128) NOT NULL,
	[ReferencesPageId] [int] NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PageRevision]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PageRevision](
	[PageId] [int] NOT NULL,
	[Name] [nvarchar](128) NOT NULL,
	[Namespace] [nvarchar](128) NULL,
	[Description] [nvarchar](max) NOT NULL,
	[Body] [nvarchar](max) NOT NULL,
	[Revision] [int] NOT NULL,
	[ModifiedByUserId] [int] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,
	[DataHash] [int] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PageStatistics]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PageStatistics](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PageId] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[WikifyTimeMs] [decimal](8, 2) NULL,
	[MatchCount] [int] NULL,
	[ErrorCount] [int] NULL,
	[OutgoingLinkCount] [int] NULL,
	[TagCount] [int] NULL,
	[ProcessedBodySize] [int] NULL,
	[BodySize] [int] NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PageTag]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PageTag](
	[PageId] [int] NOT NULL,
	[Tag] [nvarchar](128) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PageToken]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PageToken](
	[PageId] [int] NOT NULL,
	[Token] [nvarchar](128) NOT NULL,
	[Weight] [decimal](6, 2) NOT NULL,
	[DoubleMetaphone] [varchar](16) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PageFileRevision]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PageFileRevision](
	[PageFileId] [int] NOT NULL,
	[ContentType] [nvarchar](100) NOT NULL,
	[Size] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[Data] [varbinary](max) NOT NULL,
	[Revision] [int] NOT NULL,
	[DataHash] [int] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PageRevisionAttachment]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PageRevisionAttachment](
	[PageId] [int] NOT NULL,
	[PageFileId] [int] NOT NULL,
	[FileRevision] [int] NOT NULL,
	[PageRevision] [int] NOT NULL
) ON [PRIMARY]
END
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[ConfigurationGroup]') AND name = N'PK_ConfigurationGroup')
ALTER TABLE [dbo].[ConfigurationGroup] ADD  CONSTRAINT [PK_ConfigurationGroup] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DataType]') AND name = N'IX_DataType_Name')
CREATE UNIQUE NONCLUSTERED INDEX [IX_DataType_Name] ON [dbo].[DataType]
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DataType]') AND name = N'PK_DataType')
ALTER TABLE [dbo].[DataType] ADD  CONSTRAINT [PK_DataType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Emoji]') AND name = N'IX_Emoji')
ALTER TABLE [dbo].[Emoji] ADD  CONSTRAINT [IX_Emoji] UNIQUE NONCLUSTERED 
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Emoji]') AND name = N'PK_Emoji')
ALTER TABLE [dbo].[Emoji] ADD  CONSTRAINT [PK_Emoji] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Exception]') AND name = N'PK_Exceptions')
ALTER TABLE [dbo].[Exception] ADD  CONSTRAINT [PK_Exceptions] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MenuItem]') AND name = N'IX_MenuItem_Name')
CREATE UNIQUE NONCLUSTERED INDEX [IX_MenuItem_Name] ON [dbo].[MenuItem]
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MenuItem]') AND name = N'PK_MenuItem')
ALTER TABLE [dbo].[MenuItem] ADD  CONSTRAINT [PK_MenuItem] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Role]') AND name = N'PK_Role')
ALTER TABLE [dbo].[Role] ADD  CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[ConfigurationEntry]') AND name = N'PK_ConfigurationEntry')
ALTER TABLE [dbo].[ConfigurationEntry] ADD  CONSTRAINT [PK_ConfigurationEntry] PRIMARY KEY CLUSTERED 
(
	[ConfigurationGroupId] ASC,
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EmojiCategory]') AND name = N'IX_EmojiCategory')
ALTER TABLE [dbo].[EmojiCategory] ADD  CONSTRAINT [IX_EmojiCategory] UNIQUE NONCLUSTERED 
(
	[EmojiId] ASC,
	[Category] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EmojiCategory]') AND name = N'PK_EmojiCategory')
ALTER TABLE [dbo].[EmojiCategory] ADD  CONSTRAINT [PK_EmojiCategory] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[User]') AND name = N'IX_User_AccountName')
CREATE UNIQUE NONCLUSTERED INDEX [IX_User_AccountName] ON [dbo].[User]
(
	[AccountName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[User]') AND name = N'IX_User_Email')
CREATE UNIQUE NONCLUSTERED INDEX [IX_User_Email] ON [dbo].[User]
(
	[EmailAddress] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[User]') AND name = N'PK_User')
ALTER TABLE [dbo].[User] ADD  CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Page]') AND name = N'IX_Page_Name')
CREATE UNIQUE NONCLUSTERED INDEX [IX_Page_Name] ON [dbo].[Page]
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Page]') AND name = N'PK_Page')
ALTER TABLE [dbo].[Page] ADD  CONSTRAINT [PK_Page] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PageFile]') AND name = N'IX_PageFile')
CREATE UNIQUE NONCLUSTERED INDEX [IX_PageFile] ON [dbo].[PageFile]
(
	[Name] ASC,
	[PageId] ASC,
	[Revision] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PageFile]') AND name = N'PK_PageFile')
ALTER TABLE [dbo].[PageFile] ADD  CONSTRAINT [PK_PageFile] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PageProcessingInstruction]') AND name = N'PK_ProcessingInstruction')
ALTER TABLE [dbo].[PageProcessingInstruction] ADD  CONSTRAINT [PK_ProcessingInstruction] PRIMARY KEY CLUSTERED 
(
	[PageId] ASC,
	[Instruction] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PageReference]') AND name = N'PK_PageReference')
ALTER TABLE [dbo].[PageReference] ADD  CONSTRAINT [PK_PageReference] PRIMARY KEY CLUSTERED 
(
	[PageId] ASC,
	[ReferencesPageNavigation] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PageRevision]') AND name = N'PK_PageRevision')
ALTER TABLE [dbo].[PageRevision] ADD  CONSTRAINT [PK_PageRevision] PRIMARY KEY CLUSTERED 
(
	[PageId] ASC,
	[Revision] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PageStatistics]') AND name = N'PK_PageStatistics')
ALTER TABLE [dbo].[PageStatistics] ADD  CONSTRAINT [PK_PageStatistics] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PageTag]') AND name = N'PK_PageTag')
ALTER TABLE [dbo].[PageTag] ADD  CONSTRAINT [PK_PageTag] PRIMARY KEY CLUSTERED 
(
	[PageId] ASC,
	[Tag] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PageToken]') AND name = N'PageToken_Covering')
CREATE UNIQUE NONCLUSTERED INDEX [PageToken_Covering] ON [dbo].[PageToken]
(
	[Token] ASC,
	[DoubleMetaphone] ASC,
	[Weight] ASC,
	[PageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PageToken]') AND name = N'PK_PageToken')
ALTER TABLE [dbo].[PageToken] ADD  CONSTRAINT [PK_PageToken] PRIMARY KEY CLUSTERED 
(
	[PageId] ASC,
	[Token] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PageFileRevision]') AND name = N'PK_PageFileRevision_1')
ALTER TABLE [dbo].[PageFileRevision] ADD  CONSTRAINT [PK_PageFileRevision_1] PRIMARY KEY CLUSTERED 
(
	[PageFileId] ASC,
	[Revision] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PageRevisionAttachment]') AND name = N'PK_PageRevisionAttachment')
ALTER TABLE [dbo].[PageRevisionAttachment] ADD  CONSTRAINT [PK_PageRevisionAttachment] PRIMARY KEY CLUSTERED 
(
	[PageId] ASC,
	[PageFileId] ASC,
	[FileRevision] ASC,
	[PageRevision] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ConfigurationEntry_ConfigurationGroup]') AND parent_object_id = OBJECT_ID(N'[dbo].[ConfigurationEntry]'))
ALTER TABLE [dbo].[ConfigurationEntry]  WITH NOCHECK ADD  CONSTRAINT [FK_ConfigurationEntry_ConfigurationGroup] FOREIGN KEY([ConfigurationGroupId])
REFERENCES [dbo].[ConfigurationGroup] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ConfigurationEntry_ConfigurationGroup]') AND parent_object_id = OBJECT_ID(N'[dbo].[ConfigurationEntry]'))
ALTER TABLE [dbo].[ConfigurationEntry] CHECK CONSTRAINT [FK_ConfigurationEntry_ConfigurationGroup]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ConfigurationEntry_DataType]') AND parent_object_id = OBJECT_ID(N'[dbo].[ConfigurationEntry]'))
ALTER TABLE [dbo].[ConfigurationEntry]  WITH CHECK ADD  CONSTRAINT [FK_ConfigurationEntry_DataType] FOREIGN KEY([DataTypeId])
REFERENCES [dbo].[DataType] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ConfigurationEntry_DataType]') AND parent_object_id = OBJECT_ID(N'[dbo].[ConfigurationEntry]'))
ALTER TABLE [dbo].[ConfigurationEntry] CHECK CONSTRAINT [FK_ConfigurationEntry_DataType]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EmojiCategory_Emoji]') AND parent_object_id = OBJECT_ID(N'[dbo].[EmojiCategory]'))
ALTER TABLE [dbo].[EmojiCategory]  WITH CHECK ADD  CONSTRAINT [FK_EmojiCategory_Emoji] FOREIGN KEY([EmojiId])
REFERENCES [dbo].[Emoji] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EmojiCategory_Emoji]') AND parent_object_id = OBJECT_ID(N'[dbo].[EmojiCategory]'))
ALTER TABLE [dbo].[EmojiCategory] CHECK CONSTRAINT [FK_EmojiCategory_Emoji]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User]  WITH CHECK ADD  CONSTRAINT [FK_User_Role] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Role] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_User_Role]') AND parent_object_id = OBJECT_ID(N'[dbo].[User]'))
ALTER TABLE [dbo].[User] CHECK CONSTRAINT [FK_User_Role]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Page_Page_Modified]') AND parent_object_id = OBJECT_ID(N'[dbo].[Page]'))
ALTER TABLE [dbo].[Page]  WITH CHECK ADD  CONSTRAINT [FK_Page_Page_Modified] FOREIGN KEY([CreatedByUserId])
REFERENCES [dbo].[User] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Page_Page_Modified]') AND parent_object_id = OBJECT_ID(N'[dbo].[Page]'))
ALTER TABLE [dbo].[Page] CHECK CONSTRAINT [FK_Page_Page_Modified]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Page_User_Created]') AND parent_object_id = OBJECT_ID(N'[dbo].[Page]'))
ALTER TABLE [dbo].[Page]  WITH CHECK ADD  CONSTRAINT [FK_Page_User_Created] FOREIGN KEY([CreatedByUserId])
REFERENCES [dbo].[User] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Page_User_Created]') AND parent_object_id = OBJECT_ID(N'[dbo].[Page]'))
ALTER TABLE [dbo].[Page] CHECK CONSTRAINT [FK_Page_User_Created]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageFile_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageFile]'))
ALTER TABLE [dbo].[PageFile]  WITH CHECK ADD  CONSTRAINT [FK_PageFile_Page] FOREIGN KEY([PageId])
REFERENCES [dbo].[Page] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageFile_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageFile]'))
ALTER TABLE [dbo].[PageFile] CHECK CONSTRAINT [FK_PageFile_Page]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ProcessingInstruction_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageProcessingInstruction]'))
ALTER TABLE [dbo].[PageProcessingInstruction]  WITH CHECK ADD  CONSTRAINT [FK_ProcessingInstruction_Page] FOREIGN KEY([PageId])
REFERENCES [dbo].[Page] ([Id])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ProcessingInstruction_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageProcessingInstruction]'))
ALTER TABLE [dbo].[PageProcessingInstruction] CHECK CONSTRAINT [FK_ProcessingInstruction_Page]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageReference_PageId]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageReference]'))
ALTER TABLE [dbo].[PageReference]  WITH CHECK ADD  CONSTRAINT [FK_PageReference_PageId] FOREIGN KEY([PageId])
REFERENCES [dbo].[Page] ([Id])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageReference_PageId]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageReference]'))
ALTER TABLE [dbo].[PageReference] CHECK CONSTRAINT [FK_PageReference_PageId]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageRevision_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageRevision]'))
ALTER TABLE [dbo].[PageRevision]  WITH CHECK ADD  CONSTRAINT [FK_PageRevision_Page] FOREIGN KEY([PageId])
REFERENCES [dbo].[Page] ([Id])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageRevision_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageRevision]'))
ALTER TABLE [dbo].[PageRevision] CHECK CONSTRAINT [FK_PageRevision_Page]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageRevision_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageRevision]'))
ALTER TABLE [dbo].[PageRevision]  WITH CHECK ADD  CONSTRAINT [FK_PageRevision_User] FOREIGN KEY([ModifiedByUserId])
REFERENCES [dbo].[User] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageRevision_User]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageRevision]'))
ALTER TABLE [dbo].[PageRevision] CHECK CONSTRAINT [FK_PageRevision_User]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageStatistics_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageStatistics]'))
ALTER TABLE [dbo].[PageStatistics]  WITH CHECK ADD  CONSTRAINT [FK_PageStatistics_Page] FOREIGN KEY([PageId])
REFERENCES [dbo].[Page] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageStatistics_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageStatistics]'))
ALTER TABLE [dbo].[PageStatistics] CHECK CONSTRAINT [FK_PageStatistics_Page]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageTag_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageTag]'))
ALTER TABLE [dbo].[PageTag]  WITH CHECK ADD  CONSTRAINT [FK_PageTag_Page] FOREIGN KEY([PageId])
REFERENCES [dbo].[Page] ([Id])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageTag_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageTag]'))
ALTER TABLE [dbo].[PageTag] CHECK CONSTRAINT [FK_PageTag_Page]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageToken_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageToken]'))
ALTER TABLE [dbo].[PageToken]  WITH CHECK ADD  CONSTRAINT [FK_PageToken_Page] FOREIGN KEY([PageId])
REFERENCES [dbo].[Page] ([Id])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageToken_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageToken]'))
ALTER TABLE [dbo].[PageToken] CHECK CONSTRAINT [FK_PageToken_Page]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageFileRevision_PageFile]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageFileRevision]'))
ALTER TABLE [dbo].[PageFileRevision]  WITH CHECK ADD  CONSTRAINT [FK_PageFileRevision_PageFile] FOREIGN KEY([PageFileId])
REFERENCES [dbo].[PageFile] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageFileRevision_PageFile]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageFileRevision]'))
ALTER TABLE [dbo].[PageFileRevision] CHECK CONSTRAINT [FK_PageFileRevision_PageFile]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageRevisionAttachment_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageRevisionAttachment]'))
ALTER TABLE [dbo].[PageRevisionAttachment]  WITH CHECK ADD  CONSTRAINT [FK_PageRevisionAttachment_Page] FOREIGN KEY([PageId])
REFERENCES [dbo].[Page] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageRevisionAttachment_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageRevisionAttachment]'))
ALTER TABLE [dbo].[PageRevisionAttachment] CHECK CONSTRAINT [FK_PageRevisionAttachment_Page]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageRevisionAttachment_PageFile]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageRevisionAttachment]'))
ALTER TABLE [dbo].[PageRevisionAttachment]  WITH CHECK ADD  CONSTRAINT [FK_PageRevisionAttachment_PageFile] FOREIGN KEY([PageFileId])
REFERENCES [dbo].[PageFile] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageRevisionAttachment_PageFile]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageRevisionAttachment]'))
ALTER TABLE [dbo].[PageRevisionAttachment] CHECK CONSTRAINT [FK_PageRevisionAttachment_PageFile]
GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[CreateUser]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CreateUser] AS'
END
GO

ALTER PROCEDURE [dbo].[CreateUser]
(
	@EmailAddress as nvarchar (128),
	@AccountName as nvarchar (128),
	@Navigation as nvarchar (128) = NULL,
	@PasswordHash as nvarchar (128) = NULL,
	@FirstName as nvarchar (128) = NULL,
	@LastName as nvarchar (128) = NULL,
	@TimeZone as nvarchar (128) = NULL,
	@Language as nvarchar (128) = NULL,
	@Country as nvarchar (128) = NULL,
	@Role as nvarchar(128),
	@VerificationCode varchar(20),
	@Provider varchar(20)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	INSERT INTO [User]
	(
		[EmailAddress],
		[AccountName],
		[Navigation],
		[PasswordHash],
		[FirstName],
		[LastName],
		[TimeZone],
		[Country],
		[Language],
		[CreatedDate],
		[ModifiedDate],
		[LastLoginDate],
		[RoleId],
		[VerificationCode],
		[Provider]
	)
	SELECT
		@EmailAddress,
		@AccountName,
		@Navigation,
		@PasswordHash,
		@FirstName,
		@LastName,
		@TimeZone,
		@Country,
		@Language,
		GETUTCDATE(),
		GETUTCDATE(),
		GETUTCDATE(),
		R.Id,
		@VerificationCode,
		@Provider
	FROM
		[Role] as R
	WHERE
		R.[Name] = @Role

	SELECT cast(SCOPE_IDENTITY() as int) as UserId

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[DeleteById]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DeleteById] AS'
END
GO




ALTER   PROCEDURE [dbo].[DeleteById]
(
	@UserId int
) as
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM [User]

	UPDATE
		[User]
	SET
		EmailAddress = 'DeletedAccount' + Cast(@UserId as nVarChar(30)) + '@unknown.void',
		AccountName = 'Deleted Account ' + Cast(@UserId as nVarChar(30)),
		Navigation = 'deleted_account' + Cast(@UserId as nVarChar(30)),
		PasswordHash = HASHBYTES('SHA2_256', Convert(nvarchar(36), NewID())),
		FirstName = 'Deleted',
		LastName = 'Account',
		AboutMe = '',
		Avatar = null,
		ModifiedDate = GETUTCDATE(),
		VerificationCode = null,
		EmailVerified = 0
	FROM
		[User]
	WHERE
		Id = @UserId

END


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[DeleteEmojiById]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DeleteEmojiById] AS'
END
GO

ALTER PROCEDURE [dbo].[DeleteEmojiById]
(
	@Id int
) as
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DELETE FROM EmojiCategory WHERE EmojiId = @Id
	DELETE FROM Emoji WHERE Id = @Id

END--PROCEDURE



GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[DeletePageById]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DeletePageById] AS'
END
GO

ALTER PROCEDURE [dbo].[DeletePageById]
(
	@PageId int
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DELETE FROM [PageStatistics] WHERE PageId = @PageId
	DELETE FROM [PageRevision] WHERE PageId = @PageId
	DELETE FROM [PageTag] WHERE PageId = @PageId
	DELETE FROM [PageRevisionAttachment] WHERE PageId = @PageId
	DELETE FROM [PageFile] WHERE PageId = @PageId
	DELETE FROM [PageToken] WHERE PageId = @PageId
	DELETE FROM [PageProcessingInstruction] WHERE PageId = @PageId
	DELETE FROM [Page] WHERE Id = @PageId

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[DeletePageFileByPageNavigationAndFileName]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DeletePageFileByPageNavigationAndFileName] AS'
END
GO







ALTER PROCEDURE [dbo].[DeletePageFileByPageNavigationAndFileName]
(
	@PageNavigation nVarChar(128),
    @FileNavigation nVarChar(250)
) AS
BEGIN--PROCEDURE

	DELETE
		PRA
	FROM
		[PageFile] as PF
	INNER JOIN [Page] as P
		ON P.Id = PF.PageId
	INNER JOIN [PageRevision] as PR
		ON PR.PageId = P.Id
	INNER JOIN PageRevisionAttachment as PRA
		ON PRA.PageId = P.Id
		AND PRA.PageFileId = PF.Id
		AND PRA.PageRevision = PR.Revision
	INNER JOIN PageFileRevision as PFR
		ON PFR.PageFileId = PF.Id
		AND PFR.Revision = PRA.FileRevision
	WHERE
		P.Navigation = @PageNavigation
		AND PF.Navigation = @FileNavigation
		
END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[DoesAccountNameExist]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DoesAccountNameExist] AS'
END
GO







ALTER PROCEDURE [dbo].[DoesAccountNameExist]
(
	@AccountName nvarchar(128)
)AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT TOP 1
		1
	FROM
		[User]
	WHERE
		AccountName = @AccountName

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[DoesEmailAddressExist]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DoesEmailAddressExist] AS'
END
GO








ALTER PROCEDURE [dbo].[DoesEmailAddressExist]
(
	@EmailAddress nvarchar(128)
)AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT TOP 1
		1
	FROM
		[User]
	WHERE
		[EMailAddress] = @EmailAddress

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetAllEmojis]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetAllEmojis] AS'
END
GO

ALTER PROCEDURE [dbo].[GetAllEmojis] AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		[Id],
		[Name],
		MimeType,
		'::' + lower([Name]) + '::' as [Shortcut]
	FROM
		Emoji
	ORDER BY
		[Name]

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetAllEmojisPaged]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetAllEmojisPaged] AS'
END
GO

ALTER PROCEDURE [dbo].[GetAllEmojisPaged]
(
	@Categories nVarChar(500) = NULL,
	@PageNumber int = 1,
	@PageSize int = 0
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @PaginationSize int = @PageSize

	DECLARE @SearchTokenCount INT
	SELECT @SearchTokenCount = COUNT(DISTINCT [value]) FROM STRING_SPLIT(@Categories, ',') as SS

	DECLARE @SearchResults TABLE (EmojiId INT)
	INSERT INTO @SearchResults
	SELECT
		EmojiId
	FROM
		STRING_SPLIT(@Categories, ',') as SS
	INNER JOIN EmojiCategory as EC
		ON EC.Category LIKE SS.[value] + '%'
	GROUP BY
		EmojiId
	HAVING
		COUNT(0) >= @SearchTokenCount

	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	SELECT
		E.Id,
		E.[Name],
		E.MimeType,
		'::' + lower(E.[Name]) + '::' as Shortcut,
		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(0) / (@PaginationSize + 0.0))
			FROM
				Emoji as iE
			WHERE
				IsNull(@SearchTokenCount, 0) = 0
				OR iE.Id IN (SELECT EmojiId FROM @SearchResults)
		) as PaginationCount
	FROM
		Emoji as E
	WHERE
		IsNull(@SearchTokenCount, 0) = 0
		OR E.Id IN (SELECT EmojiId FROM @SearchResults)
	ORDER BY
		E.[Name]
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE

GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetAllMenuItems]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetAllMenuItems] AS'
END
GO







ALTER PROCEDURE [dbo].[GetAllMenuItems] AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		[Id] as [Id],
		[Name] as [Name],
		[Link] as [Link],
		[Ordinal] as [Ordinal]
	FROM
		[MenuItem]
	ORDER BY
		[Ordinal]

END--PROCEDURE



GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetAllNamespaces]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetAllNamespaces] AS'
END
GO



ALTER   PROCEDURE [dbo].[GetAllNamespaces] AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		[Namespace],
		Count(0) as [CountOfPages]
	FROM
		[Page]
	GROUP BY
		[Namespace]

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetAllNamespacesPaged]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetAllNamespacesPaged] AS'
END
GO




ALTER   PROCEDURE[dbo].[GetAllNamespacesPaged]
(
	@PageNumber int = 1,
	@PageSize int = 0
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @PaginationSize int = @PageSize
	
	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	DECLARE @PageIDs TABLE
	(
		Id INT
	)

	SELECT
		P.[Namespace],
		Count(0) as [CountOfPages],

		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(DISTINCT P.[Namespace]) / (@PaginationSize + 0.0))
			FROM
				[Page] as P
		) as PaginationCount
	FROM
		[Page] as P
	GROUP BY
		[Namespace]
	ORDER BY
		P.[Namespace]
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetAllPages]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetAllPages] AS'
END
GO





ALTER PROCEDURE [dbo].[GetAllPages] AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		P.Id,
		P.[Name],
		P.[Description],
		PR.Body,
		PR.Revision,
		P.Navigation,
		P.CreatedByUserId,
		P.CreatedDate,
		P.ModifiedByUserId,
		P.ModifiedDate
	FROM
		[Page] as P
	INNER JOIN [PageRevision] as PR
		ON PR.PageId = P.Id
	WHERE
		PR.Revision = P.Revision

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetAllPagesByInstructionPaged]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetAllPagesByInstructionPaged] AS'
END
GO




ALTER PROCEDURE [dbo].[GetAllPagesByInstructionPaged]
(
	@PageNumber int = 1,
	@PageSize int = 0,
	@Instruction nvarchar(128)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @PaginationSize int = @PageSize
	
	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	SELECT
		P.Id,
		P.[Name],
		P.Navigation,
		P.[Description],
		P.Revision,
		P.CreatedByUserId,
		P.CreatedDate,
		P.ModifiedByUserId,
		P.ModifiedDate,
		Createduser.AccountName as CreatedByUserName,
		ModifiedUser.AccountName as ModifiedByUserName,
		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(0) / (@PaginationSize + 0.0))
			FROM
				[Page] as P
			INNER JOIN PageProcessingInstruction as PPI
				ON PPI.PageId = P.Id
			WHERE
				PPI.Instruction = @Instruction
		) as PaginationCount
	FROM
		[Page] as P
	INNER JOIN [User] as ModifiedUser
		ON ModifiedUser.Id = P.ModifiedByUserId
	INNER JOIN [User] as Createduser
		ON Createduser.Id = P.CreatedByUserId
	INNER JOIN PageProcessingInstruction as PPI
		ON PPI.PageId = P.Id
	WHERE
		PPI.Instruction = @Instruction
	ORDER BY
		P.[Name],
		P.Id
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetAllPagesPaged]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetAllPagesPaged] AS'
END
GO





ALTER PROCEDURE [dbo].[GetAllPagesPaged]
(
	@PageNumber int = 1,
	@PageSize int = 0,
	@SearchTerms nvarchar(MAX) = null
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @PaginationSize int = @PageSize
	
	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	DECLARE @PageIDs TABLE
	(
		Id INT
	)

	DECLARE @Tokens INT = (SELECT COUNT(0) FROM STRING_SPLIT(@SearchTerms ,','))

	INSERT INTO @PageIDs
	(
		Id
	)
	SELECT
		T.PageId
	FROM
		PageToken as T
	INNER JOIN STRING_SPLIT(@SearchTerms ,',') as ST
		ON ST.[value] = T.Token
	WHERE
		IsNull(ST.[value], '') <> ''
	GROUP BY
		T.PageId
	HAVING
		Count(0) = @Tokens

	SELECT
		P.Id,
		P.[Name],
		P.Navigation,
		P.[Description],
		P.Revision,
		P.CreatedByUserId,
		P.CreatedDate,
		P.ModifiedByUserId,
		P.ModifiedDate,
		Createduser.AccountName as CreatedByUserName,
		ModifiedUser.AccountName as ModifiedByUserName,
		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(0) / (@PaginationSize + 0.0))
			FROM
				[Page] as P
			WHERE
				(IsNull(@SearchTerms, '') = ''
					OR P.Id IN (SELECT PID.Id FROM @PageIDs as PID)
		)
		) as PaginationCount
	FROM
		[Page] as P
	INNER JOIN [User] as ModifiedUser
		ON ModifiedUser.Id = P.ModifiedByUserId
	INNER JOIN [User] as Createduser
		ON Createduser.Id = P.CreatedByUserId
	WHERE
		(IsNull(@SearchTerms, '') = ''
			OR P.Id IN (SELECT PID.Id FROM @PageIDs as PID)
		)
	ORDER BY
		P.[Name],
		P.Id
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetAllRoles]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetAllRoles] AS'
END
GO







ALTER PROCEDURE [dbo].[GetAllRoles] AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		Id,
		[Name],
		[Description]
	FROM
		[Role]
	ORDER BY
		[Name]

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetAllUsersPaged]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetAllUsersPaged] AS'
END
GO





ALTER PROCEDURE  [dbo].[GetAllUsersPaged]
(
	@PageNumber int = 1,
	@PageSize int = 0,
	@SearchToken nvarchar(256) = null
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SET @SearchToken = NullIf(@SearchToken, '')

	DECLARE @PaginationSize int = @PageSize
	
	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	SELECT
		U.Id,
		U.EmailAddress,
		U.AccountName,
		U.Navigation,
		U.PasswordHash,
		U.FirstName,
		U.LastName,
		U.TimeZone,
		U.[Language],
		U.Country,
		U.CreatedDate,
		U.ModifiedDate,
		U.LastLoginDate,
		U.EmailVerified,
		R.[Name] as [Role],
		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(0) / (@PaginationSize + 0.0))
			FROM
				[User] as P
			WHERE
				@SearchToken IS NULL
				OR AccountName LIKE '%' + @SearchToken + '%'
				OR EmailAddress LIKE '%' + @SearchToken + '%'
				OR FirstName LIKE '%' + @SearchToken + '%'
				OR LastName LIKE '%' + @SearchToken + '%'
		) as PaginationCount
	FROM
		[User] as U
	INNER JOIN [Role] as R
		ON R.Id = U.RoleId
	WHERE
		@SearchToken IS NULL
		OR U.AccountName LIKE '%' + @SearchToken + '%'
		OR U.EmailAddress LIKE '%' + @SearchToken + '%'
		OR U.FirstName LIKE '%' + @SearchToken + '%'
		OR U.LastName LIKE '%' + @SearchToken + '%'
	ORDER BY
		U.AccountName,
		U.Id
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetAssociatedTags]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetAssociatedTags] AS'
END
GO







ALTER PROCEDURE [dbo].[GetAssociatedTags]
(
	@Tag nvarchar(128)	
) AS
BEGIN--PROCEDURE
	SELECT TOP 100
		[Extent].[Tag],
		Count(DISTINCT [Extent].PageId) as [PageCount]
	FROM
		PageTag as [Root]
	INNER JOIN PageTag as [Interm]
		ON [Interm].[Tag] = [Root].[Tag]
		AND [Interm].[PageId] = [Root].[PageId]
	INNER JOIN PageTag as [Extent]
		ON [Extent].[PageId] = [Interm].[PageId]
	WHERE
		[Root].[Tag] = @Tag
	GROUP BY
		[Extent].[Tag]
END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetConfigurationEntryValuesByGroupName]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetConfigurationEntryValuesByGroupName] AS'
END
GO







ALTER PROCEDURE [dbo].[GetConfigurationEntryValuesByGroupName]
(
	@GroupName nVarchar(128)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;
		
	SELECT
		CE.[Id] as [Id],
		CE.[ConfigurationGroupId] as [ConfigurationGroupId],
		CE.[Name] as [Name],
		CE.[Value] as [Value],
		CE.[IsEncrypted] as [IsEncrypted],
		CE.[Description] as [Description]
	FROM
		[ConfigurationEntry] as CE
	INNER JOIN [ConfigurationGroup] as CG
		ON CG.Id = CE.ConfigurationGroupId
	WHERE
		CG.[Name] = @GroupName

END--PROCEDURE



GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetConfigurationEntryValuesByGroupNameAndEntryName]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetConfigurationEntryValuesByGroupNameAndEntryName] AS'
END
GO







ALTER PROCEDURE [dbo].[GetConfigurationEntryValuesByGroupNameAndEntryName]
(
	@GroupName nVarchar(128),
	@entryName nVarchar(128)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;
		
	SELECT
		CE.[Id] as [Id],
		CE.[ConfigurationGroupId] as [ConfigurationGroupId],
		CE.[Name] as [Name],
		CE.[Value] as [Value],
		CE.[Description] as [Description]
	FROM
		[ConfigurationEntry] as CE
	INNER JOIN [ConfigurationGroup] as CG
		ON CG.Id = CE.ConfigurationGroupId
	WHERE
		CG.[Name] = @GroupName
		AND CE.[Name] = @entryName

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetCountOfPageAttachmentsById]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetCountOfPageAttachmentsById] AS'
END
GO







ALTER PROCEDURE [dbo].[GetCountOfPageAttachmentsById]
(
	@PageId int
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		Count(0) as Attachments
	FROM
		PageFile
	WHERE
		PageId = @PageId
		

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetEmojiByName]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetEmojiByName] AS'
END
GO

ALTER PROCEDURE [dbo].[GetEmojiByName]
(
	@Name nVarChar(128)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		E.Id,
		E.[Name],
		E.MimeType,
		'::' + lower(E.[Name]) + '::' as Shortcut,
		CAST(DECOMPRESS(ImageData) as VARBINARY(MAX)) as ImageData
	FROM
		Emoji as E
	WHERE
		E.[Name] = @Name

END--PROCEDURE

GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetEmojiCategoriesByName]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetEmojiCategoriesByName] AS'
END
GO

ALTER PROCEDURE [dbo].[GetEmojiCategoriesByName]
(
	@Name nVarChar(128)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		Ec.Id,
		EC.EmojiId,
		EC.Category
	FROM
		Emoji as E
	INNER JOIN EmojiCategory as EC
		ON EC.EmojiId = E.Id
	WHERE
		E.[Name] = @Name

END--PROCEDURE

GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetEmojiCategoriesGrouped]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetEmojiCategoriesGrouped] AS'
END
GO

ALTER PROCEDURE [dbo].[GetEmojiCategoriesGrouped] AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		Category,
		(
			SELECT
				Count(0)
			FROM
				EmojiCategory as iEC
			INNER JOIN Emoji as iE
				ON iE.Id = iEC.EmojiId
			WHERE
				iEC.Category = EC.Category
		) as EmojiCount
	FROM
		EmojiCategory as EC
	INNER JOIN Emoji as E
		ON E.Id = EC.EmojiId
	WHERE
		E.[Name] NOT LIKE + '%' + EC.Category + '%'
	GROUP BY
		Category
	ORDER BY
		Category

END--PROCEDURE

GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetEmojisByCategory]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetEmojisByCategory] AS'
END
GO

ALTER PROCEDURE [dbo].[GetEmojisByCategory]
(
	@Category VarChar(128)
)
AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT DISTINCT
		E.[Id],
		E.[Name],
		E.MimeType,
		'::' + lower([Name]) + '::' as [Shortcut]
	FROM
		Emoji as E
	INNER JOIN EmojiCategory as EC
		ON EC.EmojiId = E.Id
	WHERE
		EC.Category = @Category
	ORDER BY
		E.[Name]

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetFlatConfiguration]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetFlatConfiguration] AS'
END
GO







ALTER PROCEDURE [dbo].[GetFlatConfiguration] AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;
		
	SELECT
		CG.Id as [GroupId],
		CG.[Name] as [GroupName],
		CG.[Description] as [GroupDescription],

		CE.[Id] as [EntryId],
		CE.[Name] as [EntryName],
		CE.[Value] as [EntryValue],
		CE.[Description] as [EntryDescription],
		CE.IsEncrypted,

		DT.[Name] as DataType
	FROM
		[ConfigurationEntry] as CE
	INNER JOIN [ConfigurationGroup] as CG
		ON CG.Id = CE.ConfigurationGroupId
	INNER JOIN DataType as DT
		ON DT.Id = CE.DataTypeId

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetNonexistentPagesPaged]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetNonexistentPagesPaged] AS'
END
GO

ALTER PROCEDURE [dbo].[GetNonexistentPagesPaged]
(
	@PageNumber int = 1,
	@PageSize int = 0
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @PaginationSize int = @PageSize
	
	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	SELECT
		P.Id as SourcePageId,
		P.[Name] as SourcePageName,
		P.[Navigation] as SourcePageNavigation,
		PR.ReferencesPageName as TargetPageName,
		PR.ReferencesPageNavigation as TargetPageNavigation,
		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(0) / (@PaginationSize + 0.0))
			FROM
				PageReference as PR
			INNER JOIN [Page] as P
				ON P.Id = PR.PageId
			WHERE
				PR.ReferencesPageId IS NULL
		) as PaginationCount
	FROM
		PageReference as PR
	INNER JOIN [Page] as P
		ON P.Id = PR.PageId
	WHERE
		PR.ReferencesPageId IS NULL
	ORDER BY
		P.[Name],
		PR.PageId
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE

GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageFileAttachmentByPageNavigationPageRevisionAndFileNavigation]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageFileAttachmentByPageNavigationPageRevisionAndFileNavigation] AS'
END
GO

ALTER PROCEDURE [dbo].[GetPageFileAttachmentByPageNavigationPageRevisionAndFileNavigation]
(
	@PageNavigation nVarChar(128),
	@FileNavigation nVarChar(128),
	@PageRevision int = NULL
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		PF.[Id] as [Id],
		PF.[PageId] as [PageId],
		PF.[Name] as [Name],
		PFR.[ContentType] as [ContentType],
		PFR.[Size] as [Size],
		PFR.[Data],
		PF.[CreatedDate] as [CreatedDate],
		PFR.[Data] as [Data]
	FROM
		[PageFile] as PF
	INNER JOIN [Page] as P
		ON P.Id = PF.PageId
	INNER JOIN [PageRevision] as PR
		ON PR.PageId = P.Id
	INNER JOIN PageRevisionAttachment as PRA
		ON PRA.PageId = P.Id
		AND PRA.PageFileId = PF.Id
		AND PRA.PageRevision = PR.Revision
		AND PRA.FileRevision = PF.Revision --Latest file revision.
	INNER JOIN PageFileRevision as PFR
		ON PFR.PageFileId = PF.Id
		AND PFR.Revision = PRA.FileRevision
	WHERE
		P.Navigation = @PageNavigation
		AND PF.Navigation = @FileNavigation
		AND PR.Revision = IsNull(@PageRevision, P.Revision)

END--PROCEDURE

GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageFileAttachmentInfoByPageNavigationPageRevisionAndFileNavigation]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageFileAttachmentInfoByPageNavigationPageRevisionAndFileNavigation] AS'
END
GO







ALTER PROCEDURE [dbo].[GetPageFileAttachmentInfoByPageNavigationPageRevisionAndFileNavigation]
(
	@PageNavigation nVarChar(128),
	@FileNavigation nVarChar(128),
	@PageRevision int = NULL
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		PF.[Id] as [Id],
		PF.[PageId] as [PageId],
		PF.[Name] as [Name],
		PFR.[ContentType] as [ContentType],
		PFR.[Size] as [Size],
		PF.[CreatedDate] as [CreatedDate],
		PFR.[Data] as [Data]
	FROM
		[PageFile] as PF
	INNER JOIN [Page] as P
		ON P.Id = PF.PageId
	INNER JOIN [PageRevision] as PR
		ON PR.PageId = P.Id
	INNER JOIN PageRevisionAttachment as PRA
		ON PRA.PageId = P.Id
		AND PRA.PageFileId = PF.Id
		AND PRA.PageRevision = PR.Revision
		AND PRA.FileRevision = PF.Revision --Latest file revision.
	INNER JOIN PageFileRevision as PFR
		ON PFR.PageFileId = PF.Id
		AND PFR.Revision = PRA.FileRevision
	WHERE
		P.Navigation = @PageNavigation
		AND PF.Navigation = @FileNavigation
		AND PR.Revision = IsNull(@PageRevision, P.Revision)


END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageFileInfoByPageIdPageRevisionAndName]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageFileInfoByPageIdPageRevisionAndName] AS'
END
GO








ALTER PROCEDURE [dbo].[GetPageFileInfoByPageIdPageRevisionAndName]
(
	@PageId Int,
	@FileName nVarChar(500),
	@PageRevision int = NULL
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		PF.[Id] as [Id],
		PF.[PageId] as [PageId],
		PF.[Name] as [Name],
		PFR.[ContentType] as [ContentType],
		PFR.[Size] as [Size],
		PF.[CreatedDate] as [CreatedDate]
	FROM
		[PageFile] as PF
	INNER JOIN [Page] as P
		ON P.Id = PF.PageId
	INNER JOIN [PageRevision] as PR
		ON PR.PageId = P.Id
	INNER JOIN PageRevisionAttachment as PRA
		ON PRA.PageId = P.Id
		AND PRA.PageFileId = PF.Id
		AND PRA.PageRevision = PR.Revision
	INNER JOIN PageFileRevision as PFR
		ON PFR.PageFileId = PF.Id
		AND PFR.Revision = PRA.FileRevision
	WHERE
		P.Id = @PageId
		AND PF.[Name] = @FileName
		AND PR.Revision = IsNull(@PageRevision, P.Revision)

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageFilesInfoByPageIdAndPageRevision]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageFilesInfoByPageIdAndPageRevision] AS'
END
GO







ALTER PROCEDURE [dbo].[GetPageFilesInfoByPageIdAndPageRevision]
(
	@PageId Int,
	@PageRevision int = NULL
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		PF.[Id] as [Id],
		PF.[PageId] as [PageId],
		PF.[Name] as [Name],
		PFR.[ContentType] as [ContentType],
		PFR.[Size] as [Size],
		PF.[CreatedDate] as [CreatedDate],
		PR.Revision as PageRevision,
		PFR.Revision as FileRevision,
		PF.Navigation as FileNavigation,
		P.Navigation as PageNavigation
	FROM
		[PageFile] as PF
	INNER JOIN [Page] as P
		ON P.Id = PF.PageId
	INNER JOIN [PageRevision] as PR
		ON PR.PageId = P.Id
	INNER JOIN PageRevisionAttachment as PRA
		ON PRA.PageId = P.Id
		AND PRA.PageFileId = PF.Id
		AND PRA.PageRevision = PR.Revision
		AND PRA.FileRevision = PF.Revision --Latest file revision.
	INNER JOIN PageFileRevision as PFR
		ON PFR.PageFileId = PF.Id
		AND PFR.Revision = PRA.FileRevision
	WHERE
		P.Id = @PageId
		AND PR.Revision = IsNull(@PageRevision, P.Revision)

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageFilesInfoByPageNavigationAndPageRevisionPaged]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageFilesInfoByPageNavigationAndPageRevisionPaged] AS'
END
GO




ALTER PROCEDURE [dbo].[GetPageFilesInfoByPageNavigationAndPageRevisionPaged]
(
	@PageNavigation nvarchar(128),
	@PageRevision int = NULL,
	@PageNumber int = 1,
	@PageSize int = 0
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @PaginationSize int = @PageSize
	
	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	SELECT
		PF.[Id] as [Id],
		PF.[PageId] as [PageId],
		PF.[Name] as [Name],
		PFR.[ContentType] as [ContentType],
		PFR.[Size] as [Size],
		PF.[CreatedDate] as [CreatedDate],
		PR.Revision as PageRevision,
		PFR.Revision as FileRevision,
		PF.Navigation as FileNavigation,
		P.Navigation as PageNavigation,
		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(0) / (@PaginationSize + 0.0))
			FROM
				[PageFile] as PF
			INNER JOIN [Page] as P
				ON P.Id = PF.PageId
			INNER JOIN [PageRevision] as PR
				ON PR.PageId = P.Id
			INNER JOIN PageRevisionAttachment as PRA
				ON PRA.PageId = P.Id
				AND PRA.PageFileId = PF.Id
				AND PRA.PageRevision = PR.Revision
				AND PRA.FileRevision = PF.Revision --Latest file revision.
			INNER JOIN PageFileRevision as PFR
				ON PFR.PageFileId = PF.Id
				AND PFR.Revision = PRA.FileRevision
			WHERE
				P.Navigation = @PageNavigation
				AND PR.Revision = IsNull(@PageRevision, P.Revision)
		) as PaginationCount
	FROM
		[PageFile] as PF
	INNER JOIN [Page] as P
		ON P.Id = PF.PageId
	INNER JOIN [PageRevision] as PR
		ON PR.PageId = P.Id
	INNER JOIN PageRevisionAttachment as PRA
		ON PRA.PageId = P.Id
		AND PRA.PageFileId = PF.Id
		AND PRA.PageRevision = PR.Revision
		AND PRA.FileRevision = PF.Revision --Latest file revision.
	INNER JOIN PageFileRevision as PFR
		ON PFR.PageFileId = PF.Id
		AND PFR.Revision = PRA.FileRevision
	WHERE
		P.Navigation = @PageNavigation
		AND PR.Revision = IsNull(@PageRevision, P.Revision)
	ORDER BY
		PF.[Name],
		PF.Id
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageInfoById]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageInfoById] AS'
END
GO







ALTER PROCEDURE [dbo].[GetPageInfoById]
(
	@PageId int
)AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		P.Id,
		P.[Name],
		P.[Description],
		P.Navigation,
		P.Revision,
		P.CreatedByUserId,
		P.CreatedDate,
		P.ModifiedByUserId,
		P.ModifiedDate
	FROM
		[Page] as P
	WHERE
		P.Id = @PageId

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageInfoByNamespaces]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageInfoByNamespaces] AS'
END
GO



ALTER PROCEDURE [dbo].[GetPageInfoByNamespaces]
(
	@Namespaces nVarChar(MAX)
)AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT DISTINCT
		P.Id,
		P.[Name],
		P.[Description],
		P.Navigation,
		P.CreatedByUserId,
		P.CreatedDate,
		P.ModifiedByUserId,
		P.ModifiedDate
	FROM
		[Page] as P
	INNER JOIN STRING_SPLIT(@Namespaces ,',') as SP
		ON P.[Namespace] = SP.[value]

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageInfoByNavigation]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageInfoByNavigation] AS'
END
GO







ALTER PROCEDURE [dbo].[GetPageInfoByNavigation]
(
	@Navigation nVarChar(128)
)AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		P.Id,
		P.[Name],
		P.[Description],
		P.Navigation,
		P.CreatedByUserId,
		P.CreatedDate,
		P.ModifiedByUserId,
		P.ModifiedDate
	FROM
		[Page] as P
	WHERE
		P.Navigation = @Navigation

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageInfoByTags]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageInfoByTags] AS'
END
GO







ALTER PROCEDURE [dbo].[GetPageInfoByTags]
(
	@Tags nVarChar(MAX)
)AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT DISTINCT
		P.Id,
		P.[Name],
		P.[Description],
		P.Navigation,
		P.CreatedByUserId,
		P.CreatedDate,
		P.ModifiedByUserId,
		P.ModifiedDate
	FROM
		PageTag as PT
	INNER JOIN STRING_SPLIT(@Tags ,',') as SP
		ON PT.Tag = SP.[value]
	INNER JOIN [Page] as P
		ON P.Id = PT.PageId

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageProcessingInstructionsByPageId]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageProcessingInstructionsByPageId] AS'
END
GO




ALTER PROCEDURE [dbo].[GetPageProcessingInstructionsByPageId]
(
	@PageId Int
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		PageId,
		Instruction
	FROM
		PageProcessingInstruction
	WHERE
		PageId = @PageId

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageRevisionById]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageRevisionById] AS'
END
GO








ALTER PROCEDURE [dbo].[GetPageRevisionById]
(
	@PageId Int,
	@Revision int = NULL
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		P.Id,
		P.[Name],
		P.[Description],
		PR.Body,
		PR.Revision,
		P.Navigation,
		P.CreatedByUserId,
		P.CreatedDate,
		P.ModifiedByUserId,
		P.ModifiedDate
	FROM
		[Page] as P
	INNER JOIN [PageRevision] as PR
		ON PR.PageId = P.Id
	WHERE
		P.Id = @PageId
		AND PR.Revision = IsNull(@Revision, P.Revision)

END--PROCEDURE



GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageRevisionByNavigation]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageRevisionByNavigation] AS'
END
GO




ALTER PROCEDURE [dbo].[GetPageRevisionByNavigation]
(
	@Navigation nVarChar(128),
	@Revision int = NULL
)AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		P.Id,
		P.[Name],
		PR.[Description],
		PR.Body,
		PR.Revision,
		P.Revision as LatestRevision,
		P.Navigation,
		P.CreatedByUserId,
		P.CreatedDate,
		PR.ModifiedByUserId,
		PR.ModifiedDate
	FROM
		[Page] as P
	INNER JOIN [PageRevision] as PR
		ON PR.PageId = P.Id
	WHERE
		P.Navigation = @Navigation
		AND PR.Revision = IsNull(@Revision, P.Revision)

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageRevisionHistoryInfoByNavigationPaged]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageRevisionHistoryInfoByNavigationPaged] AS'
END
GO




ALTER PROCEDURE [dbo].[GetPageRevisionHistoryInfoByNavigationPaged]
(
	@Navigation nvarchar(128),
	@PageNumber int = 0,
	@PageSize int = 0
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @PaginationSize int = @PageSize
	
	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	SELECT
		P.Id as PageId,
		PR.[Name],
		PR.[Description],
		PR.Revision,
		P.Navigation,
		P.CreatedByUserId,
		Createduser.AccountName as CreatedByUserName,
		P.CreatedDate,
		PR.ModifiedByUserId,
		ModifiedUser.AccountName as ModifiedByUserName,
		PR.ModifiedDate,
		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(0) / (@PaginationSize + 0.0))
			FROM
				[Page] as P
			INNER JOIN [PageRevision] as PR
				ON PR.PageId = P.Id
			WHERE
				P.Navigation = @Navigation
		) as PaginationCount
	FROM
		[Page] as P
	INNER JOIN [PageRevision] as PR
		ON PR.PageId = P.Id
	INNER JOIN [User] as ModifiedUser
		ON ModifiedUser.Id = PR.ModifiedByUserId
	INNER JOIN [User] as Createduser
		ON Createduser.Id = P.CreatedByUserId
	WHERE
		P.Navigation = @Navigation
	ORDER BY
		PR.Revision DESC
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageRevisionInfoById]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageRevisionInfoById] AS'
END
GO







ALTER PROCEDURE [dbo].[GetPageRevisionInfoById]
(
	@PageId Int,
	@Revision int = NULL
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		P.Id,
		P.[Name],
		P.[Description],
		PR.Revision,
		P.Navigation,
		P.CreatedByUserId,
		Createduser.AccountName as CreatedByUserName,
		P.CreatedDate,
		PR.ModifiedByUserId,
		ModifiedUser.AccountName as ModifiedByUserName,
		PR.ModifiedDate
	FROM
		[Page] as P
	INNER JOIN [PageRevision] as PR
		ON PR.PageId = P.Id
	INNER JOIN [User] as ModifiedUser
		ON ModifiedUser.Id = PR.ModifiedByUserId
	INNER JOIN [User] as Createduser
		ON Createduser.Id = P.CreatedByUserId
	WHERE
		P.Id = @PageId
		AND PR.Revision = IsNull(@Revision, P.Revision)

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageTagsById]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageTagsById] AS'
END
GO







ALTER PROCEDURE [dbo].[GetPageTagsById]
(
	@PageId int
)AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		PT.Tag
	FROM
		[PageTag] as PT
	WHERE
		PT.PageId = @PageId

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetRelatedPagesPaged]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetRelatedPagesPaged] AS'
END
GO




ALTER PROCEDURE [dbo].[GetRelatedPagesPaged]
(
	@PageId int,
	@PageNumber int = 1,
	@PageSize int = 0
) as
BEGIN--PROCEDURE

	DECLARE @PaginationSize int = @PageSize
	
	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	SELECT
		P.Id,
		P.[Name],
		P.[Revision],
		P.Navigation,
		P.[Description],
		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(0) / (@PaginationSize + 0.0))
			FROM
				PageReference as PR
			INNER JOIN [Page] as P
				ON P.Id = PR.PageId
			WHERE
				PR.ReferencesPageId = @PageId
				AND PR.PageId <> PR.ReferencesPageId
		) as PaginationCount
	FROM
		PageReference as PR
	INNER JOIN [Page] as P
		ON P.Id = PR.PageId
	WHERE
		PR.ReferencesPageId = @PageId
		AND PR.PageId <> PR.ReferencesPageId
	ORDER BY
		P.[Name]
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetRoleByName]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetRoleByName] AS'
END
GO




ALTER PROCEDURE [dbo].[GetRoleByName]
(
	@Name nVarChar(128)
)AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		Id,
		[Name],
		[Description]
	FROM
		[Role]
	WHERE
		[Name] = @Name

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetTopRecentlyModifiedPagesInfo]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetTopRecentlyModifiedPagesInfo] AS'
END
GO







ALTER PROCEDURE [dbo].[GetTopRecentlyModifiedPagesInfo]
(
	@TopCount int
)AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT TOP(@TopCount)
		P.Id,
		P.[Name],
		P.[Description],
		P.[Revision],
		P.Navigation,
		P.CreatedByUserId,
		P.CreatedDate,
		P.ModifiedByUserId,
		P.ModifiedDate
	FROM
		[Page] as P
	ORDER BY
		P.ModifiedDate DESC,
		P.[Name] ASC

END--PROCEDURE



GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetUserAvatarByNavigation]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetUserAvatarByNavigation] AS'
END
GO







ALTER PROCEDURE [dbo].[GetUserAvatarByNavigation]
(
	@Navigation nvarchar(128)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		[Avatar]
	FROM
		[User]
	WHERE
		Navigation = @Navigation

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetUserByAccountNameOrEmailAndPasswordHash]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetUserByAccountNameOrEmailAndPasswordHash] AS'
END
GO




ALTER PROCEDURE  [dbo].[GetUserByAccountNameOrEmailAndPasswordHash]
(
	@AccountNameOrEmail nVarChar(128),
	@PasswordHash nVarChar(128)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		U.Id,
		U.EmailAddress,
		U.AccountName,
		U.Navigation,
		U.PasswordHash,
		U.FirstName,
		U.LastName,
		U.TimeZone,
		U.Country,
		U.[Language],
		U.AboutMe,
		U.CreatedDate,
		U.ModifiedDate,
		U.LastLoginDate,
		U.VerificationCode,
		R.[Name] as [Role],
		U.EmailVerified
	FROM
		[User] as U
	INNER JOIN [Role] as R
		 ON R.Id = U.RoleId
	WHERE
		(U.EmailAddress = @AccountNameOrEmail OR U.AccountName = @AccountNameOrEmail)
		AND U.PasswordHash = @PasswordHash

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetUserByEmail]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetUserByEmail] AS'
END
GO







ALTER PROCEDURE [dbo].[GetUserByEmail]
(
	@EmailAddress nVarChar(128)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		U.Id,
		U.EmailAddress,
		U.[Provider],
		U.AccountName,
		U.Navigation,
		U.PasswordHash,
		U.FirstName,
		U.LastName,
		U.TimeZone,
		U.Country,
		U.[Language],
		U.AboutMe,
		U.CreatedDate,
		U.ModifiedDate,
		U.LastLoginDate,
		U.VerificationCode,
		R.[Name] as [Role],
		U.EmailVerified
	FROM
		[User] as U
	INNER JOIN [Role] as R
		 ON R.Id = U.RoleId
	WHERE
		U.EmailAddress = @EmailAddress

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetUserById]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetUserById] AS'
END
GO







ALTER PROCEDURE [dbo].[GetUserById]
(
	@Id int
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		U.Id,
		U.EmailAddress,
		U.[Provider],
		U.AccountName,
		U.Navigation,
		U.PasswordHash,
		U.FirstName,
		U.LastName,
		U.TimeZone,
		U.Country,
		U.[Language],
		U.AboutMe,
		U.CreatedDate,
		U.ModifiedDate,
		U.LastLoginDate,
		U.VerificationCode,
		R.[Name] as [Role],
		U.EmailVerified
	FROM
		[User] as U
	INNER JOIN [Role] as R
		 ON R.Id = U.RoleId
	WHERE
		U.Id = @Id

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetUserByNavigation]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetUserByNavigation] AS'
END
GO








ALTER PROCEDURE [dbo].[GetUserByNavigation]
(
	@Navigation nvarchar(128)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		U.Id,
		U.EmailAddress,
		U.[Provider],
		U.AccountName,
		U.Navigation,
		U.PasswordHash,
		U.FirstName,
		U.LastName,
		U.TimeZone,
		U.Country,
		U.[Language],
		U.AboutMe,
		U.CreatedDate,
		U.ModifiedDate,
		U.LastLoginDate,
		U.VerificationCode,
		R.[Name] as [Role],
		U.EmailVerified
	FROM
		[User] as U
	INNER JOIN [Role] as R
		 ON R.Id = U.RoleId
	WHERE
		U.Navigation = @Navigation

END--PROCEDURE



GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetUserByNavigationAndVerificationCode]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetUserByNavigationAndVerificationCode] AS'
END
GO







ALTER PROCEDURE [dbo].[GetUserByNavigationAndVerificationCode]
(
	@Navigation nvarchar(128),
	@VerificationCode varchar(20)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		U.Id,
		U.EmailAddress,
		U.[Provider],
		U.AccountName,
		U.Navigation,
		U.PasswordHash,
		U.FirstName,
		U.LastName,
		U.TimeZone,
		U.Country,
		U.[Language],
		U.AboutMe,
		U.CreatedDate,
		U.ModifiedDate,
		U.LastLoginDate,
		U.VerificationCode,
		R.[Name] as [Role],
		U.EmailVerified
	FROM
		[User] as U
	INNER JOIN [Role] as R
		 ON R.Id = U.RoleId
	WHERE
		U.Navigation = @Navigation
		AND U.VerificationCode = @VerificationCode

END--PROCEDURE



GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetUsersByRoleId]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetUsersByRoleId] AS'
END
GO





ALTER PROCEDURE [dbo].[GetUsersByRoleId]
(
	@RoleId int,
	@PageNumber int = 1,
	@PageSize int = 0
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @PaginationSize int = @PageSize
	
	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	SELECT
		U.Id,
		U.EmailAddress,
		U.[Provider],
		U.AccountName,
		U.Navigation,
		U.PasswordHash,
		U.FirstName,
		U.LastName,
		U.TimeZone,
		U.[Language],
		U.Country,
		U.CreatedDate,
		U.ModifiedDate,
		U.LastLoginDate,
		R.[Name] as [Role],
		U.EmailVerified,
		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(0) / (@PaginationSize + 0.0))
			FROM
				[User] as P
			WHERE
				U.RoleId = @RoleId
		) as PaginationCount
	FROM
		[User] as U
	INNER JOIN [Role] as R
		ON R.Id = U.RoleId
	WHERE
		U.RoleId = @RoleId
	ORDER BY
		U.AccountName,
		U.Id
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetWikiDatabaseStats]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetWikiDatabaseStats] AS'
END
GO

ALTER PROCEDURE [dbo].[GetWikiDatabaseStats] AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	SELECT
		(SELECT Count(0) FROM [Page]) as Pages,
		(SELECT Count(0) FROM [PageReference]) as IntraLinks,
		(SELECT Count(0) FROM PageRevision) as PageRevisions,
		(SELECT Count(0) FROM PageFile) as PageAttachments,
		(SELECT Count(0) FROM PageFileRevision) as PageAttachmentRevisions,
		(SELECT Count(0) FROM PageTag) as PageTags,
		(SELECT Count(0) FROM PageToken) as PageSearchTokens,
		(SELECT Count(0) FROM [User]) as Users,
		(SELECT Count(0) FROM [Exception]) as Exceptions
END--PROCEDURE

GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetWikiMetrics]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetWikiMetrics] AS'
END
GO




ALTER PROCEDURE [dbo].[GetWikiMetrics] AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;
		
SELECT
	(SELECT Count(0) FROM [PageToken]) as Words,
	(SELECT Count(0) FROM [Page]) as Pages,
	(SELECT Count(0) FROM [PageTag]) as Tags,
	(SELECT Count(0) FROM [User]) as Users,
	(SELECT Count(0) FROM [PageRevision]) as PageRevisions,
	(SELECT Count(0) FROM [PageFile]) as Attachments,
	(SELECT SUM(DATALENGTH(Body)) FROM [PageRevision]) / 1024.0 / 1024.0 as TotalPageSizeMB,
	(SELECT SUM(Size) FROM [PageFileRevision]) / 1024.0 / 1024.0 as TotalAttachmentSizeMB

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[InsertException]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[InsertException] AS'
END
GO




ALTER PROCEDURE  [dbo].[InsertException]
(
	@Text as nvarchar (max) = NULL,
	@ExceptionText as nvarchar(max) = NULL,
	@StackTrace as nvarchar(max) = NULL
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	INSERT INTO [Exception]
	(
		[Text],
		[ExceptionText],
		[StackTrace],
		[CreatedDate]
	)
	SELECT
		@Text,
		@ExceptionText,
		@StackTrace,
		GETUTCDATE()

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[InsertPageStatistics]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[InsertPageStatistics] AS'
END
GO

ALTER PROCEDURE [dbo].[InsertPageStatistics]
(
	@PageId int,
	@WikifyTimeMs decimal(8, 2),
	@MatchCount int,
	@ErrorCount int,
	@OutgoingLinkCount int,
	@TagCount int,
	@ProcessedBodySize int,
	@BodySize int
)AS
BEGIN--PROCEDURE

	INSERT INTO PageStatistics
	(
		[PageId],
		[CreatedDate],
		[WikifyTimeMs],
		[MatchCount],
		[ErrorCount],
		[OutgoingLinkCount],
		[TagCount],
		[ProcessedBodySize],
		[BodySize]
	)
	SELECT
		@PageId,
		GETUTCDATE(),
		@WikifyTimeMs,
		@MatchCount,
		@ErrorCount,
		@OutgoingLinkCount,
		@TagCount,
		@ProcessedBodySize,
		@BodySize

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[IsAdminPasswordDefault]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[IsAdminPasswordDefault] AS'
END
GO





ALTER PROCEDURE  [dbo].[IsAdminPasswordDefault]
(
	@PlainTextPassword VARCHAR(128)
)AS
BEGIN--PROCEDURE
	DECLARE @PasswordHash VarChar(128) = LOWER(Convert(VARCHAR(128), HASHBYTES('SHA2_256', @PlainTextPassword), 2))
	IF EXISTS(SELECT TOP 1 1 FROM [User] WHERE PasswordHash = @PasswordHash and Navigation = 'admin')
	BEGIN--IF
		SELECT Cast(1 as Bit) as Result
	END ELSE BEGIN--IF
		SELECT Cast(0 as Bit) as Result
	END--IF
END--PROCEDURE

GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[IsFirstRun]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[IsFirstRun] AS'
END
GO






ALTER PROCEDURE  [dbo].[IsFirstRun]
(
	@Content NVARCHAR(128),
	@Passphrase NVARCHAR(128)
)AS
BEGIN--PROCEDURE

	DECLARE @StoredContent NVARCHAR(128)

	SELECT @StoredContent = Convert(NVarChar(128), DecryptByPassPhrase(@Passphrase, [Content], 0, NULL)) FROM CryptoCheck

	IF(@Content = @StoredContent)
	BEGIN--IF
		SELECT CAST(0 AS BIT)
	END ELSE BEGIN--IF
		TRUNCATE TABLE CryptoCheck
		INSERT INTO CryptoCheck(Content) SELECT EncryptByPassPhrase(@Passphrase, @Content, 0, NULL)
		SELECT CAST(1 AS BIT)
	END--IF
END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[PageSearch]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[PageSearch] AS'
END
GO




ALTER PROCEDURE [dbo].[PageSearch]
(
	@SearchTerms dbo.PageTokenType READONLY
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @MinimumMatchScore Decimal(16, 2)
	DECLARE @AllowFuzzyMatching BIT = 0
	DECLARE @MaximumScore Decimal(16, 2)
	DECLARE @TokenCount INT = (SELECT COUNT(0) FROM @SearchTerms)
	
	DECLARE @PageTokens TABLE
	(
		PageId INT,
		[Match] Decimal(3, 2),
		[Weight] int,
		[Score] Decimal(16, 2)
	)

	SELECT
		@MinimumMatchScore = Cast(CE.[Value] as Decimal(16, 2))
	FROM
		[ConfigurationEntry] as CE
	INNER JOIN [ConfigurationGroup] as CG
		ON CG.Id = CE.ConfigurationGroupId
	WHERE
		CG.[Name] = 'Search'
		AND CE.[Name] = 'Minimum Match Score'

	SELECT
		@AllowFuzzyMatching = Cast(CE.[Value] as Bit)
	FROM
		[ConfigurationEntry] as CE
	INNER JOIN [ConfigurationGroup] as CG
		ON CG.Id = CE.ConfigurationGroupId
	WHERE
		CG.[Name] = 'Search'
		AND CE.[Name] = 'Allow Fuzzy Matching'

	INSERT INTO @PageTokens
	(
		PageId,
		[Match],
		[Weight],
		[Score]
	)
	SELECT
		PageId,
		SUM([Match]) as [Match],
		SUM([Weight]) as [Weight],
		SUM([Score]) as [Score]
	FROM
	(
		SELECT
			T.PageId,
			COUNT(DISTINCT T.Token) / (@TokenCount + 0.0) as [Match],
			SUM(T.[Weight] * 1.5) as [Weight],
			--Extra weight on score for exact matches:
			SUM(T.[Weight] * 1.5) * (COUNT(DISTINCT T.Token) / (@TokenCount + 0.0)) as [Score]
		FROM
			PageToken as T
		INNER JOIN @SearchTerms as ST
			ON ST.Token = T.Token
		GROUP BY
			T.PageId

		UNION ALL

		SELECT
			T.PageId,
			COUNT(DISTINCT T.DoubleMetaphone) / (@TokenCount + 0.0) as [Match],
			SUM(T.[Weight] * 1.0) as [Weight],
			--No weight benefits on score for fuzzy matching weight for exact matches:
			(COUNT(DISTINCT T.DoubleMetaphone) / (@TokenCount + 0.0)) as [Score]
		FROM
			PageToken as T
		INNER JOIN @SearchTerms as ST
			ON ST.Token != T.Token
			AND ST.DoubleMetaphone = T.DoubleMetaphone
		WHERE
			@AllowFuzzyMatching = CAST(1 AS Bit)
		GROUP BY
			T.PageId
		) as T
	GROUP BY
		T.PageId
	HAVING
		SUM(Score) >= @MinimumMatchScore

	SELECT @MaximumScore = MAX(Score) FROM @PageTokens

	SELECT
		P.Id,
		ST.[Score],
		ST.[Match],
		ST.[Weight],
		P.[Name],
		P.Navigation,
		P.[Description],
		P.Revision,
		P.CreatedByUserId,
		P.CreatedDate,
		P.ModifiedByUserId,
		P.ModifiedDate,
		Createduser.AccountName as CreatedByUserName,
		ModifiedUser.AccountName as ModifiedByUserName
	FROM
		[Page] as P
	INNER JOIN [User] as ModifiedUser
		ON ModifiedUser.Id = P.ModifiedByUserId
	INNER JOIN [User] as Createduser
		ON Createduser.Id = P.CreatedByUserId
	INNER JOIN @PageTokens as ST
		ON ST.PageId = P.Id
	ORDER BY
		ST.[Score] DESC,
		P.[Name],
		P.Id

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[PageSearchPaged]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[PageSearchPaged] AS'
END
GO




ALTER PROCEDURE [dbo].[PageSearchPaged]
(
	@PageNumber int = 1,
	@PageSize int = 0,
	@AllowFuzzyMatching BIT = NULL,
	@SearchTerms dbo.PageTokenType READONLY
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @PaginationSize int = @PageSize
	DECLARE @MinimumMatchScore Decimal(16, 2)
	DECLARE @MaximumScore Decimal(16, 2)
	DECLARE @TokenCount INT = (SELECT COUNT(0) FROM @SearchTerms)
	
	DECLARE @PageTokens TABLE
	(
		PageId INT,
		[Match] Decimal(3, 2),
		[Weight] Decimal(6, 2),
		[Score] Decimal(16, 2)
	)

	SELECT
		@MinimumMatchScore = Cast(CE.[Value] as Decimal(16, 2))
	FROM
		[ConfigurationEntry] as CE
	INNER JOIN [ConfigurationGroup] as CG
		ON CG.Id = CE.ConfigurationGroupId
	WHERE
		CG.[Name] = 'Search'
		AND CE.[Name] = 'Minimum Match Score'

	IF(@AllowFuzzyMatching IS NULL)
	BEGIN--IF
	SELECT
		@AllowFuzzyMatching = Cast(CE.[Value] as Bit)
	FROM
		[ConfigurationEntry] as CE
	INNER JOIN [ConfigurationGroup] as CG
		ON CG.Id = CE.ConfigurationGroupId
	WHERE
		CG.[Name] = 'Search'
		AND CE.[Name] = 'Allow Fuzzy Matching'
	END--IF

	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	INSERT INTO @PageTokens
	(
		PageId,
		[Match],
		[Weight],
		[Score]
	)
	SELECT
		PageId,
		SUM([Match]) as [Match],
		SUM([Weight]) as [Weight],
		SUM([Score]) as [Score]
	FROM
	(
		SELECT
			T.PageId,
			COUNT(DISTINCT T.Token) / (@TokenCount + 0.0) as [Match],
			SUM(T.[Weight] * 1.5) as [Weight],
			--Extra weight on score for exact matches:
			SUM(T.[Weight] * 1.5) * (COUNT(DISTINCT T.Token) / (@TokenCount + 0.0)) as [Score]
		FROM
			PageToken as T
		INNER JOIN @SearchTerms as ST
			ON ST.Token = T.Token
		GROUP BY
			T.PageId

		UNION ALL

		SELECT
			T.PageId,
			COUNT(DISTINCT T.DoubleMetaphone) / (@TokenCount + 0.0) as [Match],
			SUM(T.[Weight] * 1.0) as [Weight],
			--No weight benefits on score for fuzzy matching weight for exact matches:
			(COUNT(DISTINCT T.DoubleMetaphone) / (@TokenCount + 0.0)) as [Score]
		FROM
			PageToken as T
		INNER JOIN @SearchTerms as ST
			ON ST.Token != T.Token
			AND ST.DoubleMetaphone = T.DoubleMetaphone
		WHERE
			@AllowFuzzyMatching = CAST(1 AS Bit)
		GROUP BY
			T.PageId
		) as T
	GROUP BY
		T.PageId
	HAVING
		SUM(Score) >= @MinimumMatchScore

	SELECT @MaximumScore = MAX(Score) FROM @PageTokens

	SELECT
		P.Id,
		(ST.[Score] / @MaximumScore) * 100.0 as Score,
		ST.[Match],
		ST.[Weight],
		P.[Name],
		P.Navigation,
		P.[Description],
		P.Revision,
		P.CreatedByUserId,
		P.CreatedDate,
		P.ModifiedByUserId,
		P.ModifiedDate,
		Createduser.AccountName as CreatedByUserName,
		ModifiedUser.AccountName as ModifiedByUserName,
		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(0) / (@PaginationSize + 0.0))
			FROM
				[Page] as P
			INNER JOIN @PageTokens as ST
				ON ST.PageId = P.Id
		) as PaginationCount
	FROM
		[Page] as P
	INNER JOIN [User] as ModifiedUser
		ON ModifiedUser.Id = P.ModifiedByUserId
	INNER JOIN [User] as Createduser
		ON Createduser.Id = P.CreatedByUserId
	INNER JOIN @PageTokens as ST
		ON ST.PageId = P.Id
	ORDER BY
		ST.[Score] DESC,
		P.[Name],
		P.Id
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[PrintMax]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[PrintMax] AS'
END
GO



ALTER PROCEDURE  [dbo].[PrintMax]
(
	@String NVARCHAR(MAX)
) AS
BEGIN--PROCEDURE
	DECLARE @Length INT = Len(@String)
	DECLARE @Remaining INT = @Length
	DECLARE @Current INT = 1
	DECLARE @ChunkSize INT = 3840

	WHILE(@Remaining > 0)
	BEGIN--WHILE

		IF(@Remaining < @ChunkSize)
		BEGIN--IF
			SET @ChunkSize = @Remaining
		END--IF

			PRINT SUBSTRING(@String, @Current, @ChunkSize)   
			SET @Current = @Current + @ChunkSize
			SET @Remaining = @Remaining - @ChunkSize


		
	END--WHILE
END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[SaveConfigurationEntryValueByGroupAndEntry]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[SaveConfigurationEntryValueByGroupAndEntry] AS'
END
GO







ALTER PROCEDURE [dbo].[SaveConfigurationEntryValueByGroupAndEntry]
(
	@GroupName nVarchar(128),
	@entryName nVarchar(128),
	@value nVarchar(max)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;
		
	UPDATE
		CE
	SET
		[Value] = @value
	FROM
		[ConfigurationEntry] as CE
	INNER JOIN [ConfigurationGroup] as CG
		ON CG.Id = CE.ConfigurationGroupId
	WHERE
		CG.[Name] = @GroupName
		AND CE.[Name] = @entryName

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[SaveEmoji]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[SaveEmoji] AS'
END
GO

ALTER PROCEDURE [dbo].[SaveEmoji]
(
	@Name as nvarchar(128),
	@Categories as nvarchar(2000),
	@Id Int = null
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	BEGIN TRANSACTION
	BEGIN TRY

		DECLARE @EmojiId INT = NullIf(@Id, 0)

		IF(@EmojiId IS NULL)
		BEGIN--IF
			SELECT @EmojiId = Id FROM [Emoji] WHERE [Name] = @Name
		END--IF

		IF(@EmojiId IS NULL)
		BEGIN--IF
			INSERT INTO [Emoji]
			(
				[Name]
			)
			SELECT
				@Name

			SELECT @EmojiId = Id FROM [Emoji] WHERE [Name] = @Name
		END ELSE BEGIN--IF

			UPDATE
				Emoji
			SET
				[Name] = @Name
			WHERE
				Id = @EmojiId

			DELETE FROM EmojiCategory WHERE EmojiId = @EmojiId
		END--IF

		INSERT INTO EmojiCategory
		(
			[EmojiId],
			[Category]
		)
		SELECT
			@EmojiId,
			ss.[Value]
		FROM
			STRING_SPLIT(@Categories, ',') as ss

		SELECT @EmojiId as Id

        COMMIT TRANSACTION 
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK TRANSACTION
        END
    END CATCH

END--PROCEDURE



GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[SavePage]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[SavePage] AS'
END
GO



ALTER PROCEDURE [dbo].[SavePage]
(
	@Id as int = NULL,
	@Name as nvarchar (128),
	@Namespace as nvarchar (128),
	@Navigation as nvarchar (128),
	@Description as nvarchar (MAX),
	@Body as nvarchar (MAX),
	@CreatedByUserId as int,
	@CreatedDate as datetime,
	@ModifiedByUserId as int,
	@ModifiedDate as datetime
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	BEGIN TRANSACTION

	BEGIN TRY
		DECLARE @PageId INT = (SELECT Id FROM [Page] WHERE Id = @Id)
		DECLARE @PageRevision INT

		IF(@PageId IS NULL)
		BEGIN--IF
			INSERT INTO [Page]
			(
				[Name],
				[Namespace],
				[Description],
				[Navigation],
				[Revision],
				[CreatedByUserId],
				[CreatedDate],
				[ModifiedByUserId],
				[ModifiedDate]
			)
			VALUES
			(
				@Name,
				@Namespace,
				@Description,
				@Navigation,
				0,
				@CreatedByUserId,
				GETUTCDATE(),
				@ModifiedByUserId,
				GETUTCDATE()
			)

			SET @PageId = cast(SCOPE_IDENTITY() as int)
		END ELSE BEGIN--IF
			UPDATE
				[Page]
			SET
				[Description] = @Description,
				[Name] = @Name,
				[Namespace] = @Namespace,
				[Navigation] = @Navigation,
				[ModifiedByUserId] = @ModifiedByUserId,
				[ModifiedDate] = GETUTCDATE()
			WHERE
				[Id] = @Id

			SET @PageId = @Id
		END--IF

		SELECT @PageRevision = Revision FROM [Page] WHERE Id = @PageId

		DECLARE @Checksum INT = CHECKSUM(@Body)

		IF NOT EXISTS(SELECT TOP 1 1 FROM [PageRevision] WHERE PageId = @PageId AND Revision = @PageRevision
			AND DataHash = @Checksum AND CHECKSUM([Description] + [Name] + [Namespace]) = CHECKSUM(@Description + @Name + @Namespace))
		BEGIN--IF
			SET @PageRevision = @PageRevision + 1

			UPDATE [Page] SET Revision = @PageRevision WHERE Id = @PageId
	
			INSERT INTO [PageRevision]
			(
				PageId,
				[Name],
				[Namespace],
				[Description],
				Body,
				DataHash,
				Revision,
				ModifiedByUserId,
				ModifiedDate
			)
			SELECT
				@PageId,
				@Name,
				@Namespace,
				@Description,
				@Body,
				@Checksum,
				@PageRevision,
				@ModifiedByUserId,
				GETUTCDATE()
			FROM
				[Page]
			WHERE
				Id = @PageId

			INSERT INTO PageRevisionAttachment
			(
				PageId,
				PageFileId,
				FileRevision,
				PageRevision
			)
			SELECT
				PRA.PageId,
				PRA.PageFileId,
				PRA.FileRevision,
				PRA.PageRevision + 1
			FROM
				PageRevisionAttachment as PRA
			INNER JOIN PageFile as PF
				ON PF.Id = PRA.PageFileId
				AND PF.Revision = PRA.FileRevision
			WHERE
				PRA.PageId = @PageId
				AND PRA.PageRevision = @PageRevision - 1
		END--IF

		SELECT @PageId as PageId

        COMMIT TRANSACTION 
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK TRANSACTION
        END
    END CATCH
END--PROCEDURE



GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[SavePageTokens]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[SavePageTokens] AS'
END
GO





ALTER PROCEDURE [dbo].[SavePageTokens]
(
	@PageTokens dbo.PageTokenType READONLY
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	BEGIN TRANSACTION

	DELETE FROM
		[dbo].[PageToken]
	WHERE
		[PageId] IN (SELECT PageId FROM @PageTokens)

	INSERT INTO [dbo].[PageToken]
	(
		[PageId],
		[Token],
		[DoubleMetaphone],
		[Weight]
	)
	SELECT
		[PageId],
		[Token],
		[DoubleMetaphone],
		[Weight]
	FROM
		@PageTokens

	COMMIT TRANSACTION

END--PROCEDURE



GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[SetUserPasswordHash]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[SetUserPasswordHash] AS'
END
GO




ALTER PROCEDURE  [dbo].[SetUserPasswordHash]
(
	@Navigation NVARCHAR(128),
	@PlainTextPassword VARCHAR(128)
)AS
BEGIN--PROCEDURE
	UPDATE
		[User]
	SET
		PasswordHash = LOWER(Convert(VARCHAR(128), HASHBYTES('SHA2_256', @PlainTextPassword), 2))
	WHERE
		Navigation = @Navigation
END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[TruncateAllPageHistory]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[TruncateAllPageHistory] AS'
END
GO








ALTER PROCEDURE [dbo].[TruncateAllPageHistory]
(
	@Confirm nvarchar(128)	
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	IF(@Confirm = 'YES')
	BEGIN--IF

		BEGIN TRANSACTION

		DELETE
			PR
		FROM
			PageRevision as PR
		INNER JOIN (
			SELECT
				iPR.PageId,
				Max(iPR.Revision) as Revision
			FROM
				PageRevision as iPR
			GROUP BY
				iPR.PageId
			) as MostRecent
			ON PR.PageId = MostRecent.PageId
			AND PR.Revision < MostRecent.Revision

		PRINT 'Deleted ' + Cast(@@rowcount as varchar) + ' page revisions.'

		DELETE
			PRA
		FROM
			PageRevisionAttachment as PRA
		INNER JOIN (
			SELECT
				iPRA.PageFileId,
				iPRA.PageId,
				Max(iPRA.FileRevision) as FileRevision
			FROM
				PageRevisionAttachment as iPRA
			GROUP BY
				iPRA.PageId,
				iPRA.PageFileId
			) as MostRecent
			ON PRA.PageFileId = MostRecent.PageFileId
			AND PRA.PageId = MostRecent.PageId
			AND PRA.FileRevision < MostRecent.FileRevision

		PRINT 'Deleted ' + Cast(@@rowcount as varchar) + ' page file revision associations.'

		DELETE
			PRA
		FROM
			PageRevisionAttachment as PRA
		INNER JOIN (
			SELECT
				iPRA.PageFileId,
				iPRA.PageId,
				Max(iPRA.PageRevision) as PageRevision
			FROM
				PageRevisionAttachment as iPRA
			GROUP BY
				iPRA.PageId,
				iPRA.PageFileId
			) as MostRecent
			ON PRA.PageFileId = MostRecent.PageFileId
			AND PRA.PageId = MostRecent.PageId
			AND PRA.PageRevision < MostRecent.PageRevision

		PRINT 'Deleted ' + Cast(@@rowcount as varchar) + ' page revision file associations.'

		DELETE
			PFR
		FROM
			PageFileRevision as PFR
		INNER JOIN (
			SELECT
				iPFR.PageFileId,
				Max(iPFR.Revision) as Revision
			FROM
				PageFileRevision as iPFR
			GROUP BY
				iPFR.PageFileId
			) as MostRecent
			ON PFR.PageFileId = MostRecent.PageFileId
			AND PFR.Revision < MostRecent.Revision

		PRINT 'Deleted ' + Cast(@@rowcount as varchar) + ' file revisions.'

		DELETE FROM PageFileRevision WHERE PageFileId NOT IN (SELECT PageFileId FROM PageRevisionAttachment)
		DELETE FROM PageFile WHERE Id NOT IN (SELECT PageFileId FROM PageRevisionAttachment)

		PRINT 'Deleted ' + Cast(@@rowcount as varchar) + ' orphaned files.'

		UPDATE [Page] SET Revision = 1
		UPDATE PageRevision SET Revision = 1
		UPDATE PageRevisionAttachment SET PageRevision = 1
		UPDATE PageRevisionAttachment SET FileRevision = 1
		UPDATE PageFileRevision SET Revision = 1
		UPDATE PageFile SET Revision = 1


		COMMIT TRANSACTION
	END ELSE BEGIN--IF
		PRINT 'Not confirmed. Pass ''YES'' to delete all but the most recent page revisions ans reset all revisions to 1.'
	END--IF

END --PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[UpdatEmojiImage]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[UpdatEmojiImage] AS'
END
GO

ALTER PROCEDURE [dbo].[UpdatEmojiImage]
(
	@EmojiId int,
	@MimeType nvarchar(50),
	@ImageData varbinary(max)

) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	UPDATE
		[Emoji]
	SET
		MimeType = @MimeType,
		ImageData = COMPRESS(@ImageData)
	WHERE
		Id = @EmojiId

END--PROCEDURE



GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[UpdatePageProcessingInstructions]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[UpdatePageProcessingInstructions] AS'
END
GO




ALTER PROCEDURE [dbo].[UpdatePageProcessingInstructions]
(
	@PageId Int,
	@Instructions nVarChar(MAX)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	BEGIN TRANSACTION

	DELETE FROM
		PageProcessingInstruction
	WHERE
		PageId = @PageId

	INSERT INTO PageProcessingInstruction
	(
		PageId,
		Instruction
	)
	SELECT
		@PageId,
		SP.[value]
	FROM
		STRING_SPLIT(@Instructions ,',') as SP
	WHERE
		IsNull(SP.[value], '') <> ''

	COMMIT TRANSACTION

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[UpdatePageReferences]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[UpdatePageReferences] AS'
END
GO



ALTER PROCEDURE [dbo].[UpdatePageReferences]
(
	@PageId as int,
	@References as [dbo].[PageReferenceType] READONLY
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	BEGIN TRANSACTION

	DELETE FROM
		PageReference
	WHERE
		PageId = @PageId

	INSERT INTO PageReference
	(
		PageId,
		ReferencesPageName,
		ReferencesPageNavigation,
		ReferencesPageId
	)
	SELECT DISTINCT
		@PageId,
		IsNull(Ref.[Namespace] + ' :: ', '') +  Ref.[PageName],
		Ref.Navigation,
		P.Id
	FROM
		@References as Ref
	LEFT OUTER JOIN [Page] as P
		ON P.Navigation = Ref.Navigation

	UPDATE
		PR
	SET
		ReferencesPageNavigation = P.Navigation
	FROM
		PageReference as PR
	INNER JOIN [Page] as P
		ON P.Id = PR.ReferencesPageId
	WHERE
		P.Id = @PageId

	COMMIT TRANSACTION

END--PROCEDURE

GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[UpdatePageTags]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[UpdatePageTags] AS'
END
GO








ALTER PROCEDURE [dbo].[UpdatePageTags]
(
	@PageId Int,
	@Tags nVarChar(MAX)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	BEGIN TRANSACTION

	DELETE FROM
		PageTag
	WHERE
		PageId = @PageId

	INSERT INTO PageTag
	(
		PageId,
		[Tag]
	)
	SELECT
		@PageId,
		SP.[value]
	FROM
		STRING_SPLIT(@Tags ,',') as SP
	WHERE
		IsNull(SP.[value], '') <> ''

	COMMIT TRANSACTION

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[UpdateSinglePageReference]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[UpdateSinglePageReference] AS'
END
GO





ALTER PROCEDURE [dbo].[UpdateSinglePageReference]
(
	@PageNavigation as nvarchar(128)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @PageId INT = (SELECT Id FROM [Page] WHERE Navigation = @PageNavigation)

	UPDATE
		PageReference
	SET
		ReferencesPageId = @PageId
	WHERE
		ReferencesPageNavigation = @PageNavigation


END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[UpdateUser]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[UpdateUser] AS'
END
GO




ALTER PROCEDURE [dbo].[UpdateUser]
(
	@Id as int,
	@EmailAddress as nvarchar (128),
	@AccountName as nvarchar (128),
	@Navigation as nvarchar (128) = NULL,
	@PasswordHash as nvarchar (128) = NULL,
	@FirstName as nvarchar (128) = NULL,
	@LastName as nvarchar (128) = NULL,
	@TimeZone as varchar (128) = NULL,
	@Country as nvarchar (128) = NULL,
	@Language as nvarchar (128) = NULL,
	@AboutMe as nvarchar (MAX) = NULL,
	@ModifiedDate as datetime = NULL,
	@Role as nvarchar (128) = NULL
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @Provider Varchar(20)

	SELECT @Provider = [Provider] FROM [User] WHERE Id = @Id

	UPDATE
		[User]
	SET
		[EmailAddress] = CASE WHEN @Provider = 'Login' THEN @EmailAddress ELSE [EmailAddress] END, --We do not allow email address changes for external providers.
		[AccountName] = @AccountName,
		[Navigation] = @Navigation,
		[PasswordHash] = @PasswordHash,
		[FirstName] = @FirstName,
		[LastName] = @LastName,
		[Language] = @Language,
		[TimeZone] = @TimeZone,
		[Country] = @Country,
		[AboutMe] = @AboutMe,
		[RoleId] = (SELECT TOP 1 R.Id FROM [Role] as R WHERE R.[Name] = @Role)
	FROM
		[User]
	WHERE
		Id = @Id

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[UpdateUserAvatar]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[UpdateUserAvatar] AS'
END
GO







ALTER PROCEDURE [dbo].[UpdateUserAvatar]
(
	@UserId int,
	@Avatar varbinary(max)

) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	UPDATE
		[User]
	SET
		Avatar = @Avatar
	WHERE
		Id = @UserId

END--PROCEDURE



GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[UpdateUserLastLoginDateByUserId]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[UpdateUserLastLoginDateByUserId] AS'
END
GO







ALTER PROCEDURE [dbo].[UpdateUserLastLoginDateByUserId]
(
	@UserId as int
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	UPDATE
		[User]
	SET
		[LastLoginDate] = GETUTCDATE()
	FROM
		[User]
	WHERE
		[Id] = @UserId

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[UpdateUserPassword]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[UpdateUserPassword] AS'
END
GO







ALTER PROCEDURE [dbo].[UpdateUserPassword]
(
	@UserId as int,
	@PasswordHash as nvarchar (128) 
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	UPDATE
		[User]
	SET
		[PasswordHash] = @PasswordHash
	FROM
		[User]
	WHERE
		Id = @UserId

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[UpdateUserVerificationCode]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[UpdateUserVerificationCode] AS'
END
GO







ALTER PROCEDURE [dbo].[UpdateUserVerificationCode]
(
	@UserId as int,
	@VerificationCode varchar(20)
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	UPDATE
		[User]
	SET
		VerificationCode = @VerificationCode
	WHERE
		Id = @UserId

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[UpsertPageFile]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[UpsertPageFile] AS'
END
GO



ALTER PROCEDURE [dbo].[UpsertPageFile]
(
	@PageId int,
	@Name nvarchar(250),
	@FileNavigation nvarchar(250),
	@ContentType nvarchar(250),
	@Size int,
	@CreatedDate DateTime,
	@Data varbinary(max)
) AS
BEGIN--PROCEDURE

	SET NOCOUNT ON;

	BEGIN TRANSACTION

	BEGIN TRY

		DECLARE @PageFileId INT = (SELECT Id FROM [PageFile] WHERE PageId = @PageId AND Navigation = @FileNavigation)
		DECLARE @FileRevision INT
		DECLARE @PageRevision INT

		IF @PageFileId IS NULL
		BEGIN--IF
			INSERT INTO [dbo].[PageFile]
			(
				[PageId],
				[Name],
				[Navigation],
				[CreatedDate],
				[Revision]
			)
			SELECT
				@PageId,
				@Name,
				@FileNavigation,
				@CreatedDate,
				0

			SET @PageFileId = cast(SCOPE_IDENTITY() as int)
		END--IF
	
		SELECT @FileRevision = Revision FROM [PageFile] WHERE Id = @PageFileId
		DECLARE @Checksum INT = CHECKSUM(@Data)

		IF NOT EXISTS(SELECT TOP 1 1 FROM PageFileRevision WHERE PageFileId = @PageFileId AND Revision = @FileRevision AND DataHash = @Checksum)
		BEGIN--IF
			SET @FileRevision = @FileRevision + 1

			UPDATE [PageFile] SET Revision = @FileRevision WHERE Id = @PageFileId
			SELECT @PageRevision = Revision FROM [Page] WHERE Id = @PageId

			INSERT INTO PageFileRevision
			(
				PageFileId,
				ContentType,
				Size,
				CreatedDate,
				[Data],
				Revision,
				DataHash
			)
			SELECT
				@PageFileId,
				@ContentType,
				@Size,
				GETUTCDATE(),
				@Data,
				@FileRevision,
				@Checksum

			INSERT INTO PageRevisionAttachment
			(
				PageId,
				PageFileId,
				FileRevision,
				PageRevision
			)
			SELECT
				@PageId,
				@PageFileId,
				@FileRevision,
				@PageRevision
		END--IF

        COMMIT TRANSACTION 
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK TRANSACTION
        END
    END CATCH

END--PROCEDURE


GO
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[VerifyUserEmail]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[VerifyUserEmail] AS'
END
GO







ALTER PROCEDURE [dbo].[VerifyUserEmail]
(
	@UserId as int
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	UPDATE
		[User]
	SET
		EmailVerified = 1,
		VerificationCode = NULL
	WHERE
		Id = @UserId

END--PROCEDURE
GO
CREATE TABLE #tmp_a259ad388f69408590cd63e8fca187ee ([Id] [int],[Name] [nvarchar](128),[Description] [nvarchar](1000))
GO

INSERT INTO #tmp_a259ad388f69408590cd63e8fca187ee ([Id],[Name],[Description]) VALUES
(1,'Basic','Basic wiki settings such as formatting.'),
(2,'Search','Configuration related to searching and indexing.'),
(3,'Functionality','General wiki functionality.'),
(4,'Membership','Membership settings such as defaults for new members and permissions.'),
(5,'Email','EMail and SMTP setting.'),
(6,'HTML Layout','HTML layout'),
(7,'Performance','Performance related settings.')
GO
ALTER TABLE [dbo].[ConfigurationGroup] NOCHECK CONSTRAINT ALL
GO
SET IDENTITY_INSERT [dbo].[ConfigurationGroup] ON;
INSERT INTO [dbo].[ConfigurationGroup] (
	[Id],[Name],[Description])
SELECT
	[Id],[Name],[Description]
FROM #tmp_a259ad388f69408590cd63e8fca187ee as S
WHERE NOT EXISTS (
	SELECT TOP 1 1 FROM  [dbo].[ConfigurationGroup] as T
	WHERE T.[Id] = S.[Id]
)
SET IDENTITY_INSERT [dbo].[ConfigurationGroup] OFF;
ALTER TABLE [dbo].[ConfigurationGroup] CHECK CONSTRAINT ALL
GO
DROP TABLE #tmp_a259ad388f69408590cd63e8fca187ee
GO

GO
CREATE TABLE #tmp_bfc6bcaade5f4017b262d6c0b9522e91 ([Id] [int],[Name] [nvarchar](50))
GO

INSERT INTO #tmp_bfc6bcaade5f4017b262d6c0b9522e91 ([Id],[Name]) VALUES
(3,'Boolean'),
(4,'Decimal'),
(1,'Integer'),
(2,'String'),
(5,'Text')
GO
ALTER TABLE [dbo].[DataType] NOCHECK CONSTRAINT ALL
GO
UPDATE T SET 
T.[Name] = S.[Name]

FROM [dbo].[DataType] as T
INNER JOIN #tmp_bfc6bcaade5f4017b262d6c0b9522e91 as S
ON T.[Id] = S.[Id]
GO
SET IDENTITY_INSERT [dbo].[DataType] ON;
INSERT INTO [dbo].[DataType] (
	[Id],[Name])
SELECT
	[Id],[Name]
FROM #tmp_bfc6bcaade5f4017b262d6c0b9522e91 as S
WHERE NOT EXISTS (
	SELECT TOP 1 1 FROM  [dbo].[DataType] as T
	WHERE T.[Id] = S.[Id]
)
SET IDENTITY_INSERT [dbo].[DataType] OFF;
ALTER TABLE [dbo].[DataType] CHECK CONSTRAINT ALL
GO
DROP TABLE #tmp_bfc6bcaade5f4017b262d6c0b9522e91
GO

GO
CREATE TABLE #tmp_4819f4dcc4f84c0e8a694a025df880de ([Id] [int],[Name] [nvarchar](128),[Link] [nvarchar](128),[Ordinal] [int])
GO

INSERT INTO #tmp_4819f4dcc4f84c0e8a694a025df880de ([Id],[Name],[Link],[Ordinal]) VALUES
(1,'Home','/',0),
(3,'About','/Wiki About',1),
(4,'Help','/Wiki Help :: Wiki Help',2),
(5,'Search','/Page/Search',3)
GO
ALTER TABLE [dbo].[MenuItem] NOCHECK CONSTRAINT ALL
GO
SET IDENTITY_INSERT [dbo].[MenuItem] ON;
INSERT INTO [dbo].[MenuItem] (
	[Id],[Name],[Link],[Ordinal])
SELECT
	[Id],[Name],[Link],[Ordinal]
FROM #tmp_4819f4dcc4f84c0e8a694a025df880de as S
WHERE NOT EXISTS (
	SELECT TOP 1 1 FROM  [dbo].[MenuItem] as T
	WHERE T.[Id] = S.[Id]
)
SET IDENTITY_INSERT [dbo].[MenuItem] OFF;
ALTER TABLE [dbo].[MenuItem] CHECK CONSTRAINT ALL
GO
DROP TABLE #tmp_4819f4dcc4f84c0e8a694a025df880de
GO

GO
CREATE TABLE #tmp_9ebc50624bf54eed8b77391edb91a5fc ([Id] [int],[Name] [nvarchar](128),[Description] [nvarchar](1000))
GO

INSERT INTO #tmp_9ebc50624bf54eed8b77391edb91a5fc ([Id],[Name],[Description]) VALUES
(1,'Administrator','Administrators can do anything. Add, edit, delete, etc.'),
(2,'Member','Read-only user with a profile.'),
(3,'Contributor','Contributor can add and edit pages.'),
(4,'Moderator','Moderators can add, edit and delete pages.')
GO
ALTER TABLE [dbo].[Role] NOCHECK CONSTRAINT ALL
GO
UPDATE T SET 
T.[Name] = S.[Name],
T.[Description] = S.[Description]

FROM [dbo].[Role] as T
INNER JOIN #tmp_9ebc50624bf54eed8b77391edb91a5fc as S
ON T.[Id] = S.[Id]
GO
SET IDENTITY_INSERT [dbo].[Role] ON;
INSERT INTO [dbo].[Role] (
	[Id],[Name],[Description])
SELECT
	[Id],[Name],[Description]
FROM #tmp_9ebc50624bf54eed8b77391edb91a5fc as S
WHERE NOT EXISTS (
	SELECT TOP 1 1 FROM  [dbo].[Role] as T
	WHERE T.[Id] = S.[Id]
)
SET IDENTITY_INSERT [dbo].[Role] OFF;
ALTER TABLE [dbo].[Role] CHECK CONSTRAINT ALL
GO
DROP TABLE #tmp_9ebc50624bf54eed8b77391edb91a5fc
GO

GO
CREATE TABLE #tmp_b76ccf6932dc45e099d4d60b6205a169 ([Id] [int],[ConfigurationGroupId] [int],[Name] [nvarchar](128),[Value] [nvarchar](max),[DataTypeId] [int],[Description] [nvarchar](1000),[IsEncrypted] [bit])
GO

INSERT INTO #tmp_b76ccf6932dc45e099d4d60b6205a169 ([Id],[ConfigurationGroupId],[Name],[Value],[DataTypeId],[Description],[IsEncrypted]) VALUES
(38,1,'Address','https://localhost:44349',2,'the address of your wiki.',0),
(8,1,'Brand Image (Small)','/images/TightWiki Icon 32.png',2,'The brand image of the wiki, this is displayed on the top of all wiki pages.',0),
(4,1,'Copyright','Copyright &copy; NetworkDLS 2023',2,'The copyright of the wiki, this is shown at the botton of all pages.',0),
(27,1,'Default Country','US',2,'The country to use for the site culture for guests.',0),
(53,1,'Default Emoji Height','24',2,'The default height to scale emojis to. The width will be scaled to the same ratio.',0),
(47,1,'Default Language','English',2,'The language to use for the site culture for guests.',0),
(28,1,'Default TimeZone','Eastern Standard Time',2,'The timezone to use for the site culture for guests.',0),
(3,1,'FooterBlurb','TightWiki is an aspnet core MVC Wiki built on top of SQL Server and various other Microsoft technologies.',5,'The footer of the wiki, this is shown at the botton of all pages.',0),
(1,1,'Name','TightWiki',2,'The name of the wiki, this is displayed everwhere.',0),
(5,1,'New Page Template','Builtin :: Wiki Default Page',2,'the name of the wiki page to use as the default content when new wiki pages are created.',0),
(15,1,'Page Not Exists Page','Builtin :: Wiki Page Does Not Exist',2,'The name of the wiki page to display when a non existing page is requested.',0),
(30,1,'Pagination Size','20',1,'the number of items to return when pagination is used.',0),
(29,1,'Revision Does Not Exists Page','Builtin :: Wiki Page Revision Does Not Exist',2,'The name of the wiki page to display when a non existing page revision is requested.',0),
(49,2,'Allow Fuzzy Matching','1',3,'Whether to allow non-exact matches when searching.',0),
(46,2,'Minimum Match Score','0.60',4,'Value between 0.0 and 1.0 that determins how strong of a match a page search needs to be brfore it it returned in search results.',0),
(45,2,'Split Camel Case','1',3,'Whether to split CamelCasedStrings when parsing pages for search tokens. This can be helpful when pages contain alot of programming/code content.',0),
(7,2,'Word Exclusions','do,of,it,i,is,or,and,but,of,the,a,for,also,be,it,as,that,this,it,to,on,are,if,in',2,'When building a search index, these words will be excluded from indexing. Comma seperated.',0),
(50,3,'Include Search on Navbar','1',3,'Whether a search box will be shown on the navigation bar.',0),
(41,3,'Include wiki Description in Meta','1',3,'Whether the desciption of the page should be included in the HTML head meta.',0),
(43,3,'Include wiki Tags in Meta','1',3,'Whether the wiki tags attached to the page should be included in the HTML head meta keywords.',0),
(37,4,'Account Verification Email Template','<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>##SUBJECT##</title>
    <style>
        .body {
            max-width: 800px;
            min-width: 400px;
            background-color: #fbfaf8;
            word-wrap: break-word;
        }

        .confirmCode {
            max-width: 800px;
            min-width: 400px;
            background-color: #f6fff6;
            word-wrap: break-word;
        }
    </style>
</head>
<body style="margin:0px; padding:0px; border: 0 none; font-size: 11px; font-family: Verdana, sans-serif; background-color: #fbfaf8;">
    <table style="width: 100%; margin: 10px auto 50px auto; border: 0px #ffffff solid; background: #fbfaf8; font-size: 14px; font-family: Verdana, sans-serif;" align="center">
        <tbody>
            <tr>
                <td style="padding: 9px; color: #000000; background: #fbfaf8;">
                    <img src="##SITEADDRESS##/File/Image/TightWiki_Media/TightWiki_Icon_128_png" alt="##SITENAME##" />
                </td>
            </tr>
            <tr style="padding: 18px;">
                <td style="padding: 10px; vertical-align: top; background: #fbfaf8">
                    <div class="body">
                        ##PERSONNAME##,<br />
                        &nbsp;&nbsp;&nbsp;&nbsp; This email is being sent because someone (presumably you) created an account on ##SITENAME##.<br />
                        To finish your signup process, click the link below to confirm your email address:
                        <br /><br /><strong>Confirmation Link:</strong></br>
                        <font size="3" color="#aa0000">
                            <div class="confirmCode"><blockquote><a href="##SITEADDRESS##/User/##ACCOUNTNAME##/Confirm/##CODE##">Click here to confirm your email address</a></blockquote></div>
                        </font>
                        <br />Thanks,<br />
                        &nbsp;&nbsp;&nbsp;&nbsp;##SITENAME##
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</body>
</html>
',5,'HTML email template for new account verification',0),
(51,4,'Allow Google Authentication','1',3,'Whether to allow users to login/singup with Google.',0),
(9,4,'Allow Signup','1',3,'If set, users will be allowed to singup and create their own account.',0),
(24,4,'Default Country','US',2,'The default country to use for new accounts.',0),
(48,4,'Default Language','English',2,'The default language to use for new accounts.',0),
(11,4,'Default Signup Role','Contributor',2,'The default role to assign accounts when they singup.',0),
(25,4,'Default TimeZone','Eastern Standard Time',2,'The default timezone to use for new accounts.',0),
(26,4,'Request Email Verification','1',3,'If set, en email will be sent to request email verification.',0),
(22,4,'Require Email Verification','1',3,'If set, users can not login until their email addresses are verified.',0),
(40,4,'Reset Password Email Template','<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>##SUBJECT##</title>
    <style>
        .body {
            max-width: 800px;
            min-width: 400px;
            background-color: #fbfaf8;
            word-wrap: break-word;
        }

        .confirmCode {
            max-width: 800px;
            min-width: 400px;
            background-color: #f6fff6;
            word-wrap: break-word;
        }
    </style>
</head>
<body style="margin:0px; padding:0px; border: 0 none; font-size: 11px; font-family: Verdana, sans-serif; background-color: #fbfaf8;">
    <table style="width: 100%; margin: 10px auto 50px auto; border: 0px #ffffff solid; background: #fbfaf8; font-size: 14px; font-family: Verdana, sans-serif;" align="center">
        <tbody>
            <tr>
                <td style="padding: 9px; color: #000000; background: #fbfaf8;">
                    <img src="##SITEADDRESS##/File/Image/TightWiki_Media/TightWiki_Icon_128_png" alt="##SITENAME##" />
                </td>
            </tr>
            <tr style="padding: 18px;">
                <td style="padding: 10px; vertical-align: top; background: #fbfaf8">
                    <div class="body">
                        ##PERSONNAME##,<br />
                        &nbsp;&nbsp;&nbsp;&nbsp; This email is being sent because someone requested a password reset on ##SITENAME##.<br />
                        Click the link below to finish resetting your password:
                        <br /><br /><strong>Confirmation Link:</strong></br>
                        <font size="3" color="#aa0000">
                            <div class="confirmCode"><blockquote><a href="##SITEADDRESS##/User/##ACCOUNTNAME##/Reset/##CODE##">Click here to reset your password</a></blockquote></div>
                        </font>
                        <br />Thanks,<br />
                        &nbsp;&nbsp;&nbsp;&nbsp;##SITENAME##
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</body>
</html>',5,'HTML email template to use when sending a password reset email.',0),
(16,5,'Address','smtp.gmail.com',2,'The SMTP server ip/host to use when sending email.',0),
(21,5,'From Display Name','TightWiki',2,'The display name to show for all email communications.',0),
(18,5,'Password','/hBMRX+whTpWqAo7gVCnEg==',2,'The SMTP password to use when sending email.',1),
(19,5,'Port','587',2,'The SMTP port to use when sending email.',0),
(39,5,'Use SSL','1',3,'Whether SMTP should connect using SSL or not.',0),
(20,5,'Username','ASAPWikiMail@Gmail.com',2,'The account name to use for all email communications.',0),
(34,6,'Footer','',5,'HTML placed into the footer section of the page.',0),
(33,6,'Header','<script async src="https://www.googletagmanager.com/gtag/js?id=G-NQDCWX9F8R"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag(''js'', new Date());
  gtag(''config'', ''G-NQDCWX9F8R'');
</script>',5,'HTML placed into the header section of the HTML. A usefule place to put scripts and CSS.',0),
(36,6,'Post-Body','',5,'HTML placed inside the body tag but directly after the other body content.',0),
(35,6,'Pre-Body','',5,'HTML placed inside the body tag but just before the other content of the page.',0),
(56,7,'Cache Memory Limit MB','1024',2,'The memory limit (in megabytes) for the cache. Oldest items will be ejected when limit is reached.',0),
(52,7,'Page Cache Time (Seconds)','300',2,'The number of seconds to cache pages in memory (0 = disabled).',0),
(55,7,'Write Page Statistics','1',3,'Whether to record general page render statistics to the database.',0)
GO
ALTER TABLE [dbo].[ConfigurationEntry] NOCHECK CONSTRAINT ALL
GO
SET IDENTITY_INSERT [dbo].[ConfigurationEntry] ON;
INSERT INTO [dbo].[ConfigurationEntry] (
	[Id],[ConfigurationGroupId],[Name],[Value],[DataTypeId],[Description],[IsEncrypted])
SELECT
	[Id],[ConfigurationGroupId],[Name],[Value],[DataTypeId],[Description],[IsEncrypted]
FROM #tmp_b76ccf6932dc45e099d4d60b6205a169 as S
WHERE NOT EXISTS (
	SELECT TOP 1 1 FROM  [dbo].[ConfigurationEntry] as T
	WHERE T.[ConfigurationGroupId] = S.[ConfigurationGroupId] AND T.[Name] = S.[Name]
)
SET IDENTITY_INSERT [dbo].[ConfigurationEntry] OFF;
ALTER TABLE [dbo].[ConfigurationEntry] CHECK CONSTRAINT ALL
GO
DROP TABLE #tmp_b76ccf6932dc45e099d4d60b6205a169
GO

GO
CREATE TABLE #tmp_8eab31fe4e4c4ac9a433dfe50e420c06 ([Id] [int],[EmailAddress] [nvarchar](128),[AccountName] [nvarchar](128),[Navigation] [nvarchar](128),[PasswordHash] [nvarchar](128),[FirstName] [nvarchar](128),[LastName] [nvarchar](128),[Country] [nvarchar](128),[Language] [nvarchar](128),[TimeZone] [nvarchar](128),[AboutMe] [nvarchar](max),[Avatar] [varbinary](max),[CreatedDate] [datetime],[ModifiedDate] [datetime],[LastLoginDate] [datetime],[VerificationCode] [varchar](20),[EmailVerified] [bit],[RoleId] [int],[Provider] [varchar](20))
GO

INSERT INTO #tmp_8eab31fe4e4c4ac9a433dfe50e420c06 ([Id],[EmailAddress],[AccountName],[Navigation],[PasswordHash],[FirstName],[LastName],[Country],[Language],[TimeZone],[AboutMe],[Avatar],[CreatedDate],[ModifiedDate],[LastLoginDate],[VerificationCode],[EmailVerified],[RoleId],[Provider]) VALUES
(1,'admin@tightwiki.com','admin','admin','df5d2fa4d773ddf21b141daf0bc474fd69d285b5cd2cea1878306f0e640110e8','Default','Administrator','US','English','Eastern Standard Time',null,0x89504E470D0A1A0A0000000D494844520000022600000226080600000067CE41460000002C744558744372656174696F6E2054696D65004D6F6E2031392053657020323032322031373A30303A3134202D3035303036ED50C30000374674455874584D4C3A636F6D2E61646F62652E786D70003C3F787061636B657420626567696E3D22EFBBBF222069643D2257354D304D7043656869487A7265537A4E54637A6B633964223F3E0A3C783A786D706D65746120786D6C6E733A783D2261646F62653A6E733A6D6574612F2220783A786D70746B3D22584D5020436F726520352E312E32223E0A2020203C7264663A52444620786D6C6E733A7264663D22687474703A2F2F7777772E77332E6F72672F313939392F30322F32322D7264662D73796E7461782D6E7323223E0A2020202020203C7264663A4465736372697074696F6E207264663A61626F75743D22220A202020202020202020202020786D6C6E733A70686F746F73686F703D22687474703A2F2F6E732E61646F62652E636F6D2F70686F746F73686F702F312E302F223E0A2020202020202020203C70686F746F73686F703A486973746F72793E262378393B23204D616769632057616E64262378443B262378413B262378393B262378393B2747656E6572616C273A20262378443B262378413B262378393B262378393B262378393B274D6F6465273A204170702E436F6E7374616E74732E53656C656374696F6E4F7065726174696F6E2E5265706C6163652C20262378443B262378413B262378393B262378393B262378393B27416E7469616C696173273A2046616C73652C20262378443B262378413B262378393B262378393B262378393B2746656174686572273A20302C20262378443B262378413B262378393B262378393B262378393B2753616D706C654D6572676564273A2046616C73652C20262378443B262378413B262378393B262378393B274D617463684D6F6465273A204170702E436F6E7374616E74732E4D617463684D6F64652E52474256616C75652C20262378443B262378413B262378393B262378393B27436F6E746967756F7573273A2046616C73652C20262378443B262378413B262378393B262378393B27506F696E74273A202838342E322C39302E32292C20262378443B262378413B262378393B262378393B27546F6C6572616E6365273A20382C20262378443B262378413B262378393B262378393B27416E7469616C69617354797065273A204170702E436F6E7374616E74732E416E7469616C696173547970652E4F757473696465262378443B262378413B262378443B262378413B262378393B2320436C65617253656C656374696F6E262378443B262378413B262378393B262378393B262378443B262378413B262378443B262378413B262378393B23204C6179657250726F6D6F74654261636B67726F756E64262378443B262378413B262378393B262378393B262378443B262378413B262378443B262378413B262378393B2320436C65617253656C656374696F6E262378443B262378413B262378393B262378393B262378443B262378413B262378443B262378413B262378393B23204D616769632057616E64262378443B262378413B262378393B262378393B2747656E6572616C273A20262378443B262378413B262378393B262378393B262378393B274D6F6465273A204170702E436F6E7374616E74732E53656C656374696F6E4F7065726174696F6E2E5265706C6163652C20262378443B262378413B262378393B262378393B262378393B27416E7469616C696173273A2046616C73652C20262378443B262378413B262378393B262378393B262378393B2746656174686572273A20302C20262378443B262378413B262378393B262378393B262378393B2753616D706C654D6572676564273A2046616C73652C20262378443B262378413B262378393B262378393B274D617463684D6F6465273A204170702E436F6E7374616E74732E4D617463684D6F64652E52474256616C75652C20262378443B262378413B262378393B262378393B27436F6E746967756F7573273A2046616C73652C20262378443B262378413B262378393B262378393B27506F696E74273A20283533352C3233392E38292C20262378443B262378413B262378393B262378393B27546F6C6572616E6365273A20382C20262378443B262378413B262378393B262378393B27416E7469616C69617354797065273A204170702E436F6E7374616E74732E416E7469616C696173547970652E4F757473696465262378443B262378413B262378443B262378413B262378393B2320436C65617253656C656374696F6E262378443B262378413B262378393B262378393B262378443B262378413B262378443B262378413B262378393B2320436C65617253656C656374696F6E262378443B262378413B262378393B262378393B262378443B262378413B262378443B262378413B262378393B2320436C65617253656C656374696F6E262378443B262378413B262378393B262378393B262378443B262378413B262378443B262378413B262378393B23204D616769632057616E64262378443B262378413B262378393B262378393B2747656E6572616C273A20262378443B262378413B262378393B262378393B262378393B274D6F6465273A204170702E436F6E7374616E74732E53656C656374696F6E4F7065726174696F6E2E5265706C6163652C20262378443B262378413B262378393B262378393B262378393B27416E7469616C696173273A2046616C73652C20262378443B262378413B262378393B262378393B262378393B2746656174686572273A20302C20262378443B262378413B262378393B262378393B262378393B2753616D706C654D6572676564273A2046616C73652C20262378443B262378413B262378393B262378393B274D617463684D6F6465273A204170702E436F6E7374616E74732E4D617463684D6F64652E52474256616C75652C20262378443B262378413B262378393B262378393B27436F6E746967756F7573273A2046616C73652C20262378443B262378413B262378393B262378393B27506F696E74273A20283535332E3839312C3137362E323837292C20262378443B262378413B262378393B262378393B27546F6C6572616E6365273A20382C20262378443B262378413B262378393B262378393B27416E7469616C69617354797065273A204170702E436F6E7374616E74732E416E7469616C696173547970652E4F757473696465262378443B262378413B262378443B262378413B262378393B23204D616769632057616E64262378443B262378413B262378393B262378393B2747656E6572616C273A20262378443B262378413B262378393B262378393B262378393B274D6F6465273A204170702E436F6E7374616E74732E53656C656374696F6E4F7065726174696F6E2E5265706C6163652C20262378443B262378413B262378393B262378393B262378393B27416E7469616C696173273A2046616C73652C20262378443B262378413B262378393B262378393B262378393B2746656174686572273A20302C20262378443B262378413B262378393B262378393B262378393B2753616D706C654D6572676564273A2046616C73652C20262378443B262378413B262378393B262378393B274D617463684D6F6465273A204170702E436F6E7374616E74732E4D617463684D6F64652E52474256616C75652C20262378443B262378413B262378393B262378393B27436F6E746967756F7573273A2046616C73652C20262378443B262378413B262378393B262378393B27506F696E74273A20283539362E3038352C3233382E353036292C20262378443B262378413B262378393B262378393B27546F6C6572616E6365273A20382C20262378443B262378413B262378393B262378393B27416E7469616C69617354797065273A204170702E436F6E7374616E74732E416E7469616C696173547970652E4F757473696465262378443B262378413B262378443B262378413B262378393B2320436C65617253656C656374696F6E262378443B262378413B262378393B262378393B262378443B262378413B262378443B262378413B262378393B23204D616769632057616E64262378443B262378413B262378393B262378393B2747656E6572616C273A20262378443B262378413B262378393B262378393B262378393B274D6F6465273A204170702E436F6E7374616E74732E53656C656374696F6E4F7065726174696F6E2E5265706C6163652C20262378443B262378413B262378393B262378393B262378393B27416E7469616C696173273A2046616C73652C20262378443B262378413B262378393B262378393B262378393B2746656174686572273A20302C20262378443B262378413B262378393B262378393B262378393B2753616D706C654D6572676564273A2046616C73652C20262378443B262378413B262378393B262378393B274D617463684D6F6465273A204170702E436F6E7374616E74732E4D617463684D6F64652E52474256616C75652C20262378443B262378413B262378393B262378393B27436F6E746967756F7573273A2046616C73652C20262378443B262378413B262378393B262378393B27506F696E74273A20283236332E3533362C3135312E393731292C20262378443B262378413B262378393B262378393B27546F6C6572616E6365273A20382C20262378443B262378413B262378393B262378393B27416E7469616C69617354797065273A204170702E436F6E7374616E74732E416E7469616C696173547970652E4F757473696465262378443B262378413B262378443B262378413B262378393B232053656C6563744E6F6E65262378443B262378413B262378393B262378393B262378443B262378413B262378443B262378413B262378393B232053656C656374416C6C262378443B262378413B262378393B262378393B262378443B262378413B262378443B262378413B262378393B232043726F70262378443B262378413B262378393B262378393B2743726F7052656374273A20282836362C3133292C203534322C20353135292C20262378443B262378413B262378393B262378393B274D6F6465273A204170702E436F6E7374616E74732E43726F704D6F64652E437573746F6D2C20262378443B262378413B262378393B262378393B27556E697473273A204170702E436F6E7374616E74732E43726F70556E6974732E496E636865732C20262378443B262378413B262378393B262378393B2753656C656374656441726561273A2046616C73652C20262378443B262378413B262378393B262378393B275072696E745769647468273A202D312C20262378443B262378413B262378393B262378393B275072696E74486569676874273A202D312C20262378443B262378413B262378393B262378393B2743726F7041734E6577496D616765273A2046616C73652C20262378443B262378413B262378393B262378393B27526F746174696F6E416E676C65273A202D302C20262378443B262378413B262378393B262378393B274175746F466974273A2046616C7365262378443B262378413B262378443B262378413B262378393B2320526573697A6543616E766173262378443B262378413B262378393B262378393B27417370656374526174696F273A20312E30353234332C20262378443B262378413B262378393B262378393B2746696C6C436F6C6F72273A202831312C31312C3131292C20262378443B262378413B262378393B262378393B27486F7269506C616365273A204170702E436F6E7374616E74732E486F72697A6F6E74616C547970652E43656E7465722C20262378443B262378413B262378393B262378393B274D61696E7461696E417370656374273A2046616C73652C20262378443B262378413B262378393B262378393B274E657744696D556E697473273A204170702E436F6E7374616E74732E556E6974734F664D6561737572652E506978656C732C20262378443B262378413B262378393B262378393B274E6577486569676874273A203535302C20262378443B262378413B262378393B262378393B274E65775769647468273A203535302C20262378443B262378413B262378393B262378393B27506C616365426F74746F6D273A2031382C20262378443B262378413B262378393B262378393B27506C6163654C656674273A20342C20262378443B262378413B262378393B262378393B27506C6163655269676874273A20342C20262378443B262378413B262378393B262378393B27506C616365546F70273A2031372C20262378443B262378413B262378393B262378393B2756657274506C616365273A204170702E436F6E7374616E74732E566572746963616C547970652E43656E746572262378443B262378413B262378443B262378413B262378393B232043726F704669787570262378443B262378413B262378393B262378393B262378443B262378413B262378443B262378413B392F31392F3230323220353A30313A353520504D20232046696C6520274153415057696B69204C6F676F2E707370696D616765272073617665642E262378443B262378413B262378443B262378413B262378393B232053656C656374696F6E262378443B262378413B262378393B262378393B2747656E6572616C273A20262378443B262378413B262378393B262378393B262378393B274D6F6465273A204170702E436F6E7374616E74732E53656C656374696F6E4F7065726174696F6E2E5265706C6163652C20262378443B262378413B262378393B262378393B262378393B27416E7469616C696173273A2046616C73652C20262378443B262378413B262378393B262378393B262378393B2746656174686572273A20302C20262378443B262378413B262378393B262378393B2753656C656374696F6E5368617065273A204170702E436F6E7374616E74732E53656C656374696F6E53686170652E52656374616E676C652C20262378443B262378413B262378393B262378393B275374617274273A2028362C333331292C20262378443B262378413B262378393B262378393B27456E64273A20283534382C343433292C20262378443B262378413B262378393B262378393B2753656C656374696F6E5374796C65273A204170702E436F6E7374616E74732E53656C656374696F6E5374796C652E4E6F726D616C2C20262378443B262378413B262378393B262378393B2753656C656374696F6E466978656453697A65273A20283132382C313238292C20262378443B262378413B262378393B262378393B2753656C656374696F6E4669786564526174696F273A2028312C3129262378443B262378413B262378443B262378413B262378393B2320436C65617253656C656374696F6E262378443B262378413B262378393B262378393B262378443B262378413B262378443B262378413B262378393B232053656C6563744E6F6E65262378443B262378413B262378393B262378393B262378443B262378413B262378443B262378413B262378393B232054657874262378443B262378413B262378393B262378393B275669736962696C697479273A20547275652C20262378443B262378413B262378393B262378393B274372656174654173273A204170702E436F6E7374616E74732E43726561746541732E566563746F722C20262378443B262378413B262378393B262378393B275374617274273A202831342C333638292C20262378443B262378413B262378393B262378393B2754657874466C6F77273A204170702E436F6E7374616E74732E54657874466C6F772E486F72697A6F6E74616C446F776E2C20262378443B262378413B262378393B262378393B275465787454797065273A204170702E436F6E7374616E74732E54657874547970652E54657874426173652C20262378443B262378413B262378393B262378393B274D6174726978273A205B262378443B262378413B262378393B262378393B262378393B312C262378443B262378413B262378393B262378393B262378393B302C262378443B262378413B262378393B262378393B262378393B302C262378443B262378413B262378393B262378393B262378393B302C262378443B262378413B262378393B262378393B262378393B312C262378443B262378413B262378393B262378393B262378393B302C262378443B262378413B262378393B262378393B262378393B302C262378443B262378413B262378393B262378393B262378393B302C262378443B262378413B262378393B262378393B262378393B31262378443B262378413B262378393B262378393B5D2C20262378443B262378413B262378393B262378393B274175746F4B65726E273A20547275652C20262378443B262378413B262378393B262378393B274B65726E696E67273A20302C20262378443B262378413B262378393B262378393B27547261636B696E67273A20302C20262378443B262378413B262378393B262378393B274C656164696E67273A20302C20262378443B262378413B262378393B262378393B27466F6E74273A207527417269616C272C20262378443B262378413B262378393B262378393B27506F696E7453697A65273A203130302C20262378443B262378413B262378393B262378393B274974616C6963273A2046616C73652C20262378443B262378413B262378393B262378393B27426F6C64273A2046616C73652C20262378443B262378413B262378393B262378393B27556E6465726C696E65273A2046616C73652C20262378443B262378413B262378393B262378393B275375706572536372697074273A2046616C73652C20262378443B262378413B262378393B262378393B27537562536372697074273A2046616C73652C20262378443B262378413B262378393B262378393B27537472696B6574687275273A2046616C73652C20262378443B262378413B262378393B262378393B27416E7469616C6961735374796C65273A204170702E436F6E7374616E74732E416E7469616C69617345782E53686172702C20262378443B262378413B262378393B262378393B275761727054657874273A20547275652C20262378443B262378413B262378393B262378393B2753657454657874273A204170702E436F6E7374616E74732E4A7573746966792E4C6566742C20262378443B262378413B262378393B262378393B2746696C6C273A20262378443B262378413B262378393B262378393B262378393B27436F6C6F72273A2028302C302C30292C20262378443B262378413B262378393B262378393B262378393B275061747465726E273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B274772616469656E74273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B2754657874757265273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B27417274273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B274964656E74697479273A2075274D6174657269616C272C20262378443B262378413B262378393B262378393B275374726F6B65273A20262378443B262378413B262378393B262378393B262378393B27436F6C6F72273A202832342C35302C323238292C20262378443B262378413B262378393B262378393B262378393B275061747465726E273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B274772616469656E74273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B2754657874757265273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B27417274273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B274964656E74697479273A2075274D6174657269616C272C20262378443B262378413B262378393B262378393B274C696E655769647468273A20312C20262378443B262378413B262378393B262378393B274C696E655374796C65273A20262378443B262378413B262378393B262378393B262378393B274E616D65273A207527272C20262378443B262378413B262378393B262378393B262378393B274669727374436170273A20287527272C302E32352C302E3235292C20262378443B262378413B262378393B262378393B262378393B274C617374436170273A20287527272C302E32352C302E3235292C20262378443B262378413B262378393B262378393B262378393B274669727374536567436170273A20287527272C302E32352C302E3235292C20262378443B262378413B262378393B262378393B262378393B274C617374536567436170273A20287527272C302E32352C302E3235292C20262378443B262378413B262378393B262378393B262378393B275573655365676D656E7443617073273A2046616C73652C20262378443B262378413B262378393B262378393B262378393B275365676D656E7473273A204E6F6E652C20262378443B262378413B262378393B262378393B274A6F696E273A204170702E436F6E7374616E74732E4A6F696E745374796C652E4D697465722C20262378443B262378413B262378393B262378393B274D697465724C696D6974273A2031302C20262378443B262378413B262378393B262378393B2743686172616374657273273A207527536861727057696B69272C20262378443B262378413B262378393B262378393B27537472696E6773273A204E6F6E652C20262378443B262378413B262378393B262378393B2754657874546172676574273A2028302C302C5B315D2C54727565292C20262378443B262378413B262378393B262378393B2750617468546172676574273A204E6F6E652C20262378443B262378413B262378393B262378393B27496E4F626A656374273A2046616C7365262378443B262378413B262378443B262378413B262378393B2320566563746F724D6F7665262378443B262378413B262378393B262378393B274D6F766558273A2032392C20262378443B262378413B262378393B262378393B274D6F766559273A203334262378443B262378413B262378443B262378413B262378393B2320566563746F724D6F7665262378443B262378413B262378393B262378393B274D6F766558273A20302C20262378443B262378413B262378393B262378393B274D6F766559273A2035262378443B262378413B262378443B262378413B262378393B232054657874262378443B262378413B262378393B262378393B275669736962696C697479273A20547275652C20262378443B262378413B262378393B262378393B274372656174654173273A204170702E436F6E7374616E74732E43726561746541732E566563746F722C20262378443B262378413B262378393B262378393B275374617274273A202834332C343037292C20262378443B262378413B262378393B262378393B2754657874466C6F77273A204170702E436F6E7374616E74732E54657874466C6F772E486F72697A6F6E74616C446F776E2C20262378443B262378413B262378393B262378393B275465787454797065273A204170702E436F6E7374616E74732E54657874547970652E54657874426173652C20262378443B262378413B262378393B262378393B274D6174726978273A205B262378443B262378413B262378393B262378393B262378393B312C262378443B262378413B262378393B262378393B262378393B302C262378443B262378413B262378393B262378393B262378393B302C262378443B262378413B262378393B262378393B262378393B302C262378443B262378413B262378393B262378393B262378393B312C262378443B262378413B262378393B262378393B262378393B302C262378443B262378413B262378393B262378393B262378393B302C262378443B262378413B262378393B262378393B262378393B302C262378443B262378413B262378393B262378393B262378393B31262378443B262378413B262378393B262378393B5D2C20262378443B262378413B262378393B262378393B274175746F4B65726E273A20547275652C20262378443B262378413B262378393B262378393B274B65726E696E67273A20302C20262378443B262378413B262378393B262378393B27547261636B696E67273A20302C20262378443B262378413B262378393B262378393B274C656164696E67273A20302C20262378443B262378413B262378393B262378393B27466F6E74273A207527417269616C20526F756E646564204D5420426F6C64272C20262378443B262378413B262378393B262378393B27506F696E7453697A65273A203130302C20262378443B262378413B262378393B262378393B274974616C6963273A2046616C73652C20262378443B262378413B262378393B262378393B27426F6C64273A2046616C73652C20262378443B262378413B262378393B262378393B27556E6465726C696E65273A2046616C73652C20262378443B262378413B262378393B262378393B275375706572536372697074273A2046616C73652C20262378443B262378413B262378393B262378393B27537562536372697074273A2046616C73652C20262378443B262378413B262378393B262378393B27537472696B6574687275273A2046616C73652C20262378443B262378413B262378393B262378393B27416E7469616C6961735374796C65273A204170702E436F6E7374616E74732E416E7469616C69617345782E53686172702C20262378443B262378413B262378393B262378393B275761727054657874273A20547275652C20262378443B262378413B262378393B262378393B2753657454657874273A204170702E436F6E7374616E74732E4A7573746966792E4C6566742C20262378443B262378413B262378393B262378393B2746696C6C273A20262378443B262378413B262378393B262378393B262378393B27436F6C6F72273A202838342C3135322C323438292C20262378443B262378413B262378393B262378393B262378393B275061747465726E273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B274772616469656E74273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B2754657874757265273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B27417274273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B274964656E74697479273A2075274D6174657269616C272C20262378443B262378413B262378393B262378393B275374726F6B65273A20262378443B262378413B262378393B262378393B262378393B27436F6C6F72273A20283139302C3139382C323438292C20262378443B262378413B262378393B262378393B262378393B275061747465726E273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B274772616469656E74273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B2754657874757265273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B27417274273A204E6F6E652C20262378443B262378413B262378393B262378393B262378393B274964656E74697479273A2075274D6174657269616C272C20262378443B262378413B262378393B262378393B274C696E655769647468273A20312C20262378443B262378413B262378393B262378393B274C696E655374796C65273A20262378443B262378413B262378393B262378393B262378393B274E616D65273A207527272C20262378443B262378413B262378393B262378393B262378393B274669727374436170273A20287527272C302E32352C302E3235292C20262378443B262378413B262378393B262378393B262378393B274C617374436170273A20287527272C302E32352C302E3235292C20262378443B262378413B262378393B262378393B262378393B274669727374536567436170273A20287527272C302E32352C302E3235292C20262378443B262378413B262378393B262378393B262378393B274C617374536567436170273A20287527272C302E32352C302E3235292C20262378443B262378413B262378393B262378393B262378393B275573655365676D656E7443617073273A2046616C73652C20262378443B262378413B262378393B262378393B262378393B275365676D656E7473273A204E6F6E652C20262378443B262378413B262378393B262378393B274A6F696E273A204170702E436F6E7374616E74732E4A6F696E745374796C652E4D697465722C20262378443B262378413B262378393B262378393B274D697465724C696D6974273A2031302C20262378443B262378413B262378393B262378393B2743686172616374657273273A207527536861727057696B69272C20262378443B262378413B262378393B262378393B27537472696E6773273A204E6F6E652C20262378443B262378413B262378393B262378393B2754657874546172676574273A2028302C302C5B315D2C54727565292C20262378443B262378413B262378393B262378393B2750617468546172676574273A204E6F6E652C20262378443B262378413B262378393B262378393B27496E4F626A656374273A2046616C7365262378443B262378413B262378443B262378413B262378393B2320566563746F724D6F7665262378443B262378413B262378393B262378393B274D6F766558273A202D31352C20262378443B262378413B262378393B262378393B274D6F766559273A202D33262378443B262378413B262378443B262378413B262378393B23205069636B262378443B262378413B262378393B262378393B2754797065273A204170702E436F6E7374616E74732E4F626A65637453656C656374696F6E2E53656C6563742C20262378443B262378413B262378393B262378393B2758273A203736372E352C20262378443B262378413B262378393B262378393B2759273A203235392E352C20262378443B262378413B262378393B262378393B275769647468273A20312C20262378443B262378413B262378393B262378393B27486569676874273A20312C20262378443B262378413B262378393B262378393B2747726F7570273A20547275652C20262378443B262378413B262378393B262378393B2748616E646C6531273A20283335362C353234292C20262378443B262378413B262378393B262378393B2748616E646C6532273A20283335362C333033292C20262378443B262378413B262378393B262378393B2748616E646C6533273A20283634382C333033292C20262378443B262378413B262378393B262378393B2748616E646C6534273A20283634382C353234292C20262378443B262378413B262378393B262378393B275069766F74273A20283530322C3431332E35292C20262378443B262378413B262378393B262378393B274561726C795834536372697074273A2046616C7365262378443B262378413B262378443B262378413B262378393B23205069636B262378443B262378413B262378393B262378393B2754797065273A204170702E436F6E7374616E74732E4F626A65637453656C656374696F6E2E53656C6563742C20262378443B262378413B262378393B262378393B2758273A203236362E352C20262378443B262378413B262378393B262378393B2759273A203338312E352C20262378443B262378413B262378393B262378393B275769647468273A20312C20262378443B262378413B262378393B262378393B27486569676874273A20312C20262378443B262378413B262378393B262378393B2747726F7570273A20547275652C20262378443B262378413B262378393B262378393B2748616E646C6531273A20283335362C353234292C20262378443B262378413B262378393B262378393B2748616E646C6532273A20283335362C333033292C20262378443B262378413B262378393B262378393B2748616E646C6533273A20283634382C333033292C20262378443B262378413B262378393B262378393B2748616E646C6534273A20283634382C353234292C20262378443B262378413B262378393B262378393B275069766F74273A20283530322C3431332E35292C20262378443B262378413B262378393B262378393B274561726C795834536372697074273A2046616C7365262378443B262378413B262378443B262378413B262378393B2320566563746F7220416C69676E20486F72697A6F6E74616C6C792043656E74657220696E2043616E766173262378443B262378413B262378393B262378393B262378443B262378413B262378443B262378413B31302F362F323032322031313A32363A313020414D20232046696C652027536861727057696B69204C6F676F2E707370696D616765272073617665642E262378443B262378413B262378443B262378413B3C2F70686F746F73686F703A486973746F72793E0A2020202020203C2F7264663A4465736372697074696F6E3E0A2020203C2F7264663A5244463E0A3C2F783A786D706D6574613E0A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200A2020202020202020202020202020202020202020202020202020200A3C3F787061636B657420656E643D2277223F3E481866350000000774494D4507E60A060F1A1CCC62F4EB000000097048597300000B1200000B1201D2DD7EFC0000000467414D410000B18F0BFC61050000C0AA4944415478DAECBD57741457D6F73D6BBD17EFC57BF95DBC97DFC5B7D6F33C637B661CC6C639CD387B9CC939E79C730E36E000B601010294510E08A19CB3844446800222094C9440EABCBFB3ABBB85C020557577757557FD7F6B9D35F68C34ADEE3E75EA577BEFB3CF5FFE0200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000C01BAEDD75D05531CE5FBE4BE75B6F91D67F0F0081CAF576075DBB6B17D78B9D6E887FD6FAEF010080A0E6FA3D211FD7ED54DB62A3FCB3364AA9B75278B985761458E8B77C0BFD9A739F76E5B5535CB5990A1B6C74FAAA9DDAEE61F105C6E5C20D3B5534D928F59895222AACB4B7D842BFBBAE97D0120BC5D75A29EB948D2AC5CF9CB966A78B7F9871BD0000405F9CBC6CA3F4E356DA5D64A155A9669A106EA2C1BB4D34609773F4EF31DCFFDD8850132D4A34D3CE422B1D3969A3734268B47E1F00F8834BB7ED547ADE4607CAACB4F69099C6873DBC2E9E74BD0C0C31D1A87D265A9060A69FB34D14567C8F0A4E75489115ADDF0B00000414A7AFDA28A6DA424B84600CDBEB5A4C779AE83B058317DED162D15D2716E843E2A9B1F926165BA04F384D5372C146DB732D3425C225210AAF17FEF9C1215D342DB24B48BD458AB668FDBE000040732EDF7648E1E575E9661A1EAA6C61ED6D8C3B60A29F732C542A166FE4D7819E3871D94EE1E5569A7550B98C3C6D7054725E9C9962AAAC74F61A841E0060504E5DB1D39E622B4D897486987D25253D17DB39B12669B16DFE038B2D087E724EDB684D9A8586EFF5FDF5C2519731FB4DB429C34CC5E771BD00000C0617E07D7FC442235458601F1F630F98E8F77C8B5420ABF5FB06C01378674D42AD9566C6A87FBDB0D02F4C30D3A1E348ED00000C42F1791BAD4831D3D03DEA2FB2EEC14F983F665BA49D3E5ABF7F0094C0F524BCA3664298FFAE178E60B204C5565BE83A52A100003D5374CE46CB92CCD25399BF16D99E9113DE36D97A0B72028207AEC1E294A4BFAF174EED4C8B72A642AFB7E39A0100E890620DA5C43D264598285A2CB4DCA44DEBCF0380BE2868B0D16271CD6875BDB09C4C8F6639B1404E0000FA428A94249B69888652E21ED3A2CD947102F97310D81CBB64937A93687DBD3C1A3981D003007400D7942C0F1029E1C17FC7F719A83701810B0BC0412102DC0C4DEBEBE561E4C44C07ABADD87E0F00086E4A584A5202474ABA533AE1268AAFB1628105014955B38D16276A7F9D3C29AD130B390100042B25AEDD3743FCB8FB46EE181462A2D56966E25E2A5A7F4E00F4E4EA1DBBD4627E981FB6D22B1D03859CCC8836535C0DE40400106470C7D515A9812925EE3131DC24F586D0FAB302A027352D1C2DD1BEB6A4373999190339010004112C252B035C4A78F0DFF753B6050798818022FDB84D3AF349EBEB03720200D005C12225EEC11D2EEB5AB143070406DC63870FD4D3FABA502227DCFC0D7202000848584A56059194F0E0BE2629F548E780C0E068AB5DDA56AFF575215B4EB843EC41C809002000293CDB45ABD32C7E6D33EF8B3132D444BB8B2C58504140C00DD52647687F5D28959359424E126A1179040004006D37EF5156FD1D5A91DC197452C26398F89B7FCD839880C020FBB44D3A3A41EBEBC2633939CA9113D46C01003424EFD47D5A9E789F86ECEED27C71F464707BFCADD910131018649CB449074E6A7D5D782E27D8E90600D090F2461BAD4AE90A5A29E1D15F8C8D19662CA401C6F9D65B5473EE36715B769E679CE2C83BEB1CFCCFBCA5B6E5A6FE9ECCD38ED9A41BBCD6D785377232FBA099128F424E00007E866F166BD2CC4199BE795C4C361C8698040A67AED9A940C8C78EDC765A91749FE6C599695C9833B2C5BB4078701761EE40BA35CB22B5482FBF60A3A63FF42129A9F556A9C3AAD6D785D772126BA6A43AC80900C04F5434F2E16216A93E43EB45D0DBC11D60B764424CB4E65C9B9D92C453366F351F1FE66C7FDEDF258E4F95CA5D4E61991A65A61F8E58A49E1AD5CDF6A08EA41C3E610D7AD9775F5773202700007F50D964A375E9FA90121EBCB5795B2E6A4CB424E7B495368839357ABF53363C8D7CF10D9DFB6AFC986DA1E47A1BD5B7DAE9F2EDE0DAC29A753AF09BAB299593E43AECD60100A844859092F587CCBA91121EC3434DB4AB1062A205DCF782A31C53237B8F8C281D1C6DE1EF95D340DB73ADC4751BC72FDB89CFA0D1FA3DF745FE599B745482D6D7852FE564AE2427889C00007C8C24253A8A94B8C778711388C32E02BFC3C700EC2FB54A5112B5BEDBFE2E491921246551A2997ECFB710A74A4E5EB151DBBDC094144E45713762ADAF0B9FCAC96E2127421253EA11390100F888B2F3665A976E0EDA6D8CBD8DB9B15D5476AE130BA61FB976DB44E1E566E969DA5FDFB35B5246ED33499D55438A2C9479D242272F99E9AAF87BB4FE4CDC9CBBD249BF6407EF2EB7DEE5C4444947CD74B1AD3D603E6F0040109273EC0EAD4ABE4FC3F6E870B10CE9A2F5691D74AAF916164A3F12577E8FC61DE8D4EC7B6749E1DD3DA3F775D1D284FBD20EA0B49A3B5475F626D59E6CD47C2E4497DE130F01DA7D3E6A5E6FB3631E5078E14DAA39D1A4F9E70C0008326EDCEEA08253EDB43A459F52C263425817C5547652DBADFB5824FD44DEC90E9A1D1D38375D2EB61D286E98E38528AD4CEAA05F8FDCA0B4CA6B74EEB2764FF5250D0F6861823EAF39969399511DB43FFF3A9D6E6AC3750700904F55B38D361ED667FAE63BD713F3F26433D55F0ACC5A033D72F98E436AFFEFCB42579F4ACA4E67B3C019429C761458880B51B52898BD74DB417B4AAC52BF16AD3F13B5E4842327F1D50F70ED0100E451D562A34D19FA95121E63F69B28AC0C45AFFE844F9FE69E235A7FF7F26E9EDC1FC5447B8BADC44DDFFCFD59159FB7D1AC98E0F8AC3C959379715D94760CD72000A00FAA3952C25212AAFDE2A5DA93F12EE72E0D7EAF5A7FDE468177C184145B34FFEE95CE133E7D7A43868578579A3F3FAFE69B766917913F0B84FD3DB839DEFC04331D3A8EEB1000F014F846BD492CC223742C253C385AC25B55B5FEBC8DC4892B369A1F1F9C11009683C54264CB1AFD7B03E554D2CC18EDDFBFDA72B2209EE504D72300E031F850B4EF0D2025C3F69AE8FB23163A7905B525FE245DDC788606716A906FA0DCC7A7A1CD7FF3E6CA1D3B45565868DC01EDDFBFEA729200390100F4A0A6C52EDDACF52E25BC00AE4A35536533A4C49F5CBA65A79F73822B8DF3F8E0825D8EB47197E04BB7FD377F1A6FD869A778CD9106B836B9B15CFA09A47500303C1C29F9C10052E20EC7173660E1F3373CC7F83460ADE7802FE46472A4593AD1D89F9FDFD96B4EB1D37331FA237282C80900C6A5B6C54E9B0D22258BC482977B060B9E16C4D75A69A04E8A38074A826BA2723FD79B9CBA62A3AD59C691133E3A40EB790B00F033B5E2297673A691A40491122D68FEC39926D47A1EF872705B7BEE73C2E7FDF8F3B374CBC93003C8C922494E70CD0260186A2F3AA544EF796B9692858894680AF72ED1D369B93CF8CC1DDE61547CCEFFF38A8BB6B7661A434EF8DACD40E40400FD73B4C5465B0C242539A7F1D4A52561E5FA8A96B8079F8ABCAFC4A2C9DC6239D962A0C809E404001D73F4224B89D91052C2BD11B24F6341D392F3D76DB42A2D387B97C89963ABC57BE3F48A169F6DB79CECD1FEB3505B4EB868FDC8493C6000A03B584A383F6D182939255F4A6A6B6AB0E8A940418395C6E8B40707A773E6C49AA8C0C7BBBC2A2B2A64FFFF9DB86CA7CDE24143EF7232C4252799901300F483512225BC63821B35652B48DF242525D1F4E9D369E3860D58F47CC8F5763BED2ED267B484076F1D9E1461A2E43ADF45E5A2A3A369FCF871F4DB6FBFC997138E9C64EA3F7232A43B7282282800414F5DAB8D7E3448A4647EBC722919306000FDD77FFF174D9E3C090B9E0FE183EFF83C22ADE7859A8377E78497FBAECE64E78E1DF4F77FFC9DDE78F30DDAB6ED174572B2D94072920939012078A96729C9B6480BA8D68B8A9A636077FAC60329F9AFFFA2FE03FA53624202163B1F9275CAAAFBADE8FCFE0EF8F084EA9292629A3F7F1EFDEDEF7F532E27979D7232D40072B224C94C590AAE7500408050DF6A378C94781C29714949427C3C16391F72F98E9DB6E7E973374ECF3176BF89627CDC05B6A4F83139F94559E4E40723C889787F4B594EB0E30E80E0A1FE928D7E328294ECEAA2F971CA9E9E2025EA537FC94EB30F6A3F3FD41CEE1A93241FD698B8292E2EF2387272FC3237B4331B434E92B1F30E80A0A0BAB1937ECA318694CC8E7EA028DF9C9498D85D5322474AEA8E1EC5A2E701C9F536699BA7D67344CDC1BB72661DE43E399EDF187BDB0D56EC45E4E4B87830318C9C24298B960200FC4CF1A93BB4E548A7FEA524C444B3631E5062E55DD90B52620F29E1FF4CE8A3A6E4975F7EA6952B579292ED9BE02F7FB978CBB94B44EB39E28F39B85C3CB11FBBE4595BFA5D3B77D2C2850B8953374FFB19A79CCCEF96935F94C8C965E7510043742E88889C0010C0545D78403FA477D0C8D02ECD170BB56F08F3E2CC945475CF7329E92352B261C37A7AE38DD769E8B0A154545488054F01654D369A1CA1FD3C517B7044887B885CB9EBF0687E6C58BF9E5E7BFD359A3E7D1A151715C98F9C2848EB1CE3C84986312227CB849CE4E03C2C0002077E3AFA31CB64182951D268C92D25FFFDDFFF2D2B52C252F2BA9092CF3FFF8CC2C20E60A15348D4192B4D4AB7D0F028330DD4F10D915BD21F28F37CAB706E4E8EB445FDB5D75EA569D3A6CA90130F2327978C13396139C1619D0004002C25BFE45868B4DED337BB4C34375648898242574FA5E43FFFF91C52E201E7EE39686B838D569DB5D1FC4A2B4DCBB6D0D844F1C41E6EA2FE3ABA313ABBBE9AA9E0AC77E98347E464EA542A2A7C7A74AEC42527EE3E274AE484D34DDF6718434E96A7404E00D014C348498890923865E7653C222503594A7A4FDFAC8794784DD91F0E5A77C14EEB9AC568B2D3EAF3765A76C24673CB2C3425D3426312CC34845BD4EFD27E4E7933B899DF86743335DDF0FE06E89493C9424E5EA3A98AE5E4674572B2C90072C2692BAEFDC9839C00E07FB8A1D2B65C8B1452D67A315073B89F4E3D9692017D4B4977FA0652E23157EE3B28A2D941EB5B9C635DB3C32928DD9262A325C7AC34BBD842930E5B6894F84E07056903B6B142AEC2BD48E33C4ECFC8C9D4A953A8B01739E1948F3791938D424EF4BE638AE564450ACB090A6201F01BDC48891B5819454A324E78112989EF3B52F20622255E73F69E837E68B0778B49CFD12D2862AC1592B2AAC1468B6AAD3423DF4213D2CC3422DA4403F76A3FDFE40C4E292E8C3753D979DFDEF4DC72F2AA9093292C270505BDD49C14791C39A937909C705A27CFCB741B0040067CDCF936034989A2484942C263E99BDE6B4AD6AFF73C7D73B4B6160B5E0F0AAF3B68ED85278BC9D324654DA39D569CB1D1822A2B4DCFB5D0B864330D8B14DF7D00DF34F986B735CB4C57EEC8DB26ACE4E46A969329525A47C8C994C9BDCB4951112D58D0434E7E56222736DA78D86C0839E1C849FE59A47500508DBAE62EDA966B368494CC88EAA4A49AFBD476EB81AC454571A464BD67919282FC7C5ABA6409AD58B182EAEBEAB0E009CEDDECA23D176C7D4AC9A382F268AA678DF8FD654242E7955B696A96AB1E25CC44FD43B49F8FEED17F67174D08EBA2A872797372DFBE7D52DD48745494223971A775A64C99423CDF9EF6B3525AC74339293F779FD6A4DEA781219D9A7FAEEACB8989724E9A70AD02E06BCA4EDFA62D191D346A9FBE179201BBBA84943CA0F80AE5CDD394444A3C9192FCFC3C9A3469123DFFC2F3D20D075113279597EED1C6066562F2B428CAC37A141BCD29B5D2E423161A1D279EEE03A0C09BBB0D2F8C7F4005276ECBFADE7FFD753BBDFAEAABF4C9A79F50644484ECB992939DDD1D39E1C2D85EE5A4D8F3C849C1895BB434EE0E0D0AD1779B8121BBBB6849C27D4A2ABF41F5A71A71CD02E00B6A1AEFD38F99F70D202526E98C9543F526BA7EBB53D60292E04EDFFCCF7FD3C081036548C93AA7947CF11F0FA464A2242523478DA4C3E9E958E004D7EE3CA043AD265AD7D8771A47A9A448F528E76CB4B8CE46B30A2D3431DD4C23634C9A15CD0EDF6BA2ED395D74F90F7973B3B2B29256AE5C41FD5EED479F2A94939E691D8EA0E4E7E5F5DAE7C41339B971AB9D72EB6ED0AAE4FB34388022536AC9C9A2B8764A286DC3750B80B79CBE6AA7DFF22D34E680F617B7DA52C2678F1CF6A4D055A994781029E19B835B4AD20F1DC2E2E6A2A9DD41BF9D1752D2EC1B3179AAA408F15979D6460BABAD3423CF42E353CC343CCAE4B7266EFDC5FC9C16CDF3535931251F69B072855B4E3EA5C8C848C591132E889DD4979C7851735272FA1E6D48B748DBA0B55E07D496138E9C649F942796008027603429493F2E5F4A3C8D947CE151A46412BD0029792275771CB4E1BC531E7C2D26BDD5A32C3F65A3F915569A96E39F266EDC4B6755AA994E5D557E36CE9FE44469E4648A4B4E26F51539F15C4EEA2E8AEFCF2072C2352785E750100B8062584A7E2F80943C099690FEFDFBD3FFFCCFFFC89292753DA4243C3C4CBE94E43D949251A346513AD2377F22F58A4B1C54921239F5284B8F5B9D4DDCB2D46BE2C60763EE29F6BC778924272B574A3527DECA495E6E6E1F72B280FEF1FC3F2439F959819C1C1572B22EDDAC7B39E1825896CC22C80900F291A4C40091120E8FCF8C3153DA71F9E1F147A46490DA5232915E78F10548C953B870CF41BF9C7349829FC4A4574911379A25F5569A5D62A5C919BE6BE2E6AC7DE256E7DEF5C4785C4E223C9113F1BB13274E24FEF7A7FDAC94D659D8534E7E92FD3AB52D365A77C81872B21A7202803CCE5C73464AC61A614B70B49952EB3D8C9428941245E91B48892C2A6F0A41B8A04E7D89D745B3DCC4EDA89566167013370B8D1002EC691337BE497324E1C275E5699C3F7D665E444E7272B295C9C902CFE4A4A6D9466B0FE93FAD33CC2527C59013009E0E4BC90E0348497F494A4C424A023C52329AA50435254FE2DA0307C55C0C0C29E9B389DB691B2DA8B6D274A968D6A2B889DB18713D8695FBAE83A8379113A9205692937E3461E204CA51297252D362A33587CC526D8DD6EB85EA7292063901E0899CBD66734A8901D2371C294951534AD6AD9516624FA464E223528248C9D368B8E7A02D0DEA16BDFABC68960F15E4266E153D4E3EEEA3891B47F6E6C79BA9F4826F6F5C2C27AB5C72C27D4E22C2C315A675A638E564829013212B4FFB59A9E6A4879CFCF4937C39A96E36869C38D33A162A3E0F3901A09BB3D7ECB4D3309112B5A5649DC7528248897C8A6E3C3C49586B01F14452A47A9463569A536AA1C999161A2DE463F013AE3F3E8D7773A6992EDDF63E8DF338DE474EDC7232BE7739F122725225E464759A45F772C291933569662A819C00209E3CDD52628048C9742125C9752AD6942052E2175A3B1CB4AF2930D3381ED5A3484DDCAC34BBC84293B889DB416713B7FE62DE4E0837516CB57A07C175474E5E73C98982C809D79C4CED2127D9D959AAC849A5242766E90043ADD711C809002AD3D026A4A4D01852C2CDA992EA14444AE2E3BBA564D0A041B2A5E4CB2FBF5024257979B99012859CB9E7A0EFCF054FB444B6A4B89BB8D5586966BE85261FB2D0EA1C2B555EF47DB4A4273DE544695A87232553A73AE564FC78212759BDCBC9420FD33A154D36698BED0043C889C5E7A93B00820296925D46901231A6459928E9A86752A22452A2544AFE142941F33459E4B639D3217A1093A7D6A3881BD3EAD3760A3BEFA0B60E87EAF3A23BADE349E424FB61E464FCF8717DCAC9A39113F97D4E2A1A6DB432C51872B2F690EFEB8A000868DC5232CE00523255484942AD6735258894041ECDED0EDA19205B84D58EA2FCD068A7231E747AF5940A1F454EC60939C9CACCEC534E9E7FFE797AF3CD37959D4A2CE4648581E4A40C72028CC03903454AA64699295E48C98D76798B7BBC3FD3371327D08B424A468F1E0D2951C089BB0EDA184445AF9E8E0DE2FDFD2E46950F7A9728C19DD679EDB5D7A483FFC215EED6E99693716329B30F39E1B40E9FFFF426B7AFFF45BE9CF0CD7AB99093FE8690130BE404E89BF362910B293246A4644A94499292EBF7E485C1BBA5E4AF424A06F72D256BD77A2825B94E29790152E211E9579DD1124E7D682D0F6AA67536363928F68AFA299C2721C9C9AA55929C7CE2859C8C65393972A40F3959E89493B7DE1472F28BECD7293D2FE424D91872B24EC809478AB4980B00A80A4BC96E0348098F2991268AAB912F25093DA54446A464ADB79192975E7449096A4A94D078C741DB4EDAA4AEAABA8E980831D9D268A76C3FA6711EE7D1C8C9A78AE4A4675A67EC58F972F29690936DDBE4CB09EF5E5966183931434E80BE30969498252969532D52B2460A3D7B1A2991A4640C22259E50DE62A319A9169A74D84C738AADB4A4DE46AB553E59589B348E83422EDAE9D84DEDC484A9282FA7952B9DA7122B8D9C485B89BBE5640C1DC9C89027276FBF45DBB76D53242786899CA45B88772769392700F009469292C911268AF5404AFEFAD7BF4A529228434ABC49DF404ABC23AAD22AF5B2E04EA97C822F3725E3E66473CBACB4EC844DDA6EABB554F8225AB2A9C941091AA5711EA7BCAC8C962D5B4A2FBFF2B2534EC2E4CF7B8E9C4C9B3A5592933163C65046C6E1DEE564510F39D9AE4C4EA4C84900AC41AACAC95E13AD879C8060E7C20D2125C5C6909249424A62AAAD74EDAE675222277D83488976F05CE65D0A8F7FEFFD779B6868B8496AEF3E2DC742F32B6DB4E27410D7A034DB69EB051BE55DD3365AD293B2D2525AB264892427525A47A19C70E4A49F2427A329E3F061599193B7859CFCBA7DBBECD7E1537A972619474E2A212720183975E901ED3188944C08EBA4E84A0B5DBDAB70F70DD23741436183ADCF9D6403F69868789499C6A75A6846BE9516D6D868D5D9E08AA2F06E9C3DCD166A50A105BD373C2A279E454E584EB8B6EA705F72B26821BDF0C20B424EDEA65F7F952F2785DCE63FC9ACF97AA4F6182EE46403E404041BB5E76FD38EBC07343E4CFB8B48ED31FE40278516B453EB4D8B4752D25BFAE6D8B17AF2464A26404A7C4243EB2D0A2DB128AA23182416EF9107CD34F1908566155969719D8D569F0B70491152B2A9D146F12D5D013957FE143951B85BA75B4EC6F42D278B2439795E9293DF7EFD55F6EB1418494E0E9B89DBF56B3D2F00E893D3971ED06F391D34767F97E6178FDA6362B889420BDBE954F32D75D23788940404550DB76959B267738465860FC71B1567A6C919169A5B6AA5A5C76DB4E642004A8A10931FCF5B29BBF941C0CE17B79CBCF2CA2BF4D9679F5264A4B283FF1E9593F43ED33A1C3979E79DB7E9F7DF7E932F270D365A9C681439B15055736045D7007884A63FECB4BBD0641829E162C8B3AD777D5EE8FA48A4E4AB2F3D8E9470C11FA4C47B92ABEFD2A87DDECF692E9A1D1A66A23109669A9A65A17915565A7ECA466B9B02414A1CB451DC60F63599E8D4957B013D672439592AE4A4DF2BF4F9E79F51A48253897B464E468DEABDE371775AE745979CFCFEBB7C39396BA34509C690938D929C20720202109692D0122B8D0FD3FFC5C827AE460A29B97C47664D495C1C7DF7DD7792940C1E3CB84F2959E39292AF144A496E6E0EA4C4C79CB9789B7ECEECA0FE3B7D2BDB03769B68588489C62599697AAE851654DB68E5190DA328424ABE6FB4514263E0464B7AC272B2D425279F09398988F020AD237E77D4A89174A89733A21E919377DF512427798692133355434E4020E194120B4D30404D09BFC708F1A47B596671A0A79112A5528248893A949DB943B3631E88EF5EBD28E0C03D261A116DA60969169A5968A545476DB4EA9CCDEF62B25D88494E6360474B1EF96E1E8B9C289193EEB48EF8DD910AE564C78E1DF2AFCB33365A681439C91072D20239010140F34D07ED2BB51A464AC2CB2D7449AE94C4C5754B899A911248897A1C2CBF4B437777A92A26DD63978906ED33D1C858B3D4C46D76B19596D6DB68CD79752329520B7A31A22FD9E8DC1579F55281823B72D2CF83C80937619B36ADA79CA4C9929377DF7B9776EE942F27B92C27F1C691931AC809D092E69B76A794846B7F51F8434A22144A893B7D3384A52451BE94280A4B73FA66824B4AC6424A7CC9A5DB0EDA94EEFB348E9CD1B389DB94232A37711352B2B9D141472E07E70DA55B4E5EEDA75C4EB29D72C25197112347D0A1B4B4BE77EBB8E54441E424E7B4D53072B2097202B4A24592128B31A424DC4CE1E556D95212E7572919DF2D258721253EA5E6A29DA64476925FA225BD0CA91EC5D5C46D6AB68516545A69E5699B2414BEE95DE2A09D62D4B605EFCDC429274B1FCA89D2ADC46E3919319CD252539F2E27C58FC9C9CE9D0AE4C4460B0C90D619E192935AC809F02767AF74D2DE629321A464EC814EDA5D709FCE5EEAF04C4A7A4BDFD4BBA4E4AD37BD8B94207DE373AEDEBC4FD1155D34687760ED30939AB8459A687C8A9966E4B99AB835781E45E1737E3636D929BAD94CAD3782A7BEE449FC494E3C8D9CF425273D2227EFBDF71EEDDAB54BD6EB5CBAD14169B51D3447AA59D27E2EA92D271B0F9BA8FC5C6750CF2910241C6BBC4D3B73DB69DC814ECD27BFEA52B2BF9376E5B513BF67399F8D9248497D7D1DAD59B3DAAB48C94BFF7C09E91B95A83B7F8B56A7DC27ADA3254F1D5C8F12FA84266E4AEB5184986C3E6FA1D40BF2C43BD0F145E4A49F0239E107039693109972C22456DEA19991EDDACF2195C7B03D5DB426A583326BDA7431B74080D270E501ED2E78600829E1AEB5FB4BCD74E19A49B9940CE95D4AEA8E1EA5D5AB5739A5E4EBAF146F7594A404E91B55C93DD529E6B99F8A5EBD1C5C8FE26EE23629C34273143471935AD0B7D8E8F875B36EE6D12372F2D9A78AE4840B62A74F9BD62D27A92929B2E4E4FDF7859C8484C87A9DD6EB1D945071DB109193E1424E5625DDA3AC5AC80950818BB7EC74A0CC223516D37AB2FB434AF8BD5E9479ECBB9248C92352824849C012566EA5014178943DD7A3743771CBB4D0FCDE9AB8710BFA263B255DD15FE74E6F2227CEDD3AD3A4B4CEF0E14AE4E47DDABD7BB7ECD749AE6EA7F9862888EDA275A9F7A9F202D23AC087B40A29E185DA0835254E29B1528B2752222352B26AD54ACF22259012BF71FEBA9D56A506FF0D83EB51DC4DDCF8E463A9895BCF43058598FCD468A782003A49D897789FD69926B5BE1F3E6C18A52427F721278B9C72F22FF972D27CED1E659EB21A434EF674D1A60C13D5B5EA73AE013FE39612A3444AF67B21254989894FFDBDA3B5B59294BC21A4E46B4FD337424AC68E1D0B295119EED83966BFF6F3D19763E05E5713B7540BCD2C7036715B73CE46E1971DD47CCFA1DBF9C472B26CD9433951D449595C77D35D72324CC849725252EF72B2785177E4648F82C849E6291BCD8FD3BF9C8C0835D10F472C54DF8ADD3AC00B787B6CB851A4E400D79458A9F90F6552F2CC33AE48492FBB6F584A56BA22258AA5049112BF725DDCA4438A2C4199C69133FABB9AB88D8A35D3C23C2B1DBEA8FF27D8C7E54469E444919CB82227FFFAD7FBB477CF1EF97272D26A1839D9CC72720972023C809B4B855718434AC60929D9E78594F4152959B912919260E1CC35BB21CE37191062A2A52966AABBAC7F3161BC91137741EC2BAFBC4C43870E951D39F9D7BFFF457BF7CA979323276D34CF28729269A16306997BC047F03930929444683F89FD2325166AF2484A86F42A25B5B5355E49C9784889DF39229E5C79E1D47A5EAA3D86ED35D16FF9FAD9892307A79C2CF332ADC37222AEFBA4A75FF7C5C5C552E484AF5D9693D0BD7B15C8898122272C2797202740062C2511068A94F0E1834D37E44BC9B7DF7E2B49C9D0BEA4A4A68656AC5CE159FAE63129C19660FF70F98E83B6E55AA47487D67353CDD15F8CA991263A7CDC6AB879F548E4E4B34F95CBC9F41E72D2CBF5EF8E9CF035FC6F2972225F4E324E580D143931D371A475406F5CB9C352628C2DC12C257B8594342A9012B9E99B9AEA6A5AB162052225410617E5CD3AA8FF1BC240215E2B53CD74FAAA316F08BE29887D99862891930FFE4DFB424365BDCE8D76BB248D7363F53F17594EB6645AE838D23AE0495C114F8B91068B94289112B991926A2125CB572CF7484A38973D7EBC4B4AC62152E26F92EA6C34748FF6F353ED3152DC0CF6165B0C3DB7BC8E9CF4909344B5E4E484901383444EB6649AE904E404F4E4CA5DBB534A8C505312A62C52121B1B2B5F4AAAAA68F97221256F782A25E320251A71F19683366759A43487D67354CDC169AA59074DC45BA2B5FECCB5C65D73F2AA5B4EC2E4CB8954103B5DBE9C2CEE4EEB0839D987C8C993E5C4422774D8EC0F78C05596924A6348C958297D6355255252555529A46499E7E91B444A34A5A2D1469323B59FA36A8F8121265A77C82CBBAE4AEFFC494E14444EDC72F232CB491F2D037A464E3EF8E0DFB47FDF3E9972E2A0F4E336C3C8C956F170701272626C584AA284944C328894EC29B6D00595A464995B4ABEF99A2223233CAB29819468065F078342B49FA76A0F6E1CC7BD89B4FEBC03896E3979ED55C5911329AD3363BA242783070FA28484F83E2327FF94E4E4033AB07FBFACD7B92EC9897122275BB3CC424E10D13324D70C2825DC6A5CCE67F348FAA68F02B7CACA4A69516329F9E6DB6F282A32D2F3F4CDE1C3B818358065755DBAFED338DC348EDB9F975EC0A2FF38929C2CF7504E727368464F39898FEF752BF1E2C58B859CFC933EFC50C8C98103F2E4E49E830E1DB3D11C03C8C94857E4E4142227C6A24D4CF2E82AE348C96E0552A22452525951D12D25DFB29444299512444A0281C2069B5410ADF55C557B0C0E71B604E7DD775A7FE681C8A39193CF94CBC9CC19D2C17F2C27F1F171BDC84991534E5E1672F2D1871426534EDAEED9859C580D23273FB29C5CC55C35043CB90D2525451E464A6449C9527AF3AD37E9BBEFBEA5E8A8288F2225E3C68D83946808E7F0B9185AAF2DE87B8E0961268AAB411AA737BC49EBE4E5E6D2CC593325391934A82F39297E544E64BECE75B17EA719444E38ADF363B6854E434EF48DF1A4C4EA81943CD367FAA6A2BC9C962E5DE29492FEDF514C74B4E75282F48DA634B4396859B231D2388B13CD547B11699CBE603959EE615A272F2F9766CF9A45FDFAF513723290E2E26265C9C947424EE4BE0EAFE369F5424E0CD0736764B79C60DEEA12CE51C6541B434AB8C06F579185CE792225436448C992255247D7FEDE4A0922259A937DDA46A3757692F09306F767D99E67ECDE254AF026AD939F97D72D2703FB9293A2A21E72F21185CB3CC387E52455C8C96C03C9C919444EF40587AB0F1A454A0E082929B450439BEF0B5DCBCBCA68895844DE7CF34D1AD0BF3FA424C8B97AD741BF17E83F8DC3D1A0299126A93E41EBCF3C98783C72121626AF1684613999337BB6B40D79E0C00114171B2BABE6E4A38F3F927DC0E035212729424E8CD0AD98E5E42796936B90135D70F1FA038AADB1D2E408FD4FDED1FB3A6967A1591529E1458A0FE6E242D7010306D0C19818F952929D4DE38494FC1352125070BF04239C49C2E2B53C055B303DC15B39993B678ED45D76C080FE141B7BB0F7B4CE921E721221AFE500EFAE4CA9B34A4DF3B49E679013208B86D65B145E72DF3052F24B663B9DBE22EFC4D49EE99B614387F629250B172D943ABA0E104F3F070F2A9792975E7A91468F198DB36F0288B463361ABE57FBB9ABF618B1CF5904AEF5E71DACF494934F15CA49417E3ECD9DFB504E7A5B3B4A7AC8C9C7424E2215CB89FED779B79C9CBD06C90E4A2EDDE8A40345ED3431AC4BF3C9A4F6E09A925FB2EE5355C36D9F17BA96B2942C5C28454A060E1C281696838AA484D3372FBEF8028D1C3982D2D25271310508ADB71DD202678434CECC1833E59CC642EE0D5E454E584EE6CD95D23AFD594E7A89B64A699D6E39F958760B02969364969318A3C889991A2027C1474CA5594849A7E693C81F52B2B3D042B58DED3E4FDF949694D082050B242919347850AFA1D8C7912225E39C523262C4704A4D49C1451440D4B4D8695AB4F6F357EDC12709AF4933D3059985E0E0E97823270505F9346FDE3CE977B968BE37392971EDD6E1866D1F7FC27222AF1501D74C25D719E3846C96939FB3E5D7128200204EAA29D17EF2F8434A761458E8ACE29A92BED3376E2979FD8DD7A58649BD55D63F0EA424F0E1BAAB21BBB59FC36A0FDE7174A00C45AFBEC22927CB1FA675643647630A0B0A68FE82F9F49AF85DA9CD401F72B26489534E3E512427764AAAB34A5132ADE79E5FE424C742E72027814FBCC1A4E48CCC709E92F44D4949312D983F9FDE704B49AC0229C979544A52529271D10418CD7FD869538631D2387CBE4AC97984BC7DC99F22270AE584D796D75E7F4D969C2CEE96934F283A5A9E9C7067DFC4A32C27DACF41C809F80BE718A745693F59D41EFC14F87BBE6752D257A48473BCF3E6CD9522257C62687C5C9CE24257444A029B6271A31E1FAEFD3C567BF049C21B0F5BE8F26D2CDABEC6ABC84961012D5CB8805E77C949742F6D071E91934F3F91DDA2C04872326A9F897ECDB3C83E351EF891C27336A9B3A3DE9F029D526295DDA6B8674D094B49725252AFCD8EE6CE1552F2BA9092A14328BE97C3B81EC799BE19EB94929123202501CC8172AB74D3D67A2EAB3DF8FC9F835548E3A8C59F76EB289093A2C242A9A85E8A9C7CF75DAF475A14F748EB7C2AE4446EAB02969304212733A2F59FD6E11E5DD15516E296FD5ACF0BE0A2AAC9461BC493D1309D6F7D6429F92D4FFED9094A2225BC50CC99335B9292A1E2679548099F91311E9192A0E0FC7507AD4AB3507F9D0B3C3FA02C4A30534D0BD2386AE20B39E135E7DBEFBEEDB58EA4B847E4845F47AE9C70B42CA156FF7232483C68CC8B3349DD70B59E134050DF7C9F7ECAEA920E3CD27A72A839468676D18F473AA8EA9CD2DD37CFF41929E1BCEFECD9B3A4D0EAB061432921214191944C98309E5E7CE945444A8280C3C71E48DD81B59ECF6A8FC1BBBB6873C6036ABE26EF7A019EE3AD9C70E3464E1D7FD3C709E5258F474E64B62E387BA99D224A3B686A84BE77690EDE6DA225895D947DE201DDB8D58179AF25316577C5847BA0F9A450574A3A696B4607959F91DFA7E49B6FBEE94EDF242525F62A25B366CD9242AAC3860FA34485523271C204A9791AF729494D85940432675A6ED1B6AC761AB84BEFBD7DBAA45601D16590127FE14DCD89FBBC1C6EE028C949A44C3911AF132B534E4E36DDA20385776972584700CC4FF5C628F100FB736607D55F9077AF002A5079A193D6A5754A4F475A4F08B5C6E87D26DA9E6BA6E3ADF23BBAF69492DE2225DC5B60D6AC9992940C1752D25BAAE7712025C1C7F156132D88EBA2FE3BF57BBDF01820C46B699289EA5AE45D33C037B09CAC58B15CDA0EAC584E24E158E29413B17E45F629274B5C9113212732770D9EBF725FC8C91D9AA2E307599EFBB3623A29F56827E6BE5670EE7072A4F693415529C9B3109F6922E7F3F8534D492F91126E153DD3252523860F879418808C9336697BA1D6F35AED313CD47990A5D69FB711E14ED14B972DA57EFD5EF1504E1E464EFA961367E4844F3F96DB67E944131F53D241D375DC5C90AFF16DB9163AD1721FD780BF397BCD4E5B322D525E4DEB89A0C6E02D603CB9E44A09D7857075BB9C48091FAE3563C67429ECCAC5AABDFDECE3404A8293CB77EC92E4EA7DD71AF72E991E6DA6AC532802D40A6ECEC8118D7EFDFA299613168EA54B974A27984B91935ECECB792472225E272646DE5662AE39E10683D3745A10CBD73817C21EAE439D89DFC93D63D3EDC9A84E2931D30905A7A16EDBB68DDE7DF75D69474D6FA2C16231BD5B4A462896122E748594041FF597EC34FBA059BA716B3DBFD55E9457A572C329ECC6D19247E4E4D34FE9C081FDF2E544FCEEB2654BA5A330BEFEFAEB5E4F1A76CBC9FBEFBF2FFDA7DCD7B874DB4EB1D5FAED7BC55BE543F2EFD3E9E65BB80EFCC58D760745545869AC0E7717B094FCC261B8CBCAF6A357565450626202F181594FFB19494AA6BBA4448845723222254681DB74EB7D3BBDFBFAD9578A684920E09606CFE4A458C8C932297222C94978F8537FB7A6BA5AEA30CD6B9492BF4F92138E9C44E9EF0177D81E13AD4B7B4015675104EB372EDF71489DEE06EBAC49D448B1A8FE2CA4E4B842299143757595D4D1956B4A468D1AA9A8553C2225C14DCB4D3B6DCE34461A674EAC998ACE215A1228FC29ADA3E0E03FFE5DDEE9F3D6DB6F4907FFA524FBFE780B969383D5FA9313BED6E7C73EA0BCE377702DF88B73D79D677D68FDE5FB724891921C75A484A9282FA7C58B16D18C19338494C8170B4849F053DE6833C4F951BC18AF4FB7D0C55BE87E1948B0602C75C9C9679F7F46E111E1F2E5A4B494D6AF5F4F93264D92BD355829ADB79C723255671B29A64576525AED5D5C0BFEE268AB9D56A6EAC770DD07311DBFA4EE825A5E56462C28B23FE7DA5A5AB468A1B4FD6FD4E851424A5231C98390A84AAB6E8BC47B8EB1FB4DC4EF55EBCF1BFC995257DD08A766860C1942191919B2BFA763F5F5C4BD4ED4FCFB584EA2AB584EF4735FE15E3EDCE7EBC61D6C1DF60B65E2097049923E26104BC94FD9163A762930C3CF3B77EEA075EBD62A5A4840E0D078C341EB0EE9FF0C296EB1BF20DE4C95CD81791D0167D476FBF66DB471E3062A2C2C0CB8EFA95B4E7452103BFE40271D286EA72B3721267EA1E0AC4D5A84B4FEE2F52E2520F8E16B659C0E8BC41F1F1C11FA318B0F3173E05A021EC369C0E84A2B4DD1415A67ECFE2EDA9DDF4E176F74E19AF0079927ADD2D647ADBF78AF8D36CC24ED2E6AC389904005AEB73B28B4C42A1DF0A5F55C577B4C0C3753521D041F784FC159AB78F0D57E4E7B3B46EFEBA2DFB2DBA9F11AC4C42FE48BA7C0F93A8898F053DED22433E59CC6820A7C4F439B9D96279B0D719230A7768FA95CA305F40FD7F9FD9C6DD14587648E9884E4B553CB7588895FA86EB1490BAED65FBC2FC6903D265A26DE4BCE19C809F02D59A76C347ABFF6735CEDC13D1B7ECF470B7AE01DC72FDBA44D08BC4352EB39ED8B3121AC93224BEF51DB6DD498F88533D7ECB43E5D1F62E29693A5424E7203584E5253522874EF5EE29D3A5AFF2DA06FAEDE75D08E422B0DD4791A877B9770F7CE2327B11B2790E1B3B8F6EFDB17B0DF1137B4D49394F09812D14929D5F702F633D71D5C3DCDDD51F5943B77474E02514EEA8E1E951A1D7DF8E10752B3A4EAAAAA80FB1BC1A39CBC6AA7F909C66841CFAD031AAE218D13A88484ECA22FBEF8426AEC9895951970DFD3892BCEFB899EA484AF8BB9073B29E718FA98F80D6E491F5969A57161DA4F0035E424EFAC7A72525B53436BD6AC915AD3C7C5C5C97E1D3E20EBCB2FBFA07EAFBC428B172F22EE24ABF53C004F27F5989546E8204FDED7E06EC9A12548E3042ABB4342E803F140C3E7DE6CDAB451F6F7C4DB8957AE5C4953264F56749E97522429D159A484075AD26B041FE13EEBA0F61320D8E484A31D3367CDA4E7FEF69C108D2F29262646F6EB848785D17FFEF339BDF2CACB521759C84960C211C59FC4623B50E745AF1C0D9A75D04C050D81176504CE48C9071F7C40AFBFF1BAF43054577754D6F7545050403367CEA4BFFDFD6F62BDF90F252624A8F2FD72FA468F52C263CC7E13FD967B9F4E34E1103FBF52D56C976EE05A4F0075E5449DBC795A6A2A0D1F319CFEFAD7BFD2575F7D450715B47AE6B32E7ACA091FA0A5F55C008F52D362A719D1C648E3AC3D64213E0B48EBCF1C3C8A1429612979FD352125AB654B49A1909259424A9E7DEE597AFF5FEFD38E1D3B54F96E4FEA584A784C8A305174D97D5C17FE860FF2E35344C7EA74D781A791133E6178C68CE9B465CBE65E7F8FDBCB8F60397946C8C9D72C279E474E202781051FE73E748FF67358EDC14F85DC0748EBCF1B3C4AB79470A464ADFC48895B4A389ACB52F2FBEFBFF7FA7B9C5E9E2ED6BA9F7EFA51D949ECE7DA755753D273F0B5CF9B43CA1A20269A507ADE468B13F5193579444E1414C466661EA1E1C386D1BBEFBD4BEBD7AFEBF5F7D27ACAC9575F293A240B72129834DF74D0C6C30668412FC6BC38335534225A124838A5E4DF52A464AD0229E1F4CDAC59B3E8B9E79E931529898C8CA0AFBFF95A2AC8E76333E4FE7DA567EED0E68CFBBA95121E13C34DD2A184AD371EE0DAD082CBB7ED145666D15D11EC13E54441E4E4604C8C744CB8534ED6F7193919EE9293AFBF1672120B3909668A85AC4F08D7AFACBB076F83FEFE8885DAD0823E60E829258AD3372C25EE48C98EDF6549C9FBEFBF47DF7FBF49F6F75FDF6AA6CD873B68646897E6F357AD316CAF89366598E9582BEAAE34E5E4153B6DCDB2485F88D693424D39E18672F90AE484C39C0FE5447EE4047212DC84955B6988014E12E6E31CE26B90C609141E9192B56BA8BEAE4E9E94143AA5446E4D494F29F9E187EF657FFF27A52DC1665D4B09B7CF58986042B3CE4081BF88B971FA7E4A74474E94C84977E4E4DD77FC22272FBFFC4F5AB46821E44423CE5FB7D3AA5463A471162598A9EE2216E040E0F1F44D7DBD022999FD3052D2979444782125DB745C53E21E7C58E7FE320B5DB983F46640C05F44648545CAAD693D39FC22270AB6472A9793114E39110B405C6CAC7C3909879C680D9FB934C6002709734468BB78FAD5FAF306CE2DC1FFFEB77229292A2CA4D90AA4448A94880726A55272CA20523262AF89B6649A89DBEA6B3D27400FCEB5D9E9D73C7D1CBED4979C2C4F51D6BBC1133979E6D9679C7212A7404E1039D10CAEB50829D25737E4A78DC991263A741C4DD5B48623252C25AF79202573E6CC96FA94FCEB5FFF524D4A4E5FB5D3F63CFD4B091F06BB3CC54225E72125014979A38DD6A499759F63F7464EDE91232769424E463A2327DF2895138E9C7C0E39F1377C7E14EF50D3FB49C2FCFE386AC8371DAD3F7323E394927F792C254A22255F7912293188947013456E349A78D44A373A704D042C85E266CD7976C8C99FE15E2572E5E4505ADA2372121F2FBF7D7D44783822277E26FDB8556ACFAEF5BC547B0C0F35D19E62444BB4C4632929622999A3BA94182552C2523233C644B13556BA8CBA92C087E564458A890687E8B702FB7139B9FA87BC532415474E5C05B1DF7EFB8D7239E91939A9819CA805371BE48558EF2709F398116DA2DCD3D88DA3159E4A49715111CD99AB5C4ADE7BEF5DC552F2AB41A464869092839092E022A5EA16CD8FB94783423A359F446ACBC9B2A42E4AAEBCA94AE4C42927AEC809CB49423C22270146594307CD8CEEA2FE3BF52DE2FCFE96273EA0E3CD38CA5D0B7C25253B5592929A0B1DF4735697EEA564C0AE2E9A12D149FB8B3BE84C2BAE85A0E360D1555A20C989BE17ECC1BBBB8484DDA5D8A22BB22729777995E4E49DB7E5A5755C72C2919384788572F2F9E7F4CF7FBE448B162272A2061125F768D81E9EE37A9EE75D34626F27EDCA6BC7FCD10096122E547DEDB55725293976AC5EB694CC1552C285AEB223255F7DA9584ACACFDCA12D19FA6E9EE69412932425FB0ADBE964334E0E0E4A1A5AAE53FAD176A939D9609DD79C0C0EE9A40507DB29FB84FC36C4929C7CA7A0E6A45B4EBEA50405277EB29C7CFEF9674E39415AC7A75C6833D3F7195D347097BE17648E96CC3E68A2A2B3D826EC6FBC919279F3E6AA2E25C75B4DF473769721A4645A9489A22ACDD4F207EAAC829A2B7FDC97DAB94B72A2F31C3C474E56A498A94841412CCBC977DF298B9C3CF3CC33F41DCB8982C8096F25FEF4D34FBB2327B53535B8B07C4079939DA644E9BBB9A07B51DE906EA6AB77D182DE9F38A5E47DC55252525C4CF3E63E9492BECEB3F1544A7837DAAFF9FAAF29E1F93F9DA5A4CA42ADB7B02D5837F04178BCCD50EF7D1EB8E644929373CAE484D33A6F0B3959B76EADACDD3A2C271C39495410390973C9C94B2FBD440B172E809CF880A84AABF49D6B3DEFD41E7C1ED6C12A3C25FA13AFA464DE3CFABBAB4FC9CE9D3BFB94922FBD9092D13A3D61BEA7944C130F1F7CADB7DE42A1ABEEC81572B234C91872B2DC0339E1C889534EFA889C1C72C9C9B3424EBE137292E8899CBC0839F1920B37ECB4EE90315AD02F4830534D0B9E14FD855B4A5E6529110F2BB2D3372E29F99B3FA4C400BB6FF8DA9E1A65A2484889BE31929CAC483553B1826E809ECA09FF4E6262A24239F9449213A4753C878F2618678016F49C82FD391BB525FEE211295112292929A1F9F3FD2325BF19247D3335524849054B095298BA27E7B4D53872A2347212CB72F2AD2C39493F74A83BADF35DFFEF282949A99C2072E229D7DB1DB4B7C4A2FBA26E1E93224C945A8FDE25FEE0F14889DCDF93A464C17CD5A5E4AC51A4448C29424A22CA2D74F126222586810F3C5B6220395114398975454EDE7E4BB69CF06E1D494E14474E20279E70B6CD2ED54C19218DC30F117C42ACD69FB9DE6129E12EAB4AA5A4548A94CCA7BFFFFDEF8AA4E45D21259B37FF205F4ADA1CF45B8155F752C2C72E4852526185941891ECD3565A9268D67DC74C9693954AD33AEEC8890C39E999D6E9DFBF3F252725414E5426F3944DF7457F3C86ED35D1AE4214BDAA8D534A1EA66FE4FE1E4BC982051E48C9BBEF288A9434B823253A9FF36E29092FB7520BA4C4B8B09C2C36889C288D9CC4C5C6CA9693EEB48E077212DEA3E64492935AC8496FF096D91D05161A6480340E6F91CC3A85348E9A3C1229512A251C29F9870229F9F20BC55272F69ACD10E91B8E0E4E8E305158B9055202849C88A74F23C98992E3B1DD72F29624276B65CBC980010AE5243C9C3EF9E4137AF145444EFAE2D4153B2D8837C049C262F0819C17AE6391560B6FD2370B172CE896925D32A4E40B9794284ADF18A4A6A45B4ACA3852824257E0224BC8C92223C88978CA5E29E4A4D46339911F3919306000A524272B4AEB38E5E405444E7A21A5DE4A2343B59F4BEA0E6727CF036548E3A845B794BCDACF2B29512B52D2D066A7DF0B8C21255CE07DA00CE91BF0048E9CB44AFD1206EAFC49D47B39911F39193850999C3C8C9C404E9E44CB4D2BFD946DD17DD1368BC98CE84E453BCA807C584ADE7BCF25250AD23765A5A5D216FF7FB82325BB76A912296968B349E94AA348C97E2125CD9012F03432859C2C8C37809CB8D23AA517549293F4472327A929291EC90917D61DADADC505EBA2AAC942D3A39D0B9AD67348DD05BB8B56263FA0CBB711D6F6354E2979579292BEAEE39E4852B26891FA5272CD589192FDA5424AFE8094803E3872D226E5F08D2027BC5BC7233979EB4D45723270D0408FE58423279013B1605FB945FB6ACC344CE70B36474BC6EC739EA0AAF567AE37F6ECDEDD2D254AD237E56565B498A5E4F97FC8949248494ADE512825E7DAEC8689944C1452B2AFD4022901F2C9E0B44EBCFEFB44782C27DFCA9393C3E9E93DD23A9ECB0922277FF9CBD1CB7769EB2921CD15569A7C58084A84F6F3472D31991D7D9F724FDC31F4F7ED6BDC91927E0A232592942C962F255151911E454A0C2525E12C258894000FC83869A3F971069093DD4E392953222771CEC8C99B0AE564908772F2C20B90939C8B1DF47D938DD65CB0D3CA33365A526FA53925561A2FBEBB213A6A4D3F30A48B361CEAA073ADB70CFB5DFB9ADDBBBD9012297D23375212415F7CF11FC59192F3D71DB4B3D000CDD35C52122AAEDB264809F094C3C7AD342FCE640839E1AD99E58DF2E5243E2E4E8A9CC89593913D222769A9A9B25F27A25B4E9E37AC9C9CB97A9742CF891B76B39DD6B9C6DA263BAD3E6FA315A76DB4F8A88D661658690C77330EF2C59D17EEA8D27B86FB8ED5822325EFBEEB819494BB2225B2A52492FEC352F2CEDB9092A78CF1626EF351129012E01537DAEDE4941363444E584E2A14CAC9B7DF7EA33C72326890C772C23527F5757586BAB08F5E6DA72D0D165A2F84647D8B431AEB9A1D0F25A55148CA391B2D3F65A38535569A9663A151B162CEEED17E5E297DA2E49E4225A791C6F1055C53224949BF571449494579B96229F9C22329B14B9D7DF52E253CAF278439A5A4F106A404F8801B1D0E4A3F61A3B971FA6F6AD52D274DF22F1E6FE4E4505A9A4239F9586AC2C68BA691E4E4F0C507B4A9C92649885B4C7A8E753D232942525635D86819A722ABAC3425D34AC3A3C4F71B047377A810A9DFF3D1BBC417382325EF288E94B0942C59B25851A1AB279192FAA67BB4AB48FF9112969271FBBB28A4D0042901BE852327878E5B69AE780AD5FB564D9693D5424E2A9B3C889CBCF946DF7272B8879C0C5628271111CE82D8978C2327178518EF6A304B699C2749496F92B24648CACAB3365A7A5C8875B99526A65B6848B8F673EC6963AA1028EE27A4F5671EEC744B890791929E521222A3A6C41329A93D7F9BB66777E85E4A788CDDDF49BF8AF77AFA5227E635F03D2C27E9424EE6C4EABF8F8424276966AA6A56494E5C9193679F7B96060F1EAC584E3EE6C88924278B752F270DED0EDA72E1E9D1123992C2F528DD45B375369A556CA571C9661A1C4087A2F135C5BD75CEB5A1A99A37782C2515E5B474E9127A5EA694F0EE1B4FA4E45C9B459212EEECABF59C537B8C0F33D1EFB90FE8A81031ADE705D0312C2769C7AC34FBA031E4648D9093EA16E572F286ACC8C961A79C3CCB723288B863ACDCD7E98E9CB8D23AC7EAEB757BE1675C75D026976028159327D6A3B88B66F918865A2B4DCFB7D0E878130DDCABED7C1B11EADC42A9F5E71DCCF0EE9B77DF79875E512825951515B46CE9D2875222E4A6B79F97D237FFF95CB194F0F6D8DD45164348C9D803260A29B4D0C9D60798D3407DAE1B504E6A5A94D79CB09CF4D5EE3A43C8C9C89123A5B48E143939E441E4E4C517742B274DED0EDA71C12E3B8DA334D523D5A3B88B66ABAD3435DB422362C477AF41CBFB9931662A6C40B4C453B8D0F59D7794474A584A96F69492BED2375191F4B99092B785946CD9B259BE94DCB44BC59F8648DF0829E1A2DE0BA82901FE84E524B5DE4AB3628C21276B0F99A9F6A23A91930C77E484D33A4306537A7A3AE4C4C5897B0EDAEC65B444493D8A54347BC246F32BAD34E9B0C56F4DDCF81A62016EBD8516F49EE09612A591920A9692654E2979FF5FEFCB4BDFB8A44449A4840FA70B358A948499859458E93C4EC5065A70FD9E534EF849CF28727254819C24C4C77B2127F2D33A912C271F7F4C2FE84C4E6E743A28E9B2DD95C6F1BD94F45934CBF528C76C34A7D446E3532DAA36711BB3DF449195D88DE3094E29795B79FAA6B2D229252F3C2FBBA6448A94BCFD962229B92864935374869012718DEC2CB4404A80B65C6F7774CB89D617853FE4645DBA99EA5AE55F74DD72F2C6EBB4766DDF72E26EC23664E8103AAC2072A247396914736BFB05FB23BD4BFC351E2F9A959AB871D1AC78121C9B60A641A1BE9D5BBCDBAD42C12E30E0846B4A3C959265CB973D94923E6A4A3C9712BB741E8C21A4643FA40404101C3949A9B3D28C18ED2F0E7FC8C97A2127F59794C9C937DF7C43AF4B72D277CD893B72C272A224ADC30579929CBCF082740A6AB0CB49B558D4398DA38598F45D346BA3E9B9E28673D04403767B37A7B871E1A62316E27E415A7FE6C104474ADE7E5BB99454F9514AF61B444A38E2C7E7FC6047190828AEDF735032CB49B4F61789DA839B606D386CA66397D59593EEC889F877B9AFD3534E82397272F5BE83A29A6DB4514329915334CB4DDC1654D9684AA68586477A369F784B65422D76E3284192120F2225555595B47CC572D5A5E4D26D3B1D28B3D0E800DA8EAEBA94205202029173AD7728ACF0364D3AD0A1F9C5E20F395993D6453947AF299493AF5D72D2475A2723A35B4E864A72A23C72C28BAF143939167C725277AD837E3C67D5345AE249D1EC3C6EE27648C9A1825D34EFE0032A3DD31E74DF91563823256FD12BAFBC4CEBD6AF53574A3EFF4CB1949C69BD477B0AEF1B424A46EDEBA29F8E7450ED791CA1000298FAB357684FF6359A68003919B2A78B96C5DFA12355ADAA444E8E0839E1ADC49CD6193A6C286564288F9C38E56461D0C94946B3F32461B576E3A8578F62EB3EF978B6BB89DB5343F95D3438A493B6647404D577A3255C53D22D250A23252B5C52C2BB6F76CB9092CF8494BC255E4BC996E093CDB72824BF9D4619A04F09BFC71F85945437A0791A08024E35FD4131E5F7695A94F6178FEA72226E2CAB92DAA9AEA5CBB3C8491F8BEB1157E484E564989013FE77B9AFF3B89C683D2FE4D27CD74AA18D369FF62EF17F3D8AADFBE4E345476D3423CF4AA3E3CD8F3571EBA2C911264A3F86DD387270474A5E562825D55555424A564807604A5B8265464ADE525A5372D34C074A4D347A9F01A444C8F6AF79163A7B0D3525208868B9DE498947ADC69093DD5DB429C342A7AF2AAD391172F2FA6B3223276E3919E6859C2C0A8A45E45CBB837E6CD4B6E8D557691E673D8A4D3AF97885EBE4E3A959161A116DA2FE21265A966C168B3B72F37DC152F2965B4A14A46F584A564A52F28294BE911D2979EB4D4591922B77EC14596195EA2DB45E8FFC2225F9566A404D090846DAEED90D23275C73C23B2B94C849624282723979F619C572121515E59493E78323729275CD41DFABD8544D6B49719F7CBCF4A88DC24F6371EF0B494A8428B094AC572825AB56AE94A4E4FDF7DFA7DDE2FFA7B79FF7544AAEDD755074A571A4647B9E851ADA306F411063243919B6D7443F1C51F604EC9693D724399199D679F6591AEE819C7CF4D1475287CB409693960E07855C70D0063F3454D35A52365DB0D3E1CBD822DC1B3DA54449FAA6A6BAFAA194C84CDFB8A54449FA86A524A6CA2A3516D37AFD517B8C7449C9594809D0032C27BC1D72AA41E46473A65951EEF55139911F396139C93C7244B19CFC2380E5E49C1093AD4D0EBF747AD5740831D9D162A76337B1C83F8D47A44449A4A4BA8A56AD5AE9AC2991152989A2CF3EFB5471A4A4ED9E830E565B699C01A4049112A04BDAEEBAE4C4C35E0FC13486BBE4E49C828B58919C1C71474E849C0C1F46599999BA9193B42BFE6B41AF9D9488D164A77805693FA3C152F2E69B6FD04B2FBDD4E7F5D093879112B95212E9919470C7EBD86A63444A202540D7489193A3C6899C6CC9322B6A3AD42D27AFBDDAE762CC9192913A93133E49F8378D5AD0FB5B4C360B31C982983C918752F222AD59BD5AF667545B53A3305212499F0A29E1D752222537C43C8DAB41A40400DD70CD6072B255C8C9058572F2F5D7F2E5A4BBE664F8F0A09793FA3B0EDAD2620C31D97BD941E7EFA1BEE471BC9112FE792585AE9E4809135F6B95BAF56ABDBEA83DB8A6645B2E6A4A80413052E484D33A3F669BA9F186C2C88990935715444EB843ECF011CAE424DA25277FFFC7DF359793B6070E8ABD680FA816F4EAA5711C94700552F2388F48C91A6552B27AF52AF952121D459F7EFA89C752320E5202803E315241AC5B4E9AFE907F91272526D2D75F7F255B4EDCEDEB470839C9CECA922F27D1D1DD72B270E102CD16A10BED0EDA669034CE8F4D76CA47EF92476029E113B85F1452B2768DFC9A92EE48C98BF2A424DA0B29E1DD85468894207D030C8D5B4EA618A020768490939F722CD4A2601746626282877232C26339D12A725276D3419B0D92C609BB62A72B0F103171B367CF6E7AF38D372429F1287DE30729E1034A8D22251C2981940043E34CEBD8686AA459F38BD21F72F28B4239E98E9CBCDA4F7ECDC973CF4AE99D9C9CECA090932B0F8822C44D7BA39E77E2B8A46443A3839291C6E9C69B4809FFFC8B2E29D923434A3E8194F43A46869A683BA4040027DC0FC04891939FB3CD74F1964A729299F9A89C642B93930F3FFAD0EF699DF31D443F07710B7A2562B24DBCC732B4F296E89692173D931277A464CF9E3DBD4B4914A4A44F2941A404803FC372126F1039192E454ECCD47A5BB99CF4531039E1B4CEC8512329372747999C7CE892133F454EF2C462F883DED338CDCE71F01AA2254C4F295194BEA9AD953A24CB961257A4845F4BA994A4D65B687CB8F6EB05A404000DB976D74EF135C690138E9C70D8F4CA1DF9372A257292E58A9C4872327224E57820277FFBFBDF548F9C5CEC70D0DE467BD09D24AC5C4CECB449BCCF43E85DF297BD42265E97A4E405459192BAA34769DDBA757E919243C76C34C14091121C2409402F70CD89512227929CE4B19C28889C243D9493356B14C809474E727365BF4E4C4C8C5FE4845BD0FF689016F4BFB7D8E9A8C15BD073A4840FAD6429E96BFEF6A4A794BCF7FE7BF2A4E4938F3D9292F4E3369A186EA6FE01B046A82D25BF404A0090C735494E6C424E0C50101B6AA25F859C5CBDAB4C4EBEFA4A59E4846B4E468D1E45797979011539397C854F12D6B998B87A9718BD05BD14291152F2820752B27EFD7A29ED233B52E2A1941C3E6E155262D2BF9484424A00504C77CD4984F617B13FE4E4B77C0BB5DD959FD6494E4AA2AF594EFABDD267332A9693911ECA899A9193E67607EDBC608C34CEF78D763A72C5B8370177A4E4050FD2379294BCF4A2EC48C9C72E29D9BA758BA2CF3BE384CD38529283E6690078C4350315C476CB898236E52C275F7DF525BD22C9491F9193AC87691D96937C0FE4E4B9BF3DE75339392DC4646B0B1FD8A77F310969B5D31905C5CE7A82FB94BCE6A1946CD8E09292F7944989D248C99193424A22F49FBE19BEB7937ECA36414A00F0062E888DABB1D06403C809E77C771458880F0993FBF938E5E42B979CF41139C9CAF2899C2CF0819CDCE8244ABC648C93843718B8053DA76FF8DC27CF2225EBA45A142552C25119A59192A4EABB424AF41F296129F921BD83EA5B1E18722E02E0539C726235869C849A686781D50339F952B19C8C1E339AF2F3F335899C348AF7B7DD102DE8EDB4A5D14EB906AC2FE99692179E572425F57575B471E306F991929868CFA5A4EA1E4D08EBD2BD94704476CB91075479F6B6E1E62100AAD12D2706A8396139F12C7222E4E49597FB4CEB64F7909331424E0A14C8C94121271F7CF081534E16782E2735863949D84EFB2FDBE9D27D63454C4243F74A52F2BC2752B26183B29A928F3F92A44469FA26EB9495261CE8348494FC9C6BA1632D9D869A8300F8059693584EEB18404EF8CC8A1D85CAE4242539599293972539592D5F4EC68EA18202F972121F17E78C9C3CF79C474DD8AE889B74548B314E12DED064A7248315BD1E38B0BFBBCD3CD788C8FD3D67A464A374BA304BC9DEBD7BFB94928F5C52A23452C2523249AA29E9D2FC5A575B4AF88CAE33D76C869A8300F8152E888D3548E464940735272C275F7A202763859C141614C87E9DB8D858FAF0830FA46D9987D3D3152D7AE7C5FBF9C510691C07FD2CC4A4D84085869515153473E64CA9A68477D3C8FDBD63F5F5B4699390927FBEE49412199112EFA544FB6BDC3F52629CF90780665CBBEB902227930C20270FD33AF217176F22278585F2E5A4B4A444B194304537F82461E78D5B737950594CA20CD8829EE745FAA143CAA464E3C6EEF44D5F9192183E70524809A78A944A49F6699BB46E18414A7EE62DC1889400E03F9C691D63444E9C726256B4C04891932FE5C9091FF4D73372525458A8DA62D67ADF41FB9B8C91C6D9D8E8A05483EEC691CBB163AE488992F4CD471F7A2625A79CEB8551A4E4CC554809007EC72D2786889CEC33D1CE428B6772F2F23F65474E9E55594EA416F48D46E85DE2A0EDE23FABFF80983C8D9E52F2EE7BEFF61D298989F6584A724EDB8C252548DF00A01DCEB40EE4E46938E5E40BFAA70C39E98E9C3CF3571A3B6E2C1515F95E4E32C582F943B3BEC5649DEBFDC5B6414A7AE3FBEF3749E91BFF4889416A4AB22125000404672FDEA1BDF9B769DCFEFB9A2F0EEA2F3E5DB42DFB3ED59DB928BFE62445A19C8C70A5757C2C27C7AFDEA3DF1BCCB4BE49BF52E216934D8D364A6C4223ABA7A1544A3EF4504A526BDB6962B8FEFB940CDFD3499B0E755065C31DCC39000285A3A72FD38ECCEB0690932E1AB1B78B36A7DDA4EA134DB217A1D49414E59113979C141715F964B1ABB97297B6345A751D2D71A671ECF46BA385CA2FDEC34DE209FCF0C3F7D2EE1B9692D0D0505952F2EAABFD144B4972F55D9A10F640F75B82DD525281E66900041EA79B6F524469A7741097D68B85EA9193BD9DF4F3917BD476477E6A4792932F94CBC9C48913A8A2BCDCAB45EFFA031B255DB2D2F73A6F412FA5719AEC14770585874FE2C7AD5BBBA5446EA4C41329C93ECDBBF6BA742F259CBEF931DB42A70DD8591880A0E1E28D2E3A586D35809C74D1C8D02EDA55A4ACE6C41D39E19B835C39F9E0C30F88DBD17BF3BD347638E83703F42E6131D92CC4241B378A3FC105D593264D72454AFA96129E779E4849EE191B4D8934464DC98FA829012038E0266C312C270628881D2516A7108505B12C275F7C214F4ECA4A4B293E3EDEEB85AFFEAE83B65ED4BF98F06E9CD04B766ABE879BC593C8CBCBA3E4E46448899763F85E57A404520240F0C05B8963AA2D06889C383BC4EE2E564F4EBCFE2E1E3828B6D5419B749CC2E91E8D768ABF8C9B85A7782325F9676D3435CA1852B21552024070C272628CB48E89460B39D9A3544E52594EFEA3BA9C5C6877D03603A47178FCD464A74203B5A0F7255E4949838DA619444A7ECCE2E669986300042DDCE7E460B54DC88959F345457539D92FE4A444999CA4A5A63AE5E4A51769F5EA55AA2C7665370D7292B0181157D1BBC413DC52D2AFDF2BF4E38F5B157D8685424AA6471B444A505302803E603989A93246E4648C9093502FE4C4D79193EBED0E8AAAB7D19C3C2B2DAEB3D15A1DF730D9D0E8A014B4A057CCC18331DD52A234525270165202000852AEDEB55374958526404E9E08CBC9C0810368CC983154A0E094E1BE3877DD4EAB0F5968B0585807859A6854AC99660849597ADC2A6DABD55A267C39B635DBA9E206C44409EE03FC3EFEF863444A7A91922D59D8120C802E319A9CEC2B552627F57575C4BB707CF999733BF031077AFC6DBB4CD47FB789068BBF6F4CA29966175B6985F8193D345D430B7ACF6039E1138995FC4E9190929931C69092AD901200F48DB45BC720699DB142080E9459355BD0AEDE755048919586EE79CADF2824658090942161269A906AA1F915565ADD109C92B2A9C941E95709370F3F5074CE46B384940CD8A5FD35A6BA9464424A00300452CD894176EB8C93E44459E4C4579CB966A32549661A28E306D25FFCCC402130C3224C3439C3428B6AADB4E642F07489FD5D8C63B71031519B62494A4CC69012444A0030165213B62AAB21D23AE3C2849C94FB5F4ED28E5969F47EE5BBA1FA870849D9DB4523A24D343DC7424B8FD902BB1E45C853FC354889DA949CB7D1EC8306921214BA02603C38AD135D69A10961DA2F46FE9093F072FFA5752EDDB1D3F63C0B0DD9EDE9DFDC250D969441FB4C343ACE4C330B2CB4FC64E0A57A7E68B4D31134555395522125730C22255B90BE01C0D8B09C4419444EA6449828B1D63F72527FC94EB363BDB99174B986EBDFDD45B3074C343ED94273CBACB4EA6C6048CA1EF15E2FDCC58D442DAA5BECB44C7CE79012008061E09A93E84AABEEE5847730CC8B3313E7E9D5FE4C138400F12163AABC1757D1EC50F17D4D4AB7D0C26A0DEB519A1C9480DE25AAC1DBCD7FCC3246A1EB6696922B901200800BA3C8092FF08B124C54D1A89E9C34DFB44B7D17067B9CC651205B2E49E1A2D9A9E206B6A4DEEAD728CA56212679A82F5185A63FECF46BBE8506F9611E692D255B2025008027C105B15155561A6F003959956AA6B32A15D75534DA3539E1D559346BA29107CD3443DCD096F9A11E25ECAA83F89042ADE7AEDE6813D76258B9D51052B219E91B00406F70CD4964A545F772C25BA593EAD4899A44555AA50557CBF7E72E9A1D9B60A63925165A71460549697450E225DC50D4A0F6A29D9626E9FB7CAB617B84941C31D329480900A02F8C20279C025991E2FBA8C985EB765A976EA14121DABFC79E9232E4808926A49969BE90A6D5E77D2329BF3439A8FC3A6E2ABEA6EDAE83C24AADB2FADF04EB18BABB8B36A577414A0000F2E19A93C84A7DA775386A92ECE3A849FE599BD47156EBF7F6C4E12E9A15EF7BB278525D74D42A1D2AE869D16C0C5AD0AB82DEA32543F774D1DAD40EAA69BC8FF903005006CB49948EE584A31A9B33CDC4F97C5F7C5EFCFFB3B7C44AC3344EE3C896943D266713B75CB3F350410551948D8D0E4ABB0C315183B4633629CDA1F91C5161F0B5B131BD93CACFDCC6DC01007806DF6C39AD334EA772C2DB872B9B7C13356968B3D3F214330D0CA0348E9C21D5A38472133713CD2AB4D0F2537DA77AB8057DDD4D8889AF69FEC3D9984FEB39A19694FC9069A1FA962ECC1B00807748352715FAAC39E1F71457E39BA66B474E5AA5538DB57E4FDE4ACAE07D261A972CA4ADDC4AAB1A9E9CEA89471A4715B899DAC204FDA571584ABEE742D72BEAF71002001804A79C58751739E1740EF71CF1F6F3E1938477155A9E7E9270100EA968567CDF130F9B6961CDC3266E3F3439E8305AD0AB42C6099BE63BBA5491920C9612CC1900808FE13E271195FA939335691662B1F0E6B3696873D0B2E4E04BE3C81ABB9C92322CDCD9C4EDA713563A73074FBE6A102F0450F3EFDB9752B2C719293909290100A8C5B57BCEDD3AE30275E7890783B70DB778592F71F4A25D97A9AEC7C7584E7DF9E9BC2123125DA51F31714B0922250000D59122271516DDC8C99244EFFB99D4B6D803779BB00F07170BD7B4205AA206E75AEFD0FE327D8889534A2C88940000FC07D79CE8454E160931397ED9BB9BAD11C4845BF9F3F66AADE79E5E39D57C9B761707BF98709DD5A60C4EDF406001007EE64CCB2DDA91739B46853ED07C31F466CC8FBD4F1567EF78B588E69FB84363F6756AFE5ED41CE30F74524CE93DDC6C54A2F2440BFD96DBA1F9F7EC9594ECEEA235A9F7A9EC8C77D7130000784CEDE94BB43DE34650CBC9C2B8FB54D3E05DC3A79253B7695AE403EABFB34BF3F7A3D69817DB296E38688CA516B5279B2924AF5DF3EFD9D33184A524E53E959EC61C010068CCE9E65BB4AFB82B6853192B53CDD47ACBBBB073439B8D564ACDD5F4292683434CB423DFFB6DD5A0770E0669F1EB30A46F00008146EB1F260A2FB704A59CAC3964A1EB5EB6A5BF78D34E3FE558C453A3F6EF478D3135D24459A7B01B476D928E069F98386B4A50E80A000840B82036D8E464E43E13ED2EF1CD0D37B6C64A2342B57F4F6A0CEED172E13A9E86D5A6B0C1469323B4FFBE9548C9C6C3663AE965F1380000A8066F250EABB0068D9CCC883153DE59DF2CAA55CD76E9C462ADDF93AFC7B03D5DB4BF14691C7F70E6AA9D361D0E8EB372BAA50491120040A023C949B92528CE8DE1E3E5F9F03D5FBCEFA63FEC52EF86C13A4BE74C8BECA4A2737822F6077C68E6FED2C04FE7B8A5E40422250080608117D8F0008F9C0C0F35D1AE22DFD64D241ED55F3A6769E203BA7C1B37207FC111BC408EBC4952824257004030D216E09193D907CD5472DEB761688E9A6CC934EB266A32726F278516B4E306E447CE5DB7D3D6ECC04CE738A50485AE008020A6EDAE3D20E564B4F87B0E94A9B3CB24BFC1469322CDD43F00DEA7B763567427E51DBF8B9B909F293E6FA31931DA7FFF8F4BC9064EDF205202000876AEDDE5C88935A0E46441BC89F8E03D35DEEF8D7687901E8B74DCBBD6EFD39BC162B53AA583CEB7DEC48DC8CFB4DE72D08E82C0899A38A5C442272E23520200D0092C271CA108043999146122AE0551F3FD5EBAEDA0DFF32DD282AEF5FBF574F069C991A5889668454D8B5D3A6052EB7900290100E8162972A2B19CF022BB2DD73F5B5F5B6FDB835A4E162598A914679E684AE6299BE6D70BA76FBC3DE41200000216DE4ACC690EAD16DBC589DC0CCABB2EAF4AC93D6B970A6DF9745EAD6543EE18BED744A125E85DA2355784CCEFD1E8C461D49400000C037788D5424E66449B29FBB4368BECE96B76FAE148F0B4AC9F136BA28A46B4A00F0478070C0B82BFA5647D3A222500008371F804B7DF567FC1E548C5F2645E64B5CF915734DAE9FB0C21287B4C01BB6B87E5E9D75CB3E69F1578C8E53B0E0A2DB1FA651BFAC85013FD5E60257E4DADDF370000F81DEE28CAE9954121EA2CB2DCA82AAAD24AD7DB036B913D79C5219D2BB4205EBCF7DD812529730F9AA8B2194FCA8148D1393B2D4C50672B3A0BFC944833455458E846BBF6120F00009A51DF6AA39FB2CDD2939A2F43D12B52CC94EFA37370D484CFD80929B2D28C689324685A4ACAB803268AAB410A2790E1B4E0B63C672AD4FBB9D2250D8E92F10E209C200D00003DC83B63A355A966A9FF87270B2EFFCEC01093D4982AE1A895B8F3ACD6EF4929850D7649D226848BF7B2CBBF92C24FCC5BB290C20916CA2ED869759AE71137FE9D41215D3433A68B62AAACC4BD53B47E4F0000109070B87A57A185E6C53925856FD0035CA3FF4EF7E812FFDE25FD6F5CAF313DDA246EE8163A7CC24A8D7F047E94A42F7837C6E193365A9F6EA151A126E9BDBA9F6ED59092C911264AADC72E9C6083E59BBBC4EE2EB64A291E3EA7E989D78BEBDFA5EB4588CC9428336DCE34516CF93D3AD982230700004036DCFBA4A6D9465C28CBDD637FC9B54AE788FC9E7B9FA24AEF527183999A742022BD71FE8683224A3A6861DC037153E9F2E9B663BE61CD3E68A2FC0684F0F5C0F57B76AA6DB14982CE3D83B6E588EB25CB2A894B529D8D4A84C434DE40FD080000001F51DF6A953AE87234897768782A29FC14CD350ABFE699A9E19ABEC50E000000007EA0B2C94E3B0BAD527F16B7A4F4EF4346F86746ED33D1DA43662A449404000000006AC07506FB4B2DB43CC5228907D7110CEE31F8BFE3830B771559A8FE1242F900000000F0332D37EDD4D066273EB347EBBF0500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000081CF2CA4CFF5B8CFF578C7E627C24C64831E68AB1568C7D626C1663A9EBBFFF4C8C37F8E7B5FEBB9FF25EFE97182F8931558C9FC4182BC6B35AFF5D00E815D7DA31548CEDAE3583FFF9FF6AFC37FD1FD73A35D1B57E6D76FD33FF77FF47E3BFEDFF11E34BD79ABAD9B5AEBEA4E5DFE4E1FB787CADE5EFFDBFB5FEBB40902226CFFFC7176946B12935ABC47457FC33F138526CEA4C29303D88C935DDDD9B61BAFFDB21D383EF934CF44BAAC9B2EBB0A9233AC7743F31DFD471A8C8F4807F3EBBD4D4995E642A16FFB9D475C1FF6F8DDFD7FFDFDE7B03D9715C6DC37F1503050A142850A040C11B3050F0060A14BC010305AAAF545FA9FEE20B42F4A2402B8816A2912812244112A00548D0C1BB8507D67B8775F0DE7BEFCD02EBEEBD73CDB2BFF3CCF4252E97774CF7983B7BF73C555D2081DD999E36E73C7DFA98FBE87B6ED5751B834B5A8CC12FEA0C636D8731DCBED9C8D1DF9FA27FFFEF528F3D83512E0021A1FDBF8DE446BAA2CD189E4D72E29B062343F223417B2E4B7BAE927EE61711F7E917248F664036917C335651BFE6921C802C401FF177F837EADFAB50AC51F78DDE3F87DE9F21599A20F96AF66B4DBB31446395A6B6957EE6D73E9E7F8F94C379A23055FE7FE0DF49CFFC03F5B71FFD5EDE6A0C15CA5A5A0F7BFD7C47A911E5384E78606069D17CD8D2675CA0965ADC6C8CBCBFD110CFAF30C4630B0DF1BFDFA9B767971A62FA7A43D0061BADDA646EF62C09AA4D58B4517F1F7DD3BB2056AFAEFA693F27CF33FB394A0221457D7CB4D473C1608C77D03E7A02FB6956A5318AFD3576CF3D38DF10440852B42F8F4765A1808CA33E25163619A9298B9DE5D6B216930C5C8AEA848F31C058AC6835324F2EF9699F1E5A601D00DBFA8C6158AD359EFFDF24FF4E82241251189E536B6441C424E13987435B80DF727F63AF917861457159FB598D314AEF1C29851E08E0DB221BC7090D980C69408FD186CDCE6B34B22F551862D23C3D22E2D6B0B9DE21A252D3659E562E90F07A2E0A2B8A5C4C493782051286D352D4A73806A39C0065DE4C8AA798821DDB60792539F079147D223937584C59DAB577D79B0AF46614D74EF49E65180BB73E4DA383952427BFF4FA6C92B54FE3B08983663192F8EF3586009120D9373D8071FE55C766233375B9FB77486B7C49ADE82A88721C272C70F7074242039DC1750C48431864C4AEBDB2D23C9518F4FEDB6133672225AD333618A35EFAB5A4C548C1D45BEAF96130C62B48801F8205D2CB7E83E582F6DB50980A0A070DC899D757ABCBA9191B0D435EF38666A6CF1F9C6045F2D2A72FEB8C0C8D719DCAB39F58ECFCCC47169857F5B882FFBD9F6F2192F9AFA52D46C2CB77D0CF8194BE1CD6B8863147518DE384033618AE35A8257122889A901463CE0D3D468A36DAE2304CBA60F024588CC91EAD4030E3C2DC5BEA796230C6236099A8E93206556440459B7938991C569FE0B7F15D8391D69551ABDB4DDF88E742EC5F2DAEBCBCF607B24C2A3F577949CF3E8F93BC5759DCDC675CF431F7F7C087CFAB550AB2165693B0C635E0398A6C1C271C7072A005BD6555BB9172637E513690A3454D4686FA16F89D2EEEFCD6B41BFD2AFD69B4367D2CA38A188C3803516EDF361877540F2724F87B43EA8F7930D1F5934383A20DF3DA0107215579BCB2CDEC8FA33F034EF91B3B8DDB2ACFA543E288CA35D198F7DD8BC00295F7C10A51EA082D0FDF15E9384E2860D1C0B1F5AB7A2313960F89DF06464A7DBC132439C1496C5EA39AA0A413D2009BE2180C75D0BEF9F65D8FD73885071338C687A1F861E940D48D5FD9B4A1D3180CE3CA194A0F4A4CB53F708445CA0697674FFDBADE185079EEB216F33BFFACF92DF755B419B754DEB7AED394F7B18E868C7A1C270C602921C67FCDAB9F4529DBAB9619EC6A50E4849EF3E2CC4A23A9D2075A84295E540C863A68DF4CFFACC61856DDF7555DA6200F3CA201E1CA70E8F72B9770D54287A62F4318AF17E9E0A4249FD096588AEF7E9767CF5595F95E088FC3FB1E5755E00B9AF4A28CA244D4E33861D0DC6BF47C5AAD7FC71A757B7E85912321703D08531804E59B6BD5DE0F67606CB252CF1B8331DE80245A8B9BD594131A91996CFB66E3E380FB8210DC64101662F843901CBD1CF47835F51A6DAAF209ADC622728E892171D29F5BAF662D5ED16A3E578B2840117FB051CD3A351E646DD4E33821D0DA67BCBEAA3D98CDF9F822CBA2F1DE06437C5C6D886F1AAC3F113EF5C61A433CB7CCCA4F100439F9A4DACC7150EFF7FB99983018D101D17E558ACEAF6888D223257D38E0BEDCBFB0494DA138B5307CCF74FC4BE0FC2AAFBE1C23857045B2B643CDBF8EE66044375D42B9CADAA8C7B1EC814D44C42431C587A32BE2D171B5012725DA0C060DF889BA6EA3B7A1C75859DB6DCC6EEC312AE8CF0EFAFB2332BE1E6C31396D95FE3BD140A4E8B9436EE64A0F6350969B85C18823E02702A5E9350A2EDF70A091CA36B0C83C92596BDFF01849E1A5214C37C8E81C33DF4BAFFA350EAC37246FCF78783E22306F7B8D92796B9DF9DC233EBEA72C656DD4E358F6A0C1AC9B556564753621163F2C2DF48C9BC8EBE1D5E7031ED6307D35F7196737741A89E715121A15234532C191760E8172DD2C0C465C4142F934ACA7AAFB3D683F132893A02CB868F055A143D9D6A0FA0719830CB3AAFD803C4388B1C777FC890E78C36E6921707845F4921F47D47296B5518E635903B5087002D1C95362A667EF3363F75FD6250532A6FD754C924AB6C5B16D75BB99E340DB11B59C370B8311471021588E0CCFAA7B1DD133B4EF5E0FA20F483FBFA6C3B81914294133F38758A9D403891E22D9B808D7E0AAFD986D39567A1E279A8F25C8156597600E654390521D35CD7C8E7959CBDAA8C6B1AC41A4E22D1D6FEFCF6A8C344DC0F900A362FE0872E2253D75B186106212062D3EDE5FD69B85C1881B5000D44B7AF5B10DD72E4DBD467B107D20F9F7EE0C45474C2F0D168EA0AC3AB02CB9A56E2FD664E8B29263257E9EE4FA65D47859DA62A489DC20F36A1AFF8F3412207201CC7BD9CBDA28C6B1AC4103754AD55201C7D6A0A2610A41426252638F7BAD9A62ADE0EE59D77253F69B85C18813747D27E0040A4B6D107D20A5BF1FD7D14113135882E8D4FC550063F4F3A87D710AABE2929CFF26E8AAB81345D6863D8E650B7803AB2E7A389BD6F7984C3C94C46238C12C6B550F2344A37EE194F25F9A633121360B8311272053AA8E95546602D5DAEB794069D373942383BC347C13C9A3537EC707C9DA3674AACBC330A2978202CB5A8623606E5AD3AEB631A5B524344F62DCCBC29155C7197675BB991D502BEB226F1606237AC03973BA869F89CC98F9B09F77C35171698B71230C628226C3867D8582D2EFBF89245CAAEF0E23DF4B506059CB70044C4BDF34A8797B6381103109B5FC3816A0CE296199872C870EEFE4CDC260440C5D3F133883D201669E9F77B7F519DFBDB5CE7BA64E5C21A9E41281EF9EDFA283446EBA75AA1DEBF897440596B50C4760817C5CA596E9756E9DB940A686DD37123AC754730BF831EFF2666130A287AE9F092CAAF08FF3F36E547655211AC83B81E6F5E7E1905FDF6D6CF0D347245643C24A95B10923D74B906059CB70044DF40255332AB2B936F4184B23E8DB7D88D2F1BA29A7F874888B62B3405048E7A7C7F13E6A33310730D7C22C2DFFEDD7618F6D5090B968EEC55CE16488D3AFFCAE6F513742FEF733F2DBF033BF8D4335665C17CAB17E91DA6CD93F25422BE7F277F27767CAE7C0B9ED8F41CD219CCB71DD8014DE05CE73F7F90D43957DFFAD7C369EF9895C87D3E5FFFF39CA75A8E36702BF3852DA695DE58BEF2339A694ED15961D15EB0E9CF8893CF5FB98A77BA98FCAF58482F02F417E0DB916F2FB23B07D1B17622265D733F21BA7C10D20E80291618E63D902CA43358F00C2D6C2A805510C30D52E6B31525EFAB5B4C518214135DDC75884B259B01071D78B4472C8768B70B155ED466A5EA331F2459D95AA1F05AAD67618438848C2CF4050A310985B8D8B2801418E4D8CDC1324F48ECB13194E66B9FA1E23B1AEC31858DE6A0CD3770DE39B66D71859FC77459B31827FA39F49D2FC20AF8230C7A1CFB88A904F49CA22F35447CE1D9C42E9DD298474CEAE350CEAE36D9A97047DDB0937A76E081A9A9F467C3F4AB7E377BFAA3712F003A0EF1F4272257C1F4832FDDC57202F9AFD7C9EFA99C4BAF8A6C1C87C5E63087ABE81F543CFBDA4FA5C49C626D3776F37FB477351DD650CA3CF73EB8C14D6F2B7F41EDA47898D9B7E5887FDF4BE8D92C084363FBA7E261BAC8AB35A21B9D8B7F4BD4AC404B927688D789247F98631D64DA9803E2E6A5677CEF5E35F82F5DDD86B5CA2B59D804C9D536B64698D0F63DDD11EDE8CC388DFF92E3531C137D0F7B4620FAC24F90459B5B8D91841EE1199A8D37761D628C6B16C8105F249B591505DF8ABDBCDCDE6CBF1CC63FF505CEBBCDB3D30AC38F47357FCB0DDA0370B48457DB7D183C5BFB0C9C8E29ED88BF507514F383D42B880A8D066394E9B654AD8636DF30DF790807B94FAB01B8A6A0D112A28487C0BFAA81AC2986F309FA31401FC043036D8AC5291AF0B331322AD917749E90E150B0FC5B863FEA90F83C594BE5C8B75B0E27D5CE59C9010CF82050FD994112926F3164CF5AADCE9E7BBD7751A237661ACB82280822485FEB48739FC2FFAB945D4EF91F59D461207112FE1F8B80E401A015A87A334FF06ADE3215A0B5F8621503B352BE77EE123D11A8DDF7A95AB62F34046649A7EEF864AB65A1056DDF4F448AC06D9A63A2E0868D051AE584FF48D46319288BDFE659D593919078CFFE373BE4B464C2429B984755D6C0F43B6E1D04273F6AAEE3BA21AC7B2054DD294EF149D5FD1B03169505341A68576E8E3BD505AB43047C72A4208CF054DE629E6BAEEC9B4E03D816C1698DF511708A402424527A36EA18283025FD56618203941E78D71180B10922768035F236566605C1EF1F11D5EBE133E0374AA18C5A914A799A012F7157CD36FA0CCDDBE43A6F1EE1BF3BB2025BBBEAE37123AF3896F03D1A0EF3AE9F65DB06AD476BB17D37C7AE90F7BD0F6CA85C6F245FA96612293A34FFBCCD5019202F2803A58D43E0FD27F016494C88FB203AC54225A89D660955499CB999526695D84AC9E1F286461C5B50A6A86E9F45127657F41E13EA56820EC0F3AE10FBAD54BC3F7B4F6F92B3C572A622249BAEB4117074899B957F99014E538962D60B6863954475041D8A2F01F9865D86678581FA0AC706D50B9C9482C6A32323037E3FF69A15506212483D82C2047307FC3DA1164ED0DB40F2B8D51FAD6DBBAE1D01EC7E0074242EBC278D56781459D066531CBFA56943A7822A86FA379F9F4936AF77A502004CD5698E7BD724C7E8E245C389DFBFD36582B5097C58E9C745AE5192E416879791ED619F5ADAEC8737E4D7FDFBBAADD1852759C746B10B8307BD3779C0EF2AA51A77A2EBE4DC7AF0CFDAEE952AB022BAD10B8D2BA9FFEDBF3610E724012482519994FACA65AEDFD054DA760ACA3191BBC4528D161D00049D39DEB521013EC395AB377BC4638E150E9B5CE50A9C6B16C81AB0FDC63EB0A2998F3E9443D4C13BE5F3ACC854D507E23DF334D3A1906796AF3B559A044619EF35B2DD98D0CC2578316F333218CED2F69536D5B5F2242524C015611F9A43EF90A0995DFF6331002AF198541603AB618EFE37711AEF955BD7A1E09BBF69FB5464EFA88DC53A49FFF0DBF1515123736FA02CA13D75174C2578AB6536DA89385F58E6CCD41AC3F9AE736D5FD8726CBC6AB3A2EBF38BBC6BB85A630CA05275C38DDAA5C634A52A394821C0790751A87465896E1DBA4F8AE5FE38AD2EB37616FCAF1D0BA3A8F9A988094D03AB9A9229B61A9827525CEE358D620767D50A7C267BE81D1E3CE7BE326639026E5166AEF8C47C71E3F9B050E95959B8CDBBA757E541A4E95F2441F982F06362ECDDDB5B095996A834258D7613AA5BEE5F3FB7E4B24C7F30959D66269A6797DAAB6DB3082B67E49E7D2878BF4F34FCB5BD54EF2B2D26EDEBAF327589AFCEC6795061F185C59629C0258835A7E268B9B8D01557F37DA3F3D5EAD52685068F49D7BF3BF8F881795DF0759A035FC81E278BC897A64AAE3A1E35F822B79144155794F8DB5EE629F9A214F4A541376E6497F9CC7B1AC810DF04DBDFAFD6EB10681F86D83191D03C7BCDD92A4FC3EAA880B9FE3A0B559E864DD87C515B4F2726A108A888C0AE80AEB57F0D1797DB5912B351129D660E580CF851F4F799C3E57B47AAF200B850B676A9C7E748AA7B9355CE9D0FC5514E9E794D9B56A3E5F4BAC62710873FC1FDC8B47418E0B1B4E7D343F708C7DD9E73AD4F23381C95D25D19ABC2E1B51D9AF5FD6990EAC3F9063926F33662B6463C51A2262734C653C60A953B55CFAF02F7998E4B65242CB2556324BDD88A8488809641BAC1E2A2432DFE09345EBF1749CC7B1AC01F3134C93412A563C0B8B01A19874A21B90E1994D32663C96EC5077B34028EB141DF4DB9018AF987F81E237DF83D0DFF7377ACF7E598AF65285A9C8AFF9301D3F3EB7CEFB1509D62FA29070D20DE37BA07048E86D2DB60655127899EBA0DAECEB5C2252433A651C826858FF8D569D2A5FFE4F3A7E26380CA9F8544009ACEB306EA9BC037BBCD0B91E872D84017BFD7D58954172550E12180B5587735DFF125C8D7FA05861F9936A63D4C7D54A1439A34C52A27BE022329AA33D3A33CEE358F64018244DBC527CBEAAE0C2750FF25AE04E18617748072DFD446271BFA6B359100EA62A48836C959BCCB06D6DB68D304612D2DA3E4651363A5920C7C034CDB97D7DC606353F91054D964209E35B649E890F83588310D888942915292924082D560E08ED6B5C1D3F93498A89D6E03BA492EDBA582563107AF8E6A91C489659962D4F563F5C3FA050AAEA1CE8F897F859777125269D5671C6A3EFACD7F30D83B504811D1A96A758248E2B1BC0A9149B2F2A3330261E51266B3B8C3B102A8820900EAD8186882A8E81F2A2F2D270FA86D00689995D6B08E40141FE0EDC5BEBE601C9B77F5BBE10BB34BFF7173069FBF547C037C0548DBEE08A021BEDAB7AEB3BF1FFF84ECCB75F8B9C3C196B25F6D3995BBF73E3F4DC9A6ED361F30F41F41361AC5E4DFE7837AC4F588B9F565B7384F7616C83B098C221B6B1D7D8EC630F4EFBBA5E3DFA697DA719E9E489A0D37E39A4723D87B1A26FAA1EFB1CFABB1695B9C25EA0772FF7380E8F2F6C522726156D7AB5C2CA8998E4A3E866285A2EF20D915ED26F4AD9A99B89490840A64964A9F3937743577123840BD6143875C20993C8CA02199A1759AD87A0890994F1770D469A4E6838C58CD0D8EEA2B614E9FCE9CF4E99AC2985EB2EDD3187A2413220B76CA5C5407D9A83FEE9BE176385B06D9AAB2C7242D0771DA653DE16FAB65A6A5FD6761BCBE9CF3EDAE4E765B8A499CBE3DF8AF58F0A9BCCA2A96C210A7A6EF357952098A81D05E182E77B21F6F057A0B96F09AA9F5E08054CFCF31BCD68AE34B251629E687E56A2D17F1FC4E9BF63B3F1FDB70D46CE4FBE13582FAABACC93A656E13AAC635C9BA8BE177BC84BA23519519352B1842134BA98E2C0B5B48AB32ED606AE233DEECD45AA19B9A5E528A363B12A1762024B16C9D4CD736AF5ACC0B080D57419497A8656723526262101D72BC87D109609DB4BC3E90D1933112A0713356DD2657E93A7794150CA0B8B9B841914768A04D14C2741017F1B643B452A645D274B9959F25DD5EF856FC90B1AE67FFC0E362FF5793FAE82BCFA0C4129C0B99336FDF165AD4642E784AE9B6A3BA8B9058194E67258F9AE826082849172AF42D406D62BC2B9A1E0F1BEC26B3EF80B2C6AFE21E5F52FC3EC67BEC13155966A8045E145A7047D58A734A79FC01782D66F4ED76F0AEB989E7147277194CCA363A8BE1B1623388B7A78FE9F2BDABC473D15F886FCAAC8B37EA35A7CB0D18AA673AD9502DF88671509A2CC4C7B5175CC75D75DDC8889F4976B26E2AF15C881FD29498952F45429C771C24032CEBA35ED46326ACB899D929F65397922A1D3BE4EAB085228113E412805F4974EF520244B5504334E9820273AD95521941101A5FABDF0DE579DE3CF6BCC8DEBAB96845C63D548EB1ED5B70631B720199823522E1BECC858A7558FE60F204F082985B58C884A0A29DD3BADDA332B9DD64590C4A42001E2378A6BF117B872A0759CD6252744C08675C83280ACBBAA55C5D14F388BBA3D1B9658AFC9AFF2CADE2997052C202A1626585840CEDDC61FD7DBAA638E6CB4BAC9BACA8198904CA95A42EB4EE7508D4312741E0A65EA7C4FA9C67142413A762D007B8C3AF4D0AE61B1E1BA07C5E068F35D84D36C08DFED4B29483320AEA266E9BC9F36C5029DAB15CD78FB7B5543333FAD36D27422DB13548832097CE568269D6F0D626E1F5AA067E29509B9E0E07D9F9772024111134422E07A4D35A95721EABA8D77F0CD3AE4A4C06AA27C88C0958C8E9F099C45DD7CD4605150916932FFC8E7B6CFA303C8FB0AE9E9718D49FBAED1E5FBFFA89A0B034DFA97E85EA18D6B6282248C702ED6212558DF0800C081DCEFA197894904405E02F84620C94F1CAC27F986D354A3E58BB229C8D063BF4A0109E6FC147E82E2C2F58F8E2280AF8A0A61800057B9CBC7295316A20BACAE03AEB974D2BC4BD3BA52CD20BF730BC2484A6D4D50DF1E563FD170152A49896F47721423DBD0698CE808FCCA4DA66F86B2A2D4F53381B3A88BA9FF37C8F3A2F24C5476760A819657439EC386A56527E9F4FDB034E110A0D24F3FFE25BAEB2E2EC404514898279DAB6138BA827C4B9F46DF9678262611419E6C2BA9197E9C16836E70BEC4E69561825AA78422DFAAAD1450148A36C821BF7D80BF894A81B07CA353D8B097BBEB42800479219C70F2F41B066A33DEBF5549BFEEE75BFDCCAD598FC55A67A117DBF24B4C209C65CE0DE5C80C3BC07703D136AA7D91C5109523C674FD4CE02CEA7495A11AE9226BDCA49DD219E030A092821C4D3A70DB3AABE32A4BB5AC851FFF12DD75170762020BE6C64E63588794C07286C001D4D0D21DB7528FE384074E0D28154DCC340582125628A56AC33D3ACA4BFBCD3A29BF514B2940B9CB14F1DA66F3823E4C864956B50F701456B51E35F6180B5044CA6DF34A0B8572D48F876F8502CAAAAE25F9AD4A91397E14FE9C5A230B937DD0DF1F743F655F47E0C712709F4C4B832A51908A3DA993A708CAD96BB1B57C83B328AAF1DA3D133E082A632B93E06D73EB2BEDA3432A4EE4D259DDB6C402C64CD542EDC7BF4477DD959A9840E6EB26B784DE80953908BD51CA7164FC7F962281E2A4CD7F045109C88CA7EA391E460B8AF9EA2A05E463A17737FA7977411F7E0593AC6A1F56B66929EB9F213267764D712758E95701E7C9E7C35A53F4FE13AA6B6875BBF9AD4A3E467E14BE0CC70E3D2ACC6F3F315F61955147AD229D3A366BDA8D5B3AE1DDB8CEF84221E53B9A5BA235FAB72195648828DCE84571213D3DA2C5BC3E1716C8C2BA3B63E65FCB8AB8CC4A6BAE542FC8EFBA2B2531A1797910B946744809C65F1EB602B32A966A1C1963800D44C26A094CAEEB3B8D2418BB9FFC077E1BCCEDD55DC6881F25AAAB14A45008E43A0940A23BD5131372C068E6F7F8256AB6800CAD6A3773AA9829CEBF6B34BE07F90CD352001F087AEF36D5080CF9ADAA3533B4E616A4776CD6CF30E1879820A1545825D4F38459D5BA85F4DC3AD13958CB284EA83A066B3BCCB0E86289EB50B559A986499D9504CFD54F07D6C48D9BBCFBC4145C11FDBCC8B3A6CC6F54FF6EA96895AE37FDAEBB521113100A14AAD409CC80154E5AF17C954E88CB38326C2073534C45B54E9014B0D86F1A8C3416409445EDD0701A42BD10DD0DAAAB14EABB4D45F9DBA0C614D94D55D3DCC389D4E789E95E248C822319880AC6A233C0EAC585EF20A1522B13B20D8364A8E66F91DFAA949A5E776EA75BD93A6B831C8730FA8956DB6DF407B90EC742B5A22E9AD7FC2245C6E1673AE1ECF03BA3DF7DB3C8F310E993509125B40F6E79ECEB3DAAD72FB202F04FAC7E24BF96ABD64A9205276F44BDEE4A444C568084E91C82E18200AB591057EE7119478607C81C0EF7A116056DEA83C8E18094F3B8EA80F2892269DBBB1B8C8CCC77A213A6A895755356F30C2CB70ACCBCAAD71B715BDC722DA0AAF48B7922020BCCD216230165EF270C5D7EEBF4B0E7168D88134ECD53231C373F7E4E5AE9FABD02960F64AD55E9D7D33E9426F2D5A856D79D664384707052F1599169E8577BED6B7D8FD1AE62F9B3AB69839C29AA4A17D595FD468C8D1762E2A72614920D4A6B89B665296EE3C8D080B4A6DC8F502C94908729B8A2CD18C1B54F98BE29F234A2AC4C74161542339D1CEE744002B15E35236BA917B7B4863C8CF2F3F05B0129A539CF10114963BE75B3DA969A98E838DAFA1C47AD7EC292D1D0E3AFD2B487BEFD4E35F70D0E23580B3AB96F74FC4C40D0C6265A0349EE20D9A362D140A22E95EB595CC17CDBE0BD086AB1281A99584DB990AA2C0EE86BEF8F0762829A50AA16BB22CF48938CEAF53356711A47460000539529C9AB6152C3091A1563C1F883ACD08B5316BDE38C46FF9417150804096BAD227A7640A235D58884281737FC52A8FD09D57151B00DA710FAEF1C9214C1470527C72921565C8E929820E3709827ACA0FA39ABD2180DD349390F9C5855AF686BBACC8382B2F3B0AE9F097C490A7D43F09CCA4DDEFD4B40A6645E20956CB9BF51216D0579477E5DF08C3FAE6AF79E2E3FDFFCFA97E8AEBBA8894910AE01662DA74DFE895C5CC6911102E0C380BB5F8406E23A645EA3910EC292522058947C247416D51B5626C7CA80C725368B5B4662E5AF649A6096476A75DADCC9AFEB8D1C724760CEA2ACAD141531C137E15B831ED3A0FB89261D820373C0B60352B0AB924E1945A5EC6CA8EB6732BFD124263FEC858E2DC62C2489F4FAFBB06634F618C754FB8BDA492A5794632D1DB0107D5CA596582D08FF1239D6B127264135999578403549631CC7911132908303750A60CA5CD064A4FDB2E36F1ACC503FA5626F3A8B4A26915A1FF0589474714BFF90A992301A884E405142A4DE8685286AA7E6521113E94C7D33C8B90DA39F7E94BF2AE0FFA47ACDA8134595878E9FC9F43189D6E8198754AE00641A7AE5426EA81A3E5DA12230483D11BD8D05FDEC53BDAA08C2BF049848C4040DD5A891CCD2EFB8957A1C270C605A8499BED3AAEF1168A64F8FEFFF057282D49032F4731D200B98F52BBE5B8B98D4761BB3031E83922C6E10121AB369D40637741A06842CC2B04B49424A4D4C48595C09726EC3E8271A9CCCA3F08569EC35AA5533407FDB605E874DD1791F0E172A3942D09E2E48B40679A29AC46F5D8779F5A49C501072135610AFEF91C90B07F2BF8F2B5155D2BFA8C91CDB67FCCEEB44232618675CBD61CEFC8E5D29C7B1EC0133B00CA532CDF4A8888AFFA693435BE13D685490757A127EAE7664B48CCA3DB1F2A2324F2CBDC6CC80E722F2C58D6B2F08F3351D46E6A58AF00503AE49401ED16F4D47DFD08989F41FDA17E4DC86D14F34DAAF43AA997F75407B728E4AD13ADDF92A188F3F124956F63381E5B5D32AA0783FAD69CFFE255058903B9A517D667A7A956BCD462B6334AEB47F5BDDA55EB88F644FD24BAE9530D6DD7826266832D1DA351DC7ECB88C63D9021B10664F98EBA1900A19FB230BACEC87483015744E0B8F7DBBBF72935E196B345953C5F3A6F5B1A8B44E8321F4436B7113819B8494FAAAF913541B4E8820724B5ACC50C91C11A13B447CCF6B7E6B24C4C42E436758D015D83AF58374801057556222F3CEBCA8391E3FC70143D592B0CACA38FB074404225D81D7DFC3B51191BC0EDDF1A1DF3DA012CE8A6CBAF0B393513D4A09E0C65A5CFC60221213B4054D46022E04418C6129C6B16C816AB8B4891D2B33A280976496813B0BB98194D7A68FABD44CB9F9A66ADE8ECBA28AB21F2882454A2DE527AF885DC35508BE83046E8E4E86697AD7704D97D14A6B694A5E89FAF8D64888496DB7BE928A6AEED16458736889A3F2A0FD58A77A95E3C7C744BE5339B11B9C4891680D724B2554FDEB7A3353ED53BA7DA535FE2E7C54BCBE0F634987822D48ACA63AEF4126FF1BEFC404F24BE7798FDCAD7316482DB0B8E890710D5813684324BD84EA4655F6BD481F7FA3533B066D51B39A408CCBA28AAA1FA837812B3B9D7A13631B882D14397296C051B65912112876520E53ED2C573881AB2ABAA888094ECF75DD464D90731B463FD122F331D1707EF5DB371D3F1369A63FA97AB522B338FB49EDFE7BF8A8787D1FF61E72AC20CF93EAE12028FF12D9EF714B4C9EB72C9B49A49FD0F189433F68FC4F049124332E3A645C034A8136BC27768F903D909828EEB18BF4735027CF099233C14CEAF53D71595451F4037E4328F8A69B4511C21EC27F6E9D31BA7193B92E4C47D1861E635DA755CFC2D3151A229AE2EA63829F57C9FE59AAB9475BD0642A54ED92045E81D05455A7F4AA2E333453FB2A58C7CF04F20A6B52C519758AE5EC7CD5EF18C14745E5EAA9BACB18D649AC16947F891CE371494C64757910B43FD0DAFC980E454AE1D6F9B6B2CD18A1397853E75B4A398E650962993D2AA1789F549B157C97C5BD9FF98653161393E240F6436441D4D9C4B8DAC30905E9B3E10C49EFFDB3EE351F29FE3DAAE4E8F31AF35B43AF951346C45518FD2C58EB819C9E9DA0E3EFE1D7FF45D7CF04C9D9DE5108DFC5D508F5D57711C4BA6EA355455EE100B5A2D5B8A5F26D41FA97C8311E77C4043E9144CE06F35798882A449E1D1D5D8183AF747AF675F08E8B0E19D7406D0D95BA0CB2ACFA60D461C4F4CE4F551DEED054EFB6E3B2A8C2EE07CCEA5016AA4EC53851AEEB309DC5F6079533039140AAD6B06F1AD4C7BCDC898974DAAC0AB96FBF43F48F6ADF824852A7E36732B74EAD26D3D216F3E4FD47BF7D858F0A7C55BCBE17DFF581A27C0BBAB8E4782326C88C4D72E8CE588B11E68F649B72766234D231A3A413778EA7712C4BE86471FCAADE48B46DD60BFDD30504AE6A8A76343A850CA8C4A9C7655185DD0FDAD0ED33367877D043C346A793A039F741DCC516F4E5A6EABD7054C4448E696405FC74FB89F6480445FC30F7B3156BD73C6BE514512E0F3116B87656712ACD2B7CAF3F5B902DDA77E828AC43887254D95BAA564319CDA315E964D3E771434C4817E4B0D6EDAEB1E0A03D5BD12729BF0636741A23442C9F182FE35896D07164932644584D7E16593F7B8DB33A65AE658D0ECF77DB71595461F603A402D95C551D5E173619A9A09D9F65BA7BE5798D9898442A30FC08ECDA6EA33FCCB07E921787541528AE528208C7C475218A73EA8C8B9786EFAA0F30341CBE2A41D6FF1ADB6472B0C0E67ABC1013548FC715B293D55EFACF69E5C0C2EFB45A3E2B5A57D3E345CEC41A50343A8B0385F748D8BC15451FC18A554E1FF9866B279960CDF3E93E2E8B2A6462F27B52604AE6789901F566D0641477C3D497614D62A2943B262E731B463FF36DC64633CDF6CA90FAF50B385BAAF66971B3711BA42288F7AB6670559CEBD120651A919CC561E505C27E1C5B413980F18D3D31415D329243FBBD900614B44451519D1C58B00AD25A6F180FE35896C0607CDB60DCD1D918324227F48CB0F49EF52A0992F20D8E51B4888F2B8E472C1655C8C4640A2238549E8D6BB4EA2EA329E8B9D5296B9FFF563A317E1297312DF5DCE71BC838D29A87E103868807244A53ED13EDC16195ECCB4E2065714AD5C2EBB521EA27600BC41F11CE1B465F657DAEB620E7773C1013453FBA7B68BD1C55717ECE37905F2296499D74F5E345CEC41A2016B4C087744E21200BF4BB5D41FA1B14E9DF645288433A8E4C9F541B5938CD2ABE2F168B2A6462321DD1552ACFA6130404A1E7E8268FDF780F7237E8842BC3F14F358C372E731B463F0BDB9C5A6384C67549C07DFA2F9AFF11D52ABFD2D2E6DBBF240F1D3F13AF840ED11D018FD9CF91B82B0C6212B47F89EC6F591113F98EDFC16F48274F130EB6A8B5A6EA73345EE44CEC419B67EDBBEBD5373B4C648B9B8D11FAFD8A30FA05333F09B5DB3ABE2568F20EF6B78AEF8CC5A20A99982C50A9808A86888120C228C7F4E36124DED2995B44A0507F7AE332A6A59EFBC206128F02983AA73D3BD03E6CFFF75A23A7DA17995E40E970E03236A1F899C02258DB6DD4073D9775DDC62195ACB38AB22D505FA272242600FC9B1634A95BFAD09054947E7F411CBFABEC81058E6C873A7771B0B4907219466E9320BCD90BFA34A5D947F22FB3C649AF7152E3BDB1585421139399B32AD54CCC10AE8D3DC6B100BFEF5E904EDD028DF83D5A1F17E332A6A59EFBB1EDB965E655AB529D283BA098A64A26D342D920AF7102BBEE0DCBCF04A1BD6124A7A3EF9FAE1A06ECD6C2F02F91635B96C4A4D3AA56DFAF1A6A8E064B1ACD614A255DFD789133E302A4C4BB75C271D170429BD7688CD0E4DFF47B4A034942DD0884A5EA9212B455ED465227E42B2E8B2A6462F2F09266A35FE5D9329432A96A81B279FFAF68ADDC7A43310DFDD88654E32ABE0B7199DB30FA59AC613FCBE802EDFA39B83AD9B8C918D431859B49F87A8DEAA0C7270C3F13698108BC0E18AE1282B6F084E15F22FB5A96C444BEEB7EF88CE810DA37AC5A46E7BCBA2C8C1739332E80845BA8E2EB67C34C5B6595F0965ED32F7A3D2921E61FB92248089E42AD033ACD8FFA3911A11F32C65DA76C792C1655D85139D55DEA5728FF596BE4E8A476C18F650CA6789C5E5060CDAF805ED16A1261CFC9B0E232B761F4D3AE81DC236C12B56654E60D3E25F47BAD6BDAF5FCBBD010F91546E872D07E26C8E3444AEB6C58F309DF15DD312CD6C2F02F91735EB6C404A08355B76ABDA50259E3390A75BCC8997103584DDEDBA07717976F2014B8FFFFB6C174C04B822020570A3DBB1E77759834F8A4107969A67604110438F92E69318670C2F36BA2C5C9BECAAADBA2159E189745153231F9856E514464D22525D7A61A6501F249F3DF440A2001A7B2200434426311D51387312DF5DCBB295E6434A53947D8EEEB4ED73B9290ACC47509AE3774AE77D170CA6C0C3027C8983EFE49E76AC9AEE12044F2E9A3B0E6B3AEDB68502D52E9D4647D9CC0EB95953B31E9B48AC1A6757C160BD2D5BB1EB6C78B9C1937802913996083329342A86111E06E0FCE961F575BF927F027D2CB4378A9669D756B083D45D63F1F63108B4515763F688CF64DD3A82721AFED92B8E326E5F59CD3291CEB09BE42781788D0E735462AC89323FC28E8D97D7119D352CEBD97867D3DBFD130DAAC4AB6371A7A8CAD382CC002815A54CD7DC6D58E2DC6281CFEFCECCB4734EEE515C747AB6E8E5D9361C2BF0B713E272F680A263A07F214323A2EEB6E3C111380D6CD5B6BDAD573F1A07D586964BDE896F12267C615B041E9F430A0533ABAD40D961A08579F570DB1585411C4F8DF0F33BDEE58C3F9147E3CC8DA0A2587A80D526AB350291827E516CBDF08153B13382D064948F20DD63564208ECB989672EE41FCBDD684C1B8C16A85DFF9B4DA0A0547AE071C20747C49C6B6252DA6A57466986384EB621D623DB641CEA1DE4AC8F3F97358858370D885232D8DED5721F5B3EC8909AEF7692ECEE924BEC3415B6612BF2F6EDF352180025470780B2BC36218ED85BBA5AF7DDD69C7655145917C08E441372A26DFA0C8A0D0DEDB60882FEA0C31B3D2102022F06D784421E70594AA6A8E0CB4AA4DDE53B0C7656EC3EA2722EB8220167E1AFA0DE7D430731B01B8C2FBB24EEF3AB2B061DD12C9591EF69C36F418BB752ADE8E6D70A475538CBA9808C444BEF77FE0CBA8229FC6AC975571FCAE09019AB85574221ED299BCA81B7C53DA369BA663EDE8833CE05446CA55C9D4F775BDF96EDF29B7A3EE07CDF18B1B3AF5AA7006D9705AC7F502FAAFFABB282849DFFC4C88639A087A6E3DF45357B01DA2135DB254E4445E3324820851F63046F7227196DFC3137C55541CA8758190EBEF1AD5D77761C33E957E0EA190BEA8659FCEFB70550F6BAFDF6F851F15AE3555E7608AE56B3210A7719C509026AF59C4F48771975F6AF261D790184EA6E0F64D4AE4774F9ED7A816B1B2BADDAC601CE87D7A14FD90299B7BE83D5A9EEA7E1BCCE8156D86412790D33805D23C0EA926A392A193EB431CD33B61F94A38F453FBC4057F91AA2E231135D97CC18AFE8133F2A4A8C6A9B9CF38E0C717E791053F1C68422F460A675510295D6762345C5DD5761BCD21F611FBE37654B24F673FCA6AF1BE23BDE0FF0679A3E3882FEBAFFDC2E1D9918EE38404D8695B9F31FC1F8DAC8F61360895655621C113417AA84341AE6957CBF18154DDF0F80E78DCEF5BD7A9B6691BADD3AA523FB0C1680C2FBCBF31F834DF4ECDCC0DD067929239F91320D65AAD62A23FE9007B3E4E631AC0DCFB3205C3DA0907BFA82C27984BA9E07D9F6415C7E9719A4FED5A34C8B3A25BA84D07C885E127B0404656FDFF218EE77DEB3BD514AA9FFDA1B31F715D1954224F1008F45FE5564046E70CBA3C37D2719CB040522D9A8C4BF31B8D64D05134AA0DA65B086152A619526CDF066DD644F22F84397B558EF0D108290BE3AFE03313453F6016C7EFEA9425506DE8270958332AA4D80981FEBEFECB3AEFCA06D7780D3DDE8A0BCA5352DAABC20E6B6E3DF4D3173191D6CE55A408D3413888DAB549D65E1C6D0FE81A55639C109D63E858746556DAC0D3BABBF4F771DD3067ACC5C61E6F04DC47FFB03F525E7DBDFCEE0FC8385CE17A7D1FE699D6F4AD20BF99DEBF6045ABF788A96956298CAD711AC7090D79B2FE0682DD6F38A14E03AB85E31131CB34B5CD610A146455F4AA1896B418291A9319A5EE0729FB849F7E809C90323B06BFA23022B2B0F916371B196C58446CD89D7A6404C3B9191BDC49121463459B91A69F9FE2F53B89ECADF9AADE9BD3E4CA36332C3A94B975998B409CE77022C435E7DC3A6334E8AB1D383CC39FA5ADCF38524A133412C7ADE93012AA5724709CA5FD1578B56C9779BD87E6E3FC5BEBD47C4D3077B89EA3DFFDBF61F791F6D222AF053E83D81F240B5ABD26CB2352876CDECF053C273F83DC2379E349262C6F35F338BD1CB7719CF090160593A090324C23EC2AACD0629C6A2000173419595A0C3930D5B03CD2C77CE37D75DDC688DBC91A6659E9DF124849773FFD804396DFBB72293867C0620461F1844FF2096581BE2D6A3232C88F417D9C87F5E3A11F48F235E0A69C67D718593A45EE54B19AC9539A6B922599CEDDF7986ACE43605EFD9D56F5F05DD55D463A88A81069F14ACBB1991276F48D87B14274D93E904DAFE444E63ADA1FD49580627F7100B849EBCBD3D538642042EE49812F8DA87FBFA4B1B9E376F00C6A7FE080890819B7F721EF151D2ACE86B1DECCC46B7DEEBE94B8B2C4B5B7973E443D8E0C0908786491C40687D259DF6924910F01B911E0C0A813FA09AB0816072C23C44CE1489783C91FCAD26B7AFBA000258A2451C59CA3202C70A28782A33E3E5ACA7ECCAA32B26D56B1B6C0220B70024696563879AD6E378611FEEBF51E16A73B6C3638D4E22A010E66B2C0A3921F900CE9BBF36D8391197BDA0761428A68599BC995E88C056A2821BA013E06639519DE85D374D063AAF8ED81861B4290E29BE18B4327EF41904E10462F56944932E7C99C5A63940E0606727E3859BC4A345E382CED5EDB61184ECED3F866AC671A87DDA5ECBFBC3ABD0D9F11A7707D5C1BD4F7987E749BA32480B0CC208D7E54FB83DE371D8ED3C5B2E3428F2C6A36D7DDF59093E0FD19577BC5C83BC600A9ECE521F40F711D47C618C80C9F0F4B25BA5B0E36EE708D0D9D466255BB912245959B5B6709D04F650658FC1DFE4D9A296115C992F0BB50D76DD440C896DA19088B15DF42A7CD216C0E102F694ECCA1AE4F670005ED3CF783143C92FB503F5285FDA053C49EB0481B84374EC528AA08F289F7C17C0FD288B9CC67F20549A8DC642468EEE06B6056FD95B559FEC78F409599885BE14F846B20DAC8A31B3799DF8DB5F2B9CF447ABFA5E79EC1BAC3F7E4C714DF49FDEFD0213C018E7B98E508FE003333EA15997345E41173072B08F2D0606FE6F7656DF70F6BBD5FFA7345EE47A23066F7A0922F7C10B0466165C59CE29BF02D922423257FE0158435FB8B2AC9EFC2B7007292F69079B0C3B51BADC304AC08F0EB8BDAA1B8A07FFF45637632AAFD81B545EFBA81EFCEBF0FD7CA202CB87E8D824862AC515C94E47D6A3EED01D98794E9CFD86B5A6695F551D4E3C87081242B504CF74B92F12635583E96509B0BE12BFF0EFFF6A752931087EFF819987AA7559470B6EC6F2484C4A51F0F47912F62CCFBEF05BB47DE106A38357F2BE71126FD3FCBF90E7CA3C9F74EA5F6895C4F8111319892E5F7604C27C7611D4695A049EED1DFC9B94311CD39B29E557E5FDE17E51A0B70FC7E27D7E44C39AF98DFDFC7D15C2EC9FF7D727DCF953272B2FC86925E93C9FE45B63FF0BDF2BBA716BC2F52C50DC22865CC74D9872941586AE22867180C06C333A222260C0683C1603018AE6062C26030180C0623366062C26030180C0623366062C26030180C0623366062C26030180C0623366062C26030180C0623366062C26030180C0623366062C26030180C0623366062C26030180C0623366062C26030180C062336003141314C156232BBD6C8C4A50E0C83C16030188C3202EA737C5A6DDC5121264B5A8C41D45C2975DF190C0683C1609419702533AFD118562126959B8C0154322D75DF190C0683C16094198860FC6155BBD1AF424C9A7B8D042AA396BAEF0C0683C16030CA0C44307EDDB6D9C84C9EE78D943CBBD4102D7DC69552F79BC16030180C4699A2B9D7D8F952853762B2B0C9F42F79B1D47D6630180C068351A68003ECF2567707D8E75718A26DB331443FFFF352F799C16030180C46998288C63D2D7DC6E12FEA0CE3C1F93F252493E619E2D5558668B47C4BEE2F757F190C0683C16094398870FC92C84953FB6623BBBADD18FEBADE18FDBCC6106BDA8D541BFD1DFC4AE0285BEA7E32180C0683C1984020F2F11B6A9391788DDA5C841353FB6DA9FBC56030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030CA1B976F0C8A52F7A19C71FD4ED21CDFABB746789C19C571EAC6A8E83D9913557BB362E5F6AC58BED56AAB776445FD81ACD87D7E545C1DF83E9405747DE87BB1FDCCA8D8B8272B5698EFCD88D5D487B62359817E957A6C188C72C68EB339B17EF7DD3DBF6E6746F4912CB83114CE7ED7C1B5C15192113951B9DB9211CBB684D796F4A5C5BCCE21B1AC7744341DCA89FD97682C86831F8B3DE72D79BB82E41DC6BD628B21AA760C88FD67C79FA23E7B6B54F49DA2F921195EB12D23967998A3453D29F11D8DF3C2EE64D17FC798AC21FDD34C7370E0D228AD47D605130647AE8C9A8B69765B46FC737D5A3CB1D41093E71BE27FBFB3DA830B0CF1F40A43BC5D93164B69B1EC3C970B74715C1FFC5E341ECC89E9B569F1F812434C9A77F7BDCFAF31C4A2BE8C387635D87732180C0B1D4773E6DE7E74B1B5EF26517B649121FE5D99A67D998DC5BE3B7C6EC03CB4BC59453262B1D5C7FF8DA03D4432E8B9956931A3216D1E967070BB742718E5D8753C27DE6FB0E4ED037999373F25FE5E911473DB9362FFC5F1A1840F5FCE89BA7D59F1654746BCBA212DFEBAE4EEF7F86D937E9803C39C8315DBB2620B919FCB01CD0123A6387879547CD39531898797C5F4180985994D19B1E574704401A7860F68D16101165B98CFAFA653C49E78084806A39C70FCEAA8F8A8395374EFE36030A33E6D9E544BDDCFBADD83E29575E948C8885D7B94C8DA6BA478976CCE8A5DE7FC8DC9511AF7D9ED19F1D0C262EF4A89A7971BA655E8EA40E9C7DE0E676E8E9AC415EBE759D21F930322236EFAE75F9569D392B2FB3C1F56CB1267AF8D88B53BB3E2EF2BD516071831D8312C2D41F4A3FD484E4C23A133C9E17DF3BA33E2427F7C376918387029679A91D7D11C6DDC9D153861411894BA5F8CF2C1363A604C5B5F5CE1C372F9D21A43741E2DAD023871A15F2CEC1A322D25A52426F98312E4D17B7519D1444AF9B22671C095C7BFABD28E0A780E119713D7E2B9DFF75D1C150B7BB3E285D5E91F59D7A39A0358993E684C8BD62359812BBE528F072340EC3B3B62B276986D5517C68B6BD2A2765F30568CBAFD59D32AE27452F98288D0E909E26B727D6854341FCE9A96299891F1FDB8E2C289F13B22687B2F4C8C7160848F9E1339F18FD5F6FB7C2A1D5A70CD5ACA3EEE3FDD2FE6B40C9B169C5213931FAC49A48C5F2542574332F0BA86626C3F9AA5FDEC20F388987CD69611C762484CF65DCC9907D3BF2D2BED1CC0DA047207AB4D9C7CA1183ED17BF8B678BF3E25FEA2B1E1717A99D39612072F247D2D88CBB79262FD8EA4F87B45CAF65D0F2F4C894F9AFDBF6BBCA0E7584AFCA72A5554103FB12425E6771BE2CCB5D484180B46B8683F9414535715DF7B93BE4B896756A4C4C65DA55D6B5B0E5D15336B07C403F3522555843F21270BA0180DD17CD01037EE781FA31B7792A2717F52BCB426E970184B898F49E6ED3F1F2F9977E4A2257F9E5A5EFAF1B774037C1F0DD171187310AFB16268A275F755F1765542CB14873BE97FAE4B88BADD03BE17C3CABE01F1EC8A84FDE25B9012B3EA87C5CE13B727C4C25BD13B209E5A86F1F8A9209E4CC2F99DEA11B1F5E8C4180B46B868DC33209EAB28AE20414C9E5E96146BB694366476D3EE736246557FEC8889452092E283BA61B1E5E81DA531AADE39205E58652FF31EA1C3D8CCFA11B1E378BCF6F9BAAD8366BF277D179FB9F8EBE294F8AC69387663C5D044D7817EF14E4D4AFB8EF0C96529B1B03B214E5D49682F884B371362DDF684278BC981F3FAEF192F38773D2196F626C4DF96161F8F07A8BD5D9D14DB4F96FF5830C247DBC184BBC56467694FA29B0F5E111FBA584C26C9D3F3134B0CDA3BFE1AFC1760117E880E44935C1C3AD1A7E75725698C46C4F5DBDE427CF1730DFB12E2C5D52E1693A694D8772E3EFB7CDF9911F15973C294C76EBAE12FF3AD2BF8BFBACC072CC07FA5863F7F32074BAC39750BCAC0BFBFB23629EAF62404E74329036C3D3E2266D467CC45A4434C104583689A7D17FCDD4157EFCD9270B47FCF23B43811CA7CE27AFCEE5B8306F2B9546CCD9A9BD38E98BC538B312FFFB160840F371F93E72AD2A2767F697D4C769FBC2D3E6E1C763C403D464AF0C3C68C99F6003997FC34F8CEADDC9A16EFD78E88A797275D0F6E50A2DF7565C47905E77CE4677A79AD832526863E26DDC77366448C53A876DE3918A1E6F37BB2D67CECB71FEBAADD29012B4CE5AEC44FE600F94B3E6BCD887FAC325C75D493CB0CB1A877E205489425FC1293A09C609998DC0513134694280762827E22BC16916B41BE17D7A588067A718DE16839811326F291ECBFE87D9CC62331D9B03B673AE33B923422251F35A7CD08C220927122ACBA627B56BCB4D6702488D0111F35A5C5C14B1C423CEEE19798A0C1DCF665A7BFB036262677C1C484112598983863FF99013AF9671C4395213FDFA84C9B594FBD3E77BC111324345BBC396B5A43ECFA0C676024C0DB743CD8F582CCDFF37A9CA38030076F55A7C5D600F36B314A842088C964B929BB7C2C46262677C1C48411259898B80399719D92BB4D96A1C32A0A79BC1193B33747C5B75D19D36FC4AECF905948677036845C4B6D4772665659BB6B24F899E0DF3B4A9C7387110082202668C81A8B54C157344D774C4CEE828909234A3031710752C37FD090B1BDCE9908C4E424C95EE4922A9EA9D66A48D4B96157387380DC4DEFD31C38AD018C67D321CE103EEE11143181E7349281EDD3ACEDC0C4E42E989830A204131377C0CFE1D3567BA5381188C971EAC7E7D41FBB247766E91092E1350125DD1C8B4397ADD2097F71783FFC509A6252DB89E103411113BF4EB04C4CEE02F7A9F02E7FC28E98CCB3EE52379FD2ABFC8A94F65B4E8D0A9401D87D6E545C0F2863E2C5FEEFC5D66383A2FBD01D71EC4A70C2E1CCCDEF45CF49EAEFD19CD87B21A76D9563144794C4044A167B7D515FD6B4B06E3AE66D3E9998941E4C4C1891C10B31C9577744DA7AA79F837398AE136CD4C40482A69514F3CAED19B372316A3EA83608571492AADA9B331DAECEDDD2EB1B8A28A26A2A1CCBF05C8C21EE4A1F72D880CFAC30C4ACA68C593F686CBF1653BFD66E1D123BC7241B02210171C438BEB1316D461AA09AF3FA5D597156B3EF00BE1B2505E652BFA75727C49B1B47C4ACC6B458B2252BB69DF1A7D0769DCB89AF3765CDF178716DDAB4147DD79DF5E55C87904E5488C5772FD9AC3EEFF9B987625DBF6D506C8B20D1DDA5DBA3623B8D650DED93155B33E2EBF621F155DBB0A7BE22E4D2A9844154C404D7215F6DCA9804222F5350C97C35F50FE4D3E9779998941E4C4C1891C10B318117F6BB7569F37EF17552680F2FB4DF9CBA4EB051109393176E89AD275362CDCEAC98450B1CC5A740B6DC12283911366C12C4CF43D1A3E01608C60185EB2C5847E02CF6E472FD7EFCA45FF41C64EB9CDF39242EF45B9BF4329D4A579222453E8042E18A9F7D81080A8885EEB8224F01EA1C8D4D8284B1C5BD3CC885CE73A1AC508F63ACB31DD62A7224749F507B2E043C88D91705A5D975ABA19A8A95D6E4B32B9266165E54810D231A20DF67903ED40481F285429FA4D057B374447B561CB7517051101314FBFCAAF3A75640AC19D4E259B5C3B98A2E1393D2633C10939799989407DC888975456398E65754BA5DBD3D630A12BBCD643AC16E5577820D9B98EC3F47CAA377904EF45676C1A048C058218BFA11EFD378424062235FBBE59CCA1B098B706A0CBA5C383276C272B1E7BCB54971627EBB3A5D749E4134E7B4A7B5AA16436023A9959D7507638DF5A0336708BD7C795DBA68D64790155886BC3CE7C2ED51D321EEE3968C696972CB22A9D3D01F249E5AB92D230E5EF64F502EDD1935056CBE9CBC9FF58A3D0C12DE7A38571262729AD615AC92536C423DAD505BC3B462D93D838949E9516A6272ECAAF57EBB83317CEFFEB9DE1018D7528F15C327BC101328CE7C08D68EB339F15E5DDA7671EA3AC186494CF69CCF89B91D29F10C323846506B038A0FCAE49B4D19D17774C8B1BF0D072C2B86CA09D86BFBE7DA84D872CADAA43BCF8D9A568662F38C7723F700E656756CFB4EE6CC0AA976CA1EEFFB8408C1298DAAD055B4269E5C6EBFCE9069D3ED19C7AE7D6F5ED7C0FF298AD2EC2062B0C6751FD7178EB81A5B41040756A8A008F4332BD2A27A5FF4C404046BEDAEAC19ADE1449C9EADB00E3F76CF6162527A949A98E03A73E9968C6DF140C884F7EBD3DA165A468CA04A4C90EE1727553B85A1EB041B16313920CB734F591A8EF2776A38217EDE322CB61EB3F7418003EA4B6BD2A19CE25F5B9F10DBCF58F370F8B215EE6867D9F8C7AAB46838A0BEA1411E9E76A8328A31C715C47645D273F9CEF76642A5476C7226E04A60E576E73586B5F22DAEC996453BF710DCFFA93244F7093D010DDF17587682EC138849CDFE6889C9B5C1EFE9F7B266FE0F278205A58E9FC15EB07B161393D2A3D4C404D8723A276635A54D72F2D862EBBA18D64AC803B81960FEAF0CC463BC183EA04A4C807CA21B3B657AD709D6FB260D839880442DDD6C09F9A849497EEC60A559D83528CEDF2A7EBADF737E54BC57676F9ED46DA8C6FC61DDB0382AA3632EDEB67C59ECB257C2DF62C9E68C5294CFA5DB1679786CB1735FA6AE4C9BB52F54D62514014E3F76EB12D78BED0E8994A0145711712955697608EFF7A8FFBB154F6FB05AB9D522516DB82684E2B7539A611193E64359F1DA06674B15080B88231C9A4FDF601F132626EEC0B534FCDA16F466C5D7A4676039C52105D7E2B0AA947A9C18014087981CBE626D52BB0C800FCCB7EEDBBB14CCD96110937CC1A9C91E228E1E97153061E5F0D2FE26AB8F3EE8E28808A5F0C68684E83B599C982054175607380D4389E2D9A83501C74AC7E7CEB74E0CC5FA0C3F9F7F6F4C88CAED033F7A67156DE6672A8A3F0FF3FF594BDA51398C05D601EA83D809AA42D2B36C8BFBB54B21100AFD8A8D7F099419A2899C9C8C379FCC99272827DF9DBC03AB59FDD4E3BCE7E71E63EF7635849F5940C44D251C1B02D629B3A6355729F1D822AB1AAB97FEC222B7B82F23CEDDFA3E32620207F8FF54BB5F9F61EC71D5E776F5CBC4A4F4F0424C702D5DB5371A1F0FD4E141841D939132840E31B93E386A865A3A110958292AB6653C9BD5822626A8EB006B89D389194A0FC20C571C5008F0F7683994132D87DD5BC3C19CE9D489F0553767DA294B93A653E4F5C1E28A01D10808AB85250ACFDE40C275467DDAF61A23EFCC889055B3CF63FA069378CF912171E242FF8FDED77BC2DED116CF8422D9A970C2EF75F12FF941919220FBBC4DCDB91661B17673072239B723632B90AE0E8E9A8AD8C992833E638DC2B974EDCEAC68F238EF68F507726618EE6B6648377C96ECFD96408EBC5E63616DC33FCB899082B4C01F68FEA621B17EDB906B5FE1F08A79724A111E3431C11DBFE910ED620544356010DB2D1EEACB3031293DE027064BB8937517BE4208FFBE36188F3E33C629748809E0CD09364D27216F1B35686272F01209F946FB4D64095C3AD1F6661C733CB861DBE99CD9AFBF39F8B03C48CAEB73126AA73CF63DACCCAF08B78322B0F7333144A342A89DE95FE2C117224F7A90CCCDCB73412A616978D4C1BF04C2CF69EEDFA9CD389ED6E18C092B0E148ECEBCE3AA68D3B151F17655C2B460D891135862D6794CD1BD93F6D434877A2CF922657E1C6B8B21486272F88AE5D3E576BD877D8935DCED51913331293D609D40DE24A7B9B542D33302E1E1A5EE2F631C43979820041309C19E5C66FF7BF003F0EA041B343141B4C81B0EA67C28BDCF48D04059FB1E43222710B2760AFF01525AC803E3950085454C2EDDF9DEB14AEA130A572EB056B809A9C2F6FCEAB47982F7F26C083537FF12A7425D50B4B028D9114558A270F20BA2D058F5CE41F1F78A842D310171FF7A9337DF1D64417DB6C27E0C313FC845E3B7CFC5C62B0862826B40A7B0E0C2318125A9E5B0F76F6162527AE0EA0409259D2AFC9AFE4C6BD36684155B4D18DAD0252600FEEE352727D82596C9DD8B136CD0C4044AF0E5B5F6CA0982B83AA0BB505C5741A13FE9B061E143B2D96349F4306BE554EFCDD9467C3C24AF5C4EDF70EF679E3CB8F997FC60394014CD366FA4C7AF7F49E3C19C786AB9BDE50173EF9524B961EFA9DB6266FD30F53565BB7F6039F4728DD57AD8F9EA1104A1E960F0A1904110137C1F949613B1CA5B7D5E5A975626104C4CE2014459E190E1660D43241EE6E298078BE4D5DB492B09E4CD91D87C27A3C4F0434CB0593F737082C566C502EDF190A133686252E3F03C7C13AC294E099D540165E8744AFFE706EF1971C32426B02405E16782E74CF3E05F52487ABE684F8BF3FDEECFF6E35F02ACDB993549B15D5FB02691DB26A8B95FD435E478EF0E6BD9710FE4DC8D9820BAA9ED48FC880942BBE1A7E394AB247F9A4696E1D5F4B3F81D953E323189075016E11D5ACF0FB83835E3C082AB61F8EF21E3EFB75DF6EDAB8E9498D3322CE6B6278BFE3BA20991A20257C7C8C7C4E1C013007E88C9F5216F4EB0702C755B4C4113133890DA9DDEF209C5824C210ED2316DBDBDF5282EC4C43D9F89373F936A8FFE258563FE764DDA2CC2E7F45C4FFE250EF94B6E0C594EC98F3A5C31BD4D6377F0527073BFB26FD0F14A0B82FCD8D5F22526C87F03F3BD9303B8997490F6231264218C5FB58F4C4CE201D4D44298AE5D81D1B0DA83F3AD68431C9C70850C7D745E631D31C609FC1013202827D8F14E4C10F1E294DB252EC40499382158EC2C0A5EFC4C54FD4BF20DA7E55617BF025C117DD0A0EF5FC2C4441D7E88099C57DFACF696AB049990750A7C024C4CE2837C28B8DF8AF4BA0D3A0557BDB0A46C09A13E152306F04B4CE004BBC4212CD7AB132C1393BB0893980035FBE06459FCDAC9F4336975F63381D545C5BF24DFE034B76ABB33E941E8A89DE5090AEE1D17FF122626EAD02526389498D637876B2CCC194ED750EAFB15CB54148289497C00AB26E4EB4B6BA329F360D7B0E760854542371D2B1C23C6F04B4C80CE6356322BC74CB02E4EB04C4CEE226C6202E7523323A7939F8943EE8DBE136AFE2585A407F7CD4EFE2170AE7BDA2653AFE95FE2F2FB4C4CD4A1434CF65CC89945111F75B19AC132F751B35A7E9C626062122FC0D9B9625B56BCB0266D5BED378A8677C37A021FA70BFD6A7E4B8C182308627254567DF4E2047BBD7FB8E8739898DC45D8C4E4F0E59C634560373F13649055F12F291C77A4693F60430A108E887053BB75F43797FC2500131375A81293ADC7EE882FDA3DE62AA9F31E8DE6042626F103C8C97A1A6FC85210D052594FA0BB5EDBA0968389117304414C549C604F5E1E6262E282B089C90F7E261AF94C74FD4BF2ED653ADDC0C256ECD9082DFCB051DFBF046062A20E156282F0E8AFDA873CE52A7963A3BB4F91573031892790CD1AC413B58E70058B120398FB308A923A358CD5C7CD9089EC73521608829800B86F7ED78313EC96E3E5474C9048A8F9909537653C10130095669DFC4C6623857C91BA39567D9C8CB27F49BEA12AB55D2654F897FCD3877F09C0C4441D5E8849D5DE9CE977B4A467900840D2F9044B6B034AAA7AAF5A7D242730318937E0E381F40BCBB7664CE775D4678255154ECF6E6DCAD214C9BAA4F9E78FFE7E99E59F8484886ED6984932143DA8DC548C12232862626582CDB83AC1AEDD362C4E5EB8F59367C58198E01B9A0E65C5FC5E2BF6DE6BFBA22323DEAAB14E0B76FD8F1B3171F33341EAF35D4552C8E3F75E5DEF5C1CCFA981A022132AAC36639F0D076947FF1297FC2500131375B81193A797A7CD10EED53B32E21F2B13F477F6B581A0405E24650B137F90993F99988C0F20C33122EB205B21EF601D756B2D0752A276D78068DA9FF8D1DFA3E617721A41C6BEB8C6DDD91E965E447EA9D4E462C4145D07FAC53B3529C70DFFCADA94B968AEDFB6CFCC77AD7F4434ED4B8857D7256DAD068F2D4E898FEA0744DFC12B3F7ACEA59B2362DDF684F87B85BDC07B78614A7CD2941407CE275C17DDC51B09B17A6B423CB3DC3E1BE7BF36A644D791BBCFBA743321AA76A7888419A13873BDB22E451B30216EDC76CF6E78EE7A422CEE4998D563ED88C9DBD549B1FDA4FB58D861EF9911F1415D5216A1FBE93BFEB12A256AF6A4C48D3B77FB7BB53F2136EC489AD7729334C701BF379DD6DBCED33FEEFB996B0931AF2B291E5D54BC3F4F2C498A657D0971F596F3F89DBB3E4C6397A453967DFD9A37ABE8FDA782CB32B974D32DC78AC06FD3F7EE3BEBFEBEFA3D093A29DA592352E6FE68D8A73FE776683B98A04381FDDEC3B7BDB21665057032B5FF3964BF85356541D78838716938D07E6E2699F161ED806D865D8CCF53CB5262CDB624EDB1E0C768EFD98498D598B47DFF64FA7BC8C9E603496F870F920398CB1757271DC63D253E6EC2DA09FE7BC6130E9C1B16159B47C44B6B92E638DB8D1764D97BB5295F72911113B4EEBE6A16227322262FAF4988DA9D03AE93BDF3F86DF1099D6AEC940B36F52BAB07C4FADE4B3F79D6CABE01F1EC8A843D31A14537AB7E58EC3C71DBB51F272FF68BE5BD83E2691B218F6F7A7D7D42B4EEBBFB4DBB4FF63BF6DD6FC318D6EFBEE369C31C3BDF2FE6770E9ACAD88E98FCA77244F41CF6F6BC62387CB65F7CDD36241E5F5CFC7BFF4A7F3FAF7348602CF3BF73887E672EFD8ED3FC3EB220211E5B9870ACBAFBFCAAA4A8D9F9E3BE6F3F7E47BC5B3D220BE215F91D3AA9D7785883C7CFDF342BEF3EB23069FBFE7F6D4C88CD47DCD791572C6CBBE6B86EDEAC4C88EDC7DCDF57B97DC0AC446DA7789F5B9114D51EC640158D7B06C47315F60A12F33A99E6C5C952827A505368BDCE6EA63D7ABC3FF03E6EDA7D4ECCA8EA7724264FD2D8ADE81B0C45296DA3F9FBA06ED89198BCBC3A21EA76799F1FCCE50BABEC65DE2374189B593F22761C0F6EAD8E5798BE4D247BFEB6D47E9D620E5E23B9DEB2575F2E326282EE43B7C53BC4329DAE72A6793C095CBA9514EB76A41C4F5F4F2E4D88EFDAFAE9447557805CE94F8AF5741277B59834A7C4C10B294FFDC0C9E99915CE1693EEA377BF69CFD9A478BF3E656B41F0DB5EDB90129B8E7A3B4D9DBF91144B7A932E169394D871CADBF38AE1C69D94A8DC9D32AFBBECAE4E60A13A7AF1EE3BF6D218CDA84B99D5928BF5EB599ABF2F5B864445EF1DF16143CABC1B2EF6737F5B9A12CB3727C5B5DB779FDD7524699E388B097ED3BFA42625F69C759FFB0B374668EC52AE16935D67F4C76E2C9675F53B5F1D51DFF79F777F5FC3DEA4787299BDE2C5FE68DC1F5CBFF3683F9474DCB36E0DF33365A921E6B4A5C5BE7346284A61EBE1AB62A6078BC9DAEDEE6B4407FBCE25C5474D2947620239D972D0FBFB3197B002385A4C48E61DF0B076CA1D37EE24CD2B1F44DFD86518CE5BF71BF7F1788D7B04E56392879B132C14FFBB352362F7D9F48F9E576A1F1344847CD29231DF13342979904E9B1F35A5C5A1CBF1F131019035D1CDCF6477819F89E95FE2F0F328AED77BC43A31D6EE4D3B921EDC1B17D64BA9DD9FB1F72F917E29573CD457611F137538F998786988EEFAB8E5A71111E76E8D9A7F77D4C3B7BB817D4C18A8CE8E847E4E6BE0251ACF260E1B1EFF089A98B83BC1A64C07BAEA3DF122269707ACEAA87EFC278A358C2BCCB5957BBC472844454CA0303E6AB2CFDC892AA285D56C9161F11907B2F125918D83672D33EA96931947D203F27AE092D5FF6B8356FE123BE50EEF7C14E6F3F24D4C4CD4E1879898B94A683CB714E42A39777354D4EDCF9A8A1C4EE188C6C3FEBE7C8733BF1662BC1313840AC389DDCB8121081CBA3C2A3E6ACED8FA0032312923044D4C007854A37AAF5DE4C6638B92E2AB8EB43855108E5A6A6202EC3A973313C521C11814C4933E1A7E1FD556E15F807BEFD3D7E3474CAE9050594C84C02E9A08EF47F81F7ED6CA7D92B1CD7D32C54C377F57201CB99C3185889DE50C9598F34A16D62A282FBB9F85F0DE74CCDBFA6362A20E5D620232FAAFCAF48F72951C2725BA90D609F672DE091EB265DABAB419F1A6DB472626F101ACE22BB665C49CF68C6965C6B8A00A30A2EA4EDD08AFAF4C4C2610C2202628D48514F4764A0C8E74487BDE7732172B620240B0E2F487E264BE1A097B5C7D6C3B31248E9F5773068C8A9800F574B27D6EA5839F498B65D940B9F3190EF571100A0E419B7FEEE5DB59B16473C631891BFE1DA17D585B505C76F94B902D1642C9CBF7303151870E31817240198AC26C9B0815458E9A6259816159416A7A8492EAF49189493CB08DE400E61187994299615A86E9B001AB33AEF0C278371393098430880980B4E54EC20EA401996091861C3F1F1762120744494CB6BAF899E06A0B05FBF03E584526D98C27FC4BC656906E3890B5F53331F35DACB194D57F682EEC14FBC30AFE2500131375A81213AC15E42AA9DCF36305709CBEF163521C7604F3EFD4FFCA3D7AFD6762527A5C1D407D1CFB6B7AE810C8D5CD27C391AB4C4C2610C222262802F79E93132C32C136664CE57A85C809880C13130B511213284C6CF6877C38FD9AFE251D999F54F88495C58EF4786D20436B3DFA97004C4CD4A1424C90C7E4991549F38A6F6CB2BB4366D5E98CEDEF82647ED89411072FABFB2478212620D14C4CC2C3E91BA36611CD8717DACF010E1B389084F17E262613086111938B24B496B8648285E90F3576769E1D15CBA4E369B911930BD7D4F32A44494CAE0E7E2F966ECE9A572B7EC843B1E27AB8168345E4211F09EB54FC4B002626EAF04A4C102A8B5C2173DB468AFA129C2762FA4D977D7148584D706DB87E97BAE2F0424C5062A16A0F1393B080FD0C1FBC071D88C1F374B884937C18EF6762328110163101DC9C60C1BC515F06D700F8F3618753FB78202697EE7C6F3A02227D37D2D4C339ECABF68440E2ACB337E2E7FC9A47E3C19CA9F474A3913077C50AF3C16B1FC500FFAA497A54FD4B002626EAF0424CB036B01E3F4702B513F649C49A0F65CD0CB176CF016981AFD25EC5B5EB464C707D8428B2C683E11C36989830316144883089099C60E73A38C1AAB4B8131384BCE2CE1D793E0A09169291BDB43A2136ECCA08FC8C9767454D4C70E582E80A9DB2E5500885A1BF63012161E75CEBD654FD4B002626EAF0424CF07D1F351BA2CF25DBF0C91BA326297732F7E72B8DABF4D10B31413D95D6C34C4CC2021313466408939800B5FBB3A6C0F09B1B24EEC404240127C162BE1A8842C2BFEDBBE8ADEF511393E3D772E2E3968CA3C5CA893C2059DA459BE27A082D7CBD52CFCF44257F491E4C4CD4E1464CA008DEAE498BDE13DEAC7E6D242B5E5A9BB67DDE83F279DBCF7AFF162626A50713134664089B98EC3E9F13331AFCF9198C076282D067387ADA15307C6D63DA2C0BEEE559511393AB83A362E9968C969F09CA93AFD9612F08305FC875A033FFAAFE2500131375B8111310C48A6DDE85FD999BDF9B64D5C96A825C3F4BB7643D5B114B4D4C0E5F19151F37DBEF6F2626D6BC220754587E3E072F8D8A594DCEBA8A894999206C6272C1C509362C62B2718F758560F74DFF4658DBA9E08418F2964C5B6F2FB8FE49A4A5CBA3D08A9A9800487E3555E3CAC5CEBF248F6B83706C56F7337940C3BF248F95A4449D880272E8ECBF14DCD8ADE81D72AC2E3C9E8909D6C373156951BB5FEDBD1D47B3E295750E56987C68A9C73D586A62B2E34CCEB4F2D87DCF0FC44481488F3762E2169583861C3620B1082D0EFAFDB0B041EE3DE0502B07E3D9EC23911F2326089B98006E4EB061101384ACBDE0700A9CB6EEC709C1FC024E776659789BF7C1F704E4C5CBB3AE0F8D8A95DB32E649D56E4E2024779F0B4E08E3CA45D5CFC4CDBF240F901E553F131DFF923C902BC38ED4E5E7BEEF5430821395A0BF6E1F36EB21D9BD0F6384EB32B7679513314192ADEFBA9D6B4F618E16F67A4B555F6A6252B5376BE661712226B0987697B1C5045157F37B328EA41FFF862BAF430112FF3C7045843976924748FAE7F500C88831A2202620135FFA74825525262043E8F70336CF830258B625FB935C0C3A38471B16913876CA307F75042753AFCFC4559453F8344E67416E408CEBA78A7E266EFE257920A78D2A31D5F12FC9A3E5508E4E6EF602EC499BF0661DF41CBE23FEBD71C4AC0165272C51E0EE7CBFFB3A2B276202607DC28AE8A4CCA148BC28F3521293EEC383564D2987EB485C6FA0E8A58ADFCC782326B07EAEDC9E31AFE19CC8017299407E5DF2511B692C2043E007E76499C41C4CA703DB0E0539CB8829A2202640EDBE9C78C98713AC2A318105E06D121476DF85BF8749BFF3987F05D57AC472F0B47B174AA27FD898168715AE251A0F644D4732BBF17A6AB995FED98D1478C53519DAABE2670201E525F9D949F89928E633D1F12FC903D703B862B21B3B283784A86FF3E96304ABC0371DC344B851BABE383101794381422FCF2B3762826B5C9CB01F715026B8E28365E5820B718B9A98DC181A15C7AF66CC50FFF7EB466CAD973F9008FA46107BD47DF2FA0E376282719B498468A702D9091BCD87ACBDE53416D8E73838ADD896157BCEE7CC049A4ECFBC7C2B69FEFBC51B233FFA399438B04A5664696CD3DEE6A035238E5C89CF783134111531D97BDE2A59AD9B615495984019228F88A3D97191752582305FD4F0B8EED1110FC0E9014463E3EE9C79527212BE8F2E4C9945AEDC846F214C67DAF5F65606B3301AFD3B88011CF3BC3A113A014E632A7E26AFACF576A78EABA9E50A7E267EFC4B0044508008FEC5E15A0AEB0299891B0EE4940B8F5D19181528F8B8A0372B9E596E4F4AD0E080ED351366B91113A0F74456BCB6C1702489F0BF72932F7E880972A660FD417E7CD6EAADC161FBBD3A433CBF3241E432E5B85ECD74F8A66F4586644870C4047B1F5653F85578EDB76E83E573C3CEA4D877CAB9AE17C6F2C3C68CE3DECACF2B4A04C0520C6BD3A70EEFFEB8890E6EF5C3E2A3C6E44FE6E07DD219AFAC4B3BCAF17C33C3D0890C5D09C1BF851131A22226976E7F6F7AE1EB3AC1AA12130084C3F4FB70B84280F90F77C7D36B33669D8F4F65B54CC7D66255CE05A9796EA57DDAFDFCF8FD83845B9D62081DC8063CD09DAE563067CF5558E4AAB0EFF09C9FBF6958F41CBAADF4CEBC9F899BD0C92B0284407B8D6E6939EC9DF4E09B9141D44F39F5D5DBB38E7E26F9B9FFC7AAB449823EF132EF72EE312F18273C7F9287313AECB1705D39121358F4603172522CB8E28562C4E9D8EE39BAC40424150E9B4F2CD1CBA5E3A5611D4101F77AF421CBC38D9844D9B0E75F5A93146BB60C888B37866DBF03FE4050FE4FFB0C6608630E7040F41AF9C88839A2222600FC3E70A7FC8086132C2C12B0809C542026FB2FE6CC103F2F6C3BACF6D8A29429500F5F522326B0C8ACDA6EF999A80A54FCFC134B92624ECB903875DDFB7B31B69FB77AF33379443AA77ABD4A82A32E22A1BCF899C007649D46DAF242E064F76E9D5E987210CD4C91BE22AD54BBA51C8909B0E534CD7DA5FDD51AE481154D910B9C98E0FF51FA22B4798655A3C20A7D56BD566DA7B97C795D786B5059562D4E8A4F9B48565D4838FB8CD15EC61593939538D2BD264B1DC02AA6629566C4185B4F44474C60EDF8A23D6D2A6BD5C567DD45673D391116A2E99045861ED4C86AEAB761E3BE5539229AF7DED11A3B28F3F71BD25A0200F3F6FAFA11B1E38C77C588AB2CE4007962A9FBF39F542CAE8750435872BC5CE5F9F12F2904141DAEBBBC5880822625B002E0A47EFABAF7EF882F3131041225EA3E1F3E06703477BACA7B4C8E17FC768A3D4397988018BAF926F8996758CD60C9DDEF31796221705073720E8EBA3DBC2025DEAB1911BBCF243D386AE74C2B51A9887F2129812C4270C581007313314A8CED2747C4070DF6C21B138F50D7CE00140550B53B255E589530AB94AA2CC0BFCBE25F708852791FA26E70FA7E65AD951E3E2AC504418B137BFDEE215FE3862B10581A74C8C9B4B509B1F9A49A4241440BAE37DCAC34B8F7552BAEF7BDE90CE7E667E2D7BF64EC3B11E6396D5D740214FD872284754F35891B888993891CF312C401612C7005F1BC0331C1DEF35B31168EC6506476EB0AF2E7AD9AB4D8691302FF033199673FEEC5880964C6DF422026781F48E4E7AD696DE7D46D6772E637979A90141293778998EC3AED4E4CAE12D9448A84FF48FFBAB0AEC99C1AD602F60BF6DAAE005327306280FD6747CC89B50BC342FA5F4430A884C139BEEF5CD22C04366569D2D1F7A390184199C107001EDE3AEF848975FD8EA4787D7D824EB229ADAB24AF0D779D7078847560CBA99C387F55BDBAF058B4933242B9785CEB3CA8A0605F5D3722B69E56AC49721ECEBC19C7F7408980CCAA9207285E6486749A775C11C151382807369093367A2F7C3D70BAD5A907E4898CCE9345298904218BEE718D104F84D74E5D65FF7C58FE768410A18130F67FDA9CDC27CD0BC6820545E6E4009D4FB8662767E094F959D3B0ED010A7B1A69F0C75A946AF765C53315C1297F2860286244A62071A41F028D3502D95B6AABC30F7B6F119C5047C4DEB3094FDF84BD8535FB494BDA2408515926B126A1AF606DC215DAC11072A6304A8CF3D713660A6164691CAB8C20C4E1DCB97873D6D6C4AA83EE43B7C5976D09F394864D3EF614848587BEC0EA00133336EF369FB1E9E7AF0F8BB6FD77C4571D49F3B40F01897704C1F4314ED8282024508038A5EB282627C08112CFC5D50E4CEB189BBF38F4FF213AFDBC5F3B2C0E5F56232697498120732314E443639E8FFFC655CC0B6BAC682055EB9559D4B1D3CA023CB6DE0514CBC38BACD4FDAD215C571CB898332D36783E080A48845F823A492A545C4D4E5D9516B3699DF69CCC6967BD4476D84F5AE50974DE8FC706EB153E3DAA57995EE7055110C5C828C609114E4158B040AA70C819BBDFF17D98137CDF199B08A9A3E7FAC5FCCE215B7F31CCC31B45CA3E6C93195BFD2477FC619E171BA6CCC2D54D271D16BC248673032C51D3D6A91D384251F6D49E5A9614DF750C8993574694BE0BD189284B8171C6DE0E626F1523239019B82285CF107402ACF8977D38C833628EB33747CD905984A5217202A16F507E883C58B635EB39AA4005472E2604AE29A0A87012FCBB7C2FAC0248D0F35E7DC664C39B8E65C569C5704E279CBE9A322D1950BEEFD33B905B05EF7C5AB34181E3AA05B91860463E12C25815027912201411E980F982F91A84A8B04FCFD209F1CD8D0951B96340AB2F67898422CB221412E6E219735ED2E658CD6C4C9BFE06BA44153906E0D40B0505EB89D55FEB6A088A1D5715D715098F57E0B9BBCF83E0E5CCE81A9CB89EABD09FFBE757639C47C477A430711D723600F28EAB0CDC97DF1D776B6CBEEDCA6AF93178054EBE584F502C8860819FD15332DC33C8DA2335FB7226B185A27F405A9940EAF0CDBB5D2CA20D7B064C99345689E3595843C89972F6E68FD70EC2E8AB89D0BFBE417D9FE3FBA1ACA7AE4C9989BB16D39E433238A7E82155C09A0BAB0EAE2FA7AEBAFBDE27E9BD4F2D4B69AF4DD5F60F5ACB08D7EDD8AFE70F07A044060E4F20B9FF54D85B4F2D4F397E2FE60D59BC51DA013A013E5141CE0123E68052C57D294E1938DDC044E6961CC72F7002444AF31DF2BD302B4340410107919BC30E38EDC3AA014585776ED36C502407E9C41044065915E0547EF44AF1FEE3FF779CF07F8574C21C9FBBCFDC43EF3A11802508C9ABCCB576EEEEB3F75E20C51EA1B001D945E4CE0E1F738F7BED6DC76E0BA4A50FB26F207D18F7FCBCA29F17FAC33F19C227065721C8DA8986A811AF15B1BD02690336EEB1AC18F05D8312436D132F8AE6C4853BE6CF7ED09831C90C941642FD11260AB26B9721158414117AAAFB7CF3C9B4682745DD7364C85CAF57439485907779D9DB77C230ADBB9B0E0F6BAF4D9DB57CF8622A90EFC35C82A4E465BA5BEB399632BFB7FB48A2E8BF6F97FD3B1AB24E6030180CC60406143D2C403A275F44F74151416141991FBE9C534A8EC86030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683C16030180C0683111BFC3F1BA1C2C07C1F1AED0000000049454E44AE426082,'1/1/1900 12:00:00 AM','10/2/2022 5:58:05 PM','5/17/2023 3:14:55 PM',null,1,1,'Native'),
(2045,'DeletedAccount2045@unknown.void','Deleted Account 2045','deleted_account2045','挞䜄扢ꑺ疵䱶볩ᡯ纏ｦ�疜諍룯ꁑ','Deleted','Account','US','English','Eastern Standard Time','',null,'12/14/2022 8:42:52 PM','12/20/2022 4:03:08 PM','12/14/2022 8:42:52 PM',null,1,4,'Native'),
(2046,'DeletedAccount2046@unknown.void','Deleted Account 2046','deleted_account2046','폚柪닞调㵡䱹犵宠젣譧疬릣㠍￨','Deleted','Account','US','English','Eastern Standard Time','',null,'12/14/2022 9:23:30 PM','12/20/2022 4:02:58 PM','12/14/2022 9:23:30 PM',null,1,3,'Native'),
(2051,'josh@ntdls.com','_NOP','_nop','275bcf392644b1928b7f00c9903dbd2d94580d6219e9124c655f55775f93a822','Josh','Patterson','US','English','Eastern Standard Time',null,null,'5/17/2023 3:14:18 PM','5/17/2023 3:14:18 PM','5/17/2023 3:14:18 PM','QDQTTY',0,1,'Google')
GO
ALTER TABLE [dbo].[User] NOCHECK CONSTRAINT ALL
GO
SET IDENTITY_INSERT [dbo].[User] ON;
INSERT INTO [dbo].[User] (
	[Id],[EmailAddress],[AccountName],[Navigation],[PasswordHash],[FirstName],[LastName],[Country],[Language],[TimeZone],[AboutMe],[Avatar],[CreatedDate],[ModifiedDate],[LastLoginDate],[VerificationCode],[EmailVerified],[RoleId],[Provider])
SELECT
	[Id],[EmailAddress],[AccountName],[Navigation],[PasswordHash],[FirstName],[LastName],[Country],[Language],[TimeZone],[AboutMe],[Avatar],[CreatedDate],[ModifiedDate],[LastLoginDate],[VerificationCode],[EmailVerified],[RoleId],[Provider]
FROM #tmp_8eab31fe4e4c4ac9a433dfe50e420c06 as S
WHERE NOT EXISTS (
	SELECT TOP 1 1 FROM  [dbo].[User] as T
	WHERE T.[Id] = S.[Id]
)
SET IDENTITY_INSERT [dbo].[User] OFF;
ALTER TABLE [dbo].[User] CHECK CONSTRAINT ALL
GO
DROP TABLE #tmp_8eab31fe4e4c4ac9a433dfe50e420c06
GO
