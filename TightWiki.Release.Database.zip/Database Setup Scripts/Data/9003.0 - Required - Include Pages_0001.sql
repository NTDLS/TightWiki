DECLARE @Discard TABLE (Id INT)
DECLARE @UserId INT = (SELECT Id FROM [User] WHERE AccountName = 'admin')
DECLARE @DateTime DateTime = GetUtcDate()
DECLARE @Id as int = (SELECT Id FROM [Page] WHERE Navigation = 'include::experimental')
DECLARE @Name as nvarchar (128) = 'Include :: Experimental'
DECLARE @Namespace as nvarchar (128) = 'Include'
DECLARE @Navigation as nvarchar (128) = 'include::experimental'
DECLARE @Description as nvarchar (MAX) = 'Include telling readers that the contents is experimental.'
DECLARE @Body varbinary(max) = DECOMPRESS(0x1F8B0800000000000400AD924D4E03310C85DF1A893BCC12103F5728884D37B0E102519BD2889950A519950A71773E7B524DD923AB756CBFE73C3BB3D0424B65ADD46BD45A5197BAD037F64826AAA8EA4ACF0A60DE3DBE76C49BB64ADAABD38E9A55BA16477DC129F8815FAFA357062C901FBDD2E9133F6177DE35393A8308708C91F9CF679C7BE225D1E99E1BEC45AF28B153A703D88205EF9260ACC99AB6E0DDF68DDB637754375864EEEAA80CFAA1A9AA9EDF924BF849CFE03EF8DD9396279F6C244EBE1BE39D7662998D779BA64E9CB36EA91C398D4D974D151B2F3475F37C1964FD97B9CCAFB0C8AEEB9FFB6635D3AB9C4F935A871957FCDD0EFE32C5557EB009FB1A7E30F3BF5F2E0D2B4E020000)
INSERT INTO @Discard EXEC SavePage @Id = @Id, @Name = @Name, @Namespace = @Namespace, @Navigation = @Navigation, @Description = @Description, @Body = @Body, @CreatedByUserId = @UserId, @CreatedDate = @DateTime, @ModifiedByUserId = @UserId, @ModifiedDate = @DateTime
GO
DECLARE @Discard TABLE (Id INT)
DECLARE @UserId INT = (SELECT Id FROM [User] WHERE AccountName = 'admin')
DECLARE @DateTime DateTime = GetUtcDate()
DECLARE @Id as int = (SELECT Id FROM [Page] WHERE Navigation = 'include::do_not_modify')
DECLARE @Name as nvarchar (128) = 'Include :: Do Not Modify'
DECLARE @Namespace as nvarchar (128) = 'Include'
DECLARE @Navigation as nvarchar (128) = 'include::do_not_modify'
DECLARE @Description as nvarchar (MAX) = 'Include asking reader not to modify the page.'
DECLARE @Body varbinary(max) = DECOMPRESS(0x1F8B08000000000004001D8C3B0E83400C445F1D2977A04C9A9C014ABA74D488BF44161496228AB83B8FD5C833637BEC9C9C9240C3CC4E4BC79D1B7F5138E9F812795051EB029335F04C9977DAD76C72E6E5220739AA1FB535DDF3B38B8CFA4DB79A1FCCBFD287435C7A02CC30AE6084000000)
INSERT INTO @Discard EXEC SavePage @Id = @Id, @Name = @Name, @Namespace = @Namespace, @Navigation = @Navigation, @Description = @Description, @Body = @Body, @CreatedByUserId = @UserId, @CreatedDate = @DateTime, @ModifiedByUserId = @UserId, @ModifiedDate = @DateTime
GO
