IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetPageFilesInfoByPageNavigationAndPageRevisionPaged]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPageFilesInfoByPageNavigationAndPageRevisionPaged] AS'
END
GO

ALTER PROCEDURE [dbo].[GetPageFilesInfoByPageNavigationAndPageRevisionPaged]
(
	@PageNavigation nvarchar(128),
	@PageRevision int = NULL,
	@PageNumber int = 1,
	@PageSize int = 0
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @PaginationSize int = @PageSize
	
	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	SELECT
		PF.[Id] as [Id],
		PF.[PageId] as [PageId],
		PF.[Name] as [Name],
		PFR.[ContentType] as [ContentType],
		PFR.[Size] as [Size],
		PF.[CreatedDate] as [CreatedDate],
		PR.Revision as PageRevision,
		PFR.Revision as FileRevision,
		PF.Navigation as FileNavigation,
		P.Navigation as PageNavigation,
		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(0) / (@PaginationSize + 0.0))
			FROM
				[PageFile] as PF
			INNER JOIN [Page] as P
				ON P.Id = PF.PageId
			INNER JOIN [PageRevision] as PR
				ON PR.PageId = P.Id
			INNER JOIN PageRevisionAttachment as PRA
				ON PRA.PageId = P.Id
				AND PRA.PageFileId = PF.Id
				AND PRA.PageRevision = PR.Revision
				AND PRA.FileRevision = PF.Revision --Latest file revision.
			INNER JOIN PageFileRevision as PFR
				ON PFR.PageFileId = PF.Id
				AND PFR.Revision = PRA.FileRevision
			WHERE
				P.Navigation = @PageNavigation
				AND PR.Revision = IsNull(@PageRevision, P.Revision)
		) as PaginationCount
	FROM
		[PageFile] as PF
	INNER JOIN [Page] as P
		ON P.Id = PF.PageId
	INNER JOIN [PageRevision] as PR
		ON PR.PageId = P.Id
	INNER JOIN PageRevisionAttachment as PRA
		ON PRA.PageId = P.Id
		AND PRA.PageFileId = PF.Id
		AND PRA.PageRevision = PR.Revision
		AND PRA.FileRevision = PF.Revision --Latest file revision.
	INNER JOIN PageFileRevision as PFR
		ON PFR.PageFileId = PF.Id
		AND PFR.Revision = PRA.FileRevision
	WHERE
		P.Navigation = @PageNavigation
		AND PR.Revision = IsNull(@PageRevision, P.Revision)
	ORDER BY
		PF.[Name],
		PF.Id
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE