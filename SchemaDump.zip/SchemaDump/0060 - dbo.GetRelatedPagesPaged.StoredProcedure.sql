IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetRelatedPagesPaged]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetRelatedPagesPaged] AS'
END
GO

ALTER PROCEDURE [dbo].[GetRelatedPagesPaged]
(
	@PageId int,
	@PageNumber int = 1,
	@PageSize int = 0
) as
BEGIN--PROCEDURE

	DECLARE @PaginationSize int = @PageSize
	
	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	SELECT
		P.Id,
		P.[Name],
		P.[Revision],
		P.Navigation,
		P.[Description],
		Hits.Matches,
		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(0) / (@PaginationSize + 0.0))
			FROM
				[Page] as P
			INNER JOIN (
					SELECT
						RelatedPT.PageId,
						COUNT(0) as Matches
					FROM
						PageTag as RootPT
					INNER JOIN PageTag as RelatedPT
						ON RelatedPT.Tag = RootPT.Tag
					WHERE
						RootPT.PageId = @PageId
					GROUP BY
						RelatedPT.PageId
				) as Hits
				ON Hits.PageId = P.Id
		) as PaginationCount
	FROM
		[Page] as P
	INNER JOIN (
			SELECT
				RelatedPT.PageId,
				COUNT(0) as Matches
			FROM
				PageTag as RootPT
			INNER JOIN PageTag as RelatedPT
				ON RelatedPT.Tag = RootPT.Tag
			WHERE
				RootPT.PageId = @PageId
			GROUP BY
				RelatedPT.PageId
		) as Hits
		ON Hits.PageId = P.Id
	ORDER BY
		P.[Name]
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE