IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[GetWikiMetrics]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetWikiMetrics] AS'
END
GO

ALTER PROCEDURE [dbo].[GetWikiMetrics] AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;
		
SELECT
	(SELECT Count(0) FROM [PageToken]) as Words,
	(SELECT Count(0) FROM [Page]) as Pages,
	(SELECT Count(0) FROM [PageTag]) as Tags,
	(SELECT Count(0) FROM [User]) as Users,
	(SELECT Count(0) FROM [PageRevision]) as PageRevisions,
	(SELECT Count(0) FROM [PageFile]) as Attachments,
	(SELECT SUM(DATALENGTH(Body)) FROM [PageRevision]) / 1024.0 / 1024.0 as TotalPageSizeMB,
	(SELECT SUM(Size) FROM [PageFileRevision]) / 1024.0 / 1024.0 as TotalAttachmentSizeMB

END--PROCEDURE