IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageToken_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageToken]'))
ALTER TABLE [dbo].[PageToken]  WITH CHECK ADD  CONSTRAINT [FK_PageToken_Page] FOREIGN KEY([PageId])
REFERENCES [dbo].[Page] ([Id])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PageToken_Page]') AND parent_object_id = OBJECT_ID(N'[dbo].[PageToken]'))
ALTER TABLE [dbo].[PageToken] CHECK CONSTRAINT [FK_PageToken_Page]