CREATE TABLE #tmp_62d3e24e93fd42a09415ed949816ce7d ([Id] [int],[UserId] [int],[RoleId] [int])
GO

INSERT INTO #tmp_62d3e24e93fd42a09415ed949816ce7d ([UserId],[RoleId]) VALUES
(1,1),
(7,1),
(15,3),
(16,3)
GO
ALTER TABLE [dbo].[UserRole] NOCHECK CONSTRAINT ALL
GO
INSERT INTO [dbo].[UserRole] (
	[UserId],[RoleId])
SELECT
	[UserId],[RoleId]
FROM #tmp_62d3e24e93fd42a09415ed949816ce7d as S
WHERE NOT EXISTS (
	SELECT TOP 1 1 FROM  [dbo].[UserRole] as T
	WHERE 
)
ALTER TABLE [dbo].[UserRole] CHECK CONSTRAINT ALL
GO
DROP TABLE #tmp_62d3e24e93fd42a09415ed949816ce7d
GO
