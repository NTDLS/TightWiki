CREATE TABLE #tmp_c09d2a49cb6543faa768b18d8349a1bc ([Id] [int],[Name] [nvarchar](128),[Navigation] [nvarchar](128),[Description] [nvarchar](max),[Revision] [int],[CreatedByUserId] [int],[CreatedDate] [datetime],[ModifiedByUserId] [int],[ModifiedDate] [datetime])
GO

INSERT INTO #tmp_c09d2a49cb6543faa768b18d8349a1bc ([Name],[Navigation],[Description],[Revision],[CreatedByUserId],[CreatedDate],[ModifiedByUserId],[ModifiedDate]) VALUES
('Home','home','The home page',67,1,'1/1/1900 12:00:00 AM',7,'10/28/2022 8:54:13 PM'),
('Function Calling Convention Wiki Help','function_calling_convention_wiki_help','Outlines the syntax and formatting for calling wiki functions.',47,1,'9/16/2022 10:33:14 AM',7,'10/28/2022 8:54:13 PM'),
('Development Notes','development_notes','Landry list of implementation ideas.',47,1,'9/16/2022 3:41:43 PM',7,'10/28/2022 8:54:13 PM'),
('Literals Wiki Help','literals_wiki_help','Literal blocks for displaying verbatim content',40,1,'9/22/2022 4:21:38 PM',7,'10/28/2022 8:54:13 PM'),
('Markup Wiki Help','markup_wiki_help','Basic markup such as bold, italics, underline, etc.',54,1,'9/23/2022 11:25:33 AM',7,'10/28/2022 8:54:13 PM'),
('Headings Wiki Help','headings_wiki_help','Headings are used to define the outline of a page.',44,1,'9/23/2022 11:25:56 AM',7,'10/28/2022 8:54:13 PM'),
('Links Wiki Help','links_wiki_help','Linking between wiki pages and external content.',46,1,'9/23/2022 5:59:56 PM',7,'10/28/2022 8:54:13 PM'),
('Attachemnts Wiki Help','attachemnts_wiki_help','How to attach and display files for download.',45,1,'9/26/2022 5:58:29 PM',7,'10/28/2022 8:54:14 PM'),
('Whitespace Wiki Help','whitespace_wiki_help','How the wiki handles whitespace and what you can do to manipulate it.',43,1,'9/28/2022 3:49:24 PM',7,'10/28/2022 8:54:14 PM'),
('Include:Experimental','includeexperimental','Include telling readers that the contents is experimental.',41,1,'9/28/2022 6:04:07 PM',7,'10/28/2022 8:54:14 PM'),
('Fallout Heads','fallout_heads','Heads, from fallout - need we say more?',38,1,'9/30/2022 1:11:34 PM',7,'10/28/2022 8:54:14 PM'),
('Wiki Page Does Not Exist','wiki_page_does_not_exist','This is the content that is displayed when a wiki pages is requested that does not exist.',40,1,'9/30/2022 1:29:11 PM',7,'10/28/2022 8:54:14 PM'),
('Wiki Default Page','wiki_default_page','This pages content will be used as the default content for new pages when they are created.',40,1,'9/30/2022 2:11:18 PM',7,'10/28/2022 8:54:14 PM'),
('Wiki Help','wiki_help','All the wiki help, all in one place.',39,1,'10/4/2022 7:21:20 PM',7,'10/28/2022 8:54:14 PM'),
('Wiki Page Revision Does Not Exist','wiki_page_revision_does_not_exist','This is the content that is displayed when a wiki page revision is requested that does not exist.',40,1,'10/5/2022 2:55:18 PM',7,'10/28/2022 8:54:14 PM'),
('Include:Do Not Modify','includedo_not_modify','Include asking reader not to modify the page.',42,1,'10/6/2022 3:31:19 PM',7,'10/28/2022 8:54:14 PM'),
('TightWiki Media','tightwiki_media','Page for official media attachments.',40,1,'10/7/2022 7:14:51 PM',7,'10/28/2022 8:54:14 PM'),
('Recently Modified','recently_modified','A list of recently modified pages.',46,7,'10/17/2022 8:38:36 PM',7,'10/28/2022 8:54:14 PM'),
('Embed YouTube Video','embed_youtube_video','How to embed a youtube video into your wiki page.',39,7,'10/19/2022 4:40:38 PM',7,'10/28/2022 8:54:14 PM'),
('Sandbox','sandbox','A place to try out new things.',41,7,'10/21/2022 2:47:20 PM',7,'10/28/2022 8:54:14 PM'),
('Jumbotron Wiki Help','jumbotron_wiki_help','Create large box. Can contain other containers.',43,7,'10/24/2022 7:58:59 PM',7,'10/28/2022 8:54:14 PM'),
('Wiki About','wiki_about','The TightWiki origin story, motivations and basic principals.',52,7,'10/25/2022 7:35:42 PM',7,'10/28/2022 8:54:14 PM'),
('Cards Wiki Help : Examples','cards_wiki_help_examples','Examples of cards with nesting.',77,7,'10/26/2022 3:36:56 PM',7,'10/28/2022 8:54:14 PM'),
('Foreground Wiki Help','foreground_wiki_help','Use the foreground block to color a section of the wiki text.',37,7,'10/26/2022 7:42:45 PM',7,'10/28/2022 8:54:14 PM'),
('Test','test','Test it like its hot!',122,7,'10/26/2022 8:10:15 PM',7,'10/28/2022 8:54:14 PM'),
('Alert Scope Function Wiki Help','alert_scope_function_wiki_help','Alert panels bring important information to the attention of the reader.',35,1,'10/27/2022 8:23:18 PM',7,'10/28/2022 8:54:14 PM'),
('Code Scope Function Wiki Help','code_scope_function_wiki_help','Display formatted, wiki-unprocessed and syntax-hilighted code.',16,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Bullets Scope Function Wiki Help','bullets_scope_function_wiki_help','Create hierarchical ordered or unordered lists.',18,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Jumbotron Scope Function Wiki Help','jumbotron_scope_function_wiki_help','Large grey box good for calling attention in a non-critical way.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Callout Scope Function Wiki Help','callout_scope_function_wiki_help','Prominently disply useful information in a failty understated panel.',16,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Background Scope Function Wiki Help','background_scope_function_wiki_help','Set the background color for a block of content.',15,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Foreground Scope Function Wiki Help','foreground_scope_function_wiki_help','Set the foreground color for a block of content.',14,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Card Scope Function Wiki Help','card_scope_function_wiki_help','Cards are good for displaying every-day content and can have a title.',17,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Collapse Scope Function Wiki Help','collapse_scope_function_wiki_help','Dynamically show or hide a section of the wiki body.',14,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Set Standard Function Wiki Help','set_standard_function_wiki_help','Set wiki page variable value.',21,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Get Standard Function Wiki Help','get_standard_function_wiki_help','Get wiki page variable value.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Color Standard Function Wiki Help','color_standard_function_wiki_help','Set the color of a portion of text.',16,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Tag Standard Function Wiki Help','tag_standard_function_wiki_help','Associate tags with a page.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('SearchList Standard Function Wiki Help','searchlist_standard_function_wiki_help','Create  a list from a search of wiki body contents.',16,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('TagList Standard Function Wiki Help','taglist_standard_function_wiki_help','Create a list from a search of page tags.',12,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('SearchCloud Standard Function Wiki Help','searchcloud_standard_function_wiki_help','Create a cloud of pages from a search of wiki body contents.',16,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('TagGlossary Standard Function Wiki Help','tagglossary_standard_function_wiki_help','Create a glossary from a search of specified tags.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('RecentlyModified Standard Function Wiki Help','recentlymodified_standard_function_wiki_help','Disply a list of recently modified wiki pages.',12,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('TextGlossary Standard Function Wiki Help','textglossary_standard_function_wiki_help','Create a glossary from a search of wiki body contens.',14,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('TagCloud Standard Function Wiki Help','tagcloud_standard_function_wiki_help','Create a tag cloud from a seed tag.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Image Standard Function Wiki Help','image_standard_function_wiki_help','Display images in the wiki body.',14,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('File Standard Function Wiki Help','file_standard_function_wiki_help','Insert file download links into the wiki body.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Tags Standard Function Wiki Help','tags_standard_function_wiki_help','Display the tags associated with the page.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('EditLink Standard Function Wiki Help','editlink_standard_function_wiki_help','Insert a link to quickly edit the page.',14,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('Inject Standard Function Wiki Help','inject_standard_function_wiki_help','Inserts the un-processed wiki body of one page into the calling page.',14,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('BR Standard Function Wiki Help','br_standard_function_wiki_help','Inserts one or more line-breaks into the wiki body.',14,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('HR Standard Function Wiki Help','hr_standard_function_wiki_help','Inserts a horizontal rule (divider) into the wiki bosy.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:14 PM'),
('History Standard Function Wiki Help','history_standard_function_wiki_help','Displays the modification history of a page.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('Attachments Standard Function Wiki Help','attachments_standard_function_wiki_help','Lists the attached files associated with a page.',14,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('TOC Standard Function Wiki Help','toc_standard_function_wiki_help','Generate a table-of-contents for a page from the headings.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('Title Standard Function Wiki Help','title_standard_function_wiki_help','Displays the title of the wiki page in title format.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('Navigation Standard Function Wiki Help','navigation_standard_function_wiki_help','Diaplys the URL friendly navigation name of a page.',16,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('Name Standard Function Wiki Help','name_standard_function_wiki_help','Displays the pages name.',15,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('Created Standard Function Wiki Help','created_standard_function_wiki_help','Displays the created date/time of the page.',15,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('LastModified Standard Function Wiki Help','lastmodified_standard_function_wiki_help','Displays the modified date/time of the page.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('AppVersion Standard Function Wiki Help','appversion_standard_function_wiki_help','Displays the wiki engine version.',14,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('Deprecate Instruction Function Wiki Help','deprecate_instruction_function_wiki_help','Processing instruction indicating the page needs to be deleted.',14,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('Protect Instruction Function Wiki Help','protect_instruction_function_wiki_help','Processing instruction indicating the page is protected from unauthorized modification.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('Template Instruction Function Wiki Help','template_instruction_function_wiki_help','Processing instruction indicating the page is a template.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('Review Instruction Function Wiki Help','review_instruction_function_wiki_help','Processing instruction indicating the page needs to be reviewed.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('Include Instruction Function Wiki Help','include_instruction_function_wiki_help','Processing instruction indicating the page is an include and not a while page.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('Draft Instruction Function Wiki Help','draft_instruction_function_wiki_help','Processing instruction indicating the page is in draft - is incomplete.',13,1,'10/28/2022 3:45:30 PM',7,'10/28/2022 8:54:15 PM'),
('Include Standard Function Wiki Help','include_standard_function_wiki_help','Inserts the processed wiki body of one page into the calling page.',5,7,'10/28/2022 8:30:45 PM',7,'10/28/2022 8:54:15 PM'),
('Related Standard Function Wiki Help','related_standard_function_wiki_help','Create a list of related pages based on tag similarities.',5,1,'10/28/2022 8:52:35 PM',7,'10/28/2022 8:57:28 PM')
GO
ALTER TABLE [dbo].[Page] NOCHECK CONSTRAINT ALL
GO
INSERT INTO [dbo].[Page] (
	[Name],[Navigation],[Description],[Revision],[CreatedByUserId],[CreatedDate],[ModifiedByUserId],[ModifiedDate])
SELECT
	[Name],[Navigation],[Description],[Revision],[CreatedByUserId],[CreatedDate],[ModifiedByUserId],[ModifiedDate]
FROM #tmp_c09d2a49cb6543faa768b18d8349a1bc as S
ALTER TABLE [dbo].[Page] CHECK CONSTRAINT ALL
GO
DROP TABLE #tmp_c09d2a49cb6543faa768b18d8349a1bc
GO
