IF NOT EXISTS(SELECT TOP 1 1 FROM sys.objects WHERE object_id = object_id('[dbo].[PageSearchPaged]'))
BEGIN
    EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[PageSearchPaged] AS'
END
GO

ALTER PROCEDURE [dbo].[PageSearchPaged]
(
	@PageNumber int = 1,
	@PageSize int = 0,
	@AllowFuzzyMatching BIT = NULL,
	@SearchTerms dbo.PageTokenType READONLY
) AS
BEGIN--PROCEDURE
	SET NOCOUNT ON;

	DECLARE @PaginationSize int = @PageSize
	DECLARE @MinimumMatchScore Decimal(16, 2)
	DECLARE @MaximumScore Decimal(16, 2)
	DECLARE @TokenCount INT = (SELECT COUNT(0) FROM @SearchTerms)
	
	DECLARE @PageTokens TABLE
	(
		PageId INT,
		[Match] Decimal(3, 2),
		[Weight] Decimal(6, 2),
		[Score] Decimal(16, 2)
	)

	SELECT
		@MinimumMatchScore = Cast(CE.[Value] as Decimal(16, 2))
	FROM
		[ConfigurationEntry] as CE
	INNER JOIN [ConfigurationGroup] as CG
		ON CG.Id = CE.ConfigurationGroupId
	WHERE
		CG.[Name] = 'Search'
		AND CE.[Name] = 'Minimum Match Score'

	IF(@AllowFuzzyMatching IS NULL)
	BEGIN--IF
	SELECT
		@AllowFuzzyMatching = Cast(CE.[Value] as Bit)
	FROM
		[ConfigurationEntry] as CE
	INNER JOIN [ConfigurationGroup] as CG
		ON CG.Id = CE.ConfigurationGroupId
	WHERE
		CG.[Name] = 'Search'
		AND CE.[Name] = 'Allow Fuzzy Matching'
	END--IF

	IF(@PageSize = 0)
	BEGIN--IF
		SELECT
			@PaginationSize = Cast(CE.[Value] as Int)
		FROM
			[ConfigurationEntry] as CE
		INNER JOIN [ConfigurationGroup] as CG
			ON CG.Id = CE.ConfigurationGroupId
		WHERE
			CG.[Name] = 'Basic'
			AND CE.[Name] = 'Pagination Size'
	END--IF

	INSERT INTO @PageTokens
	(
		PageId,
		[Match],
		[Weight],
		[Score]
	)
	SELECT
		PageId,
		SUM([Match]) as [Match],
		SUM([Weight]) as [Weight],
		SUM([Score]) as [Score]
	FROM
	(
		SELECT
			T.PageId,
			COUNT(DISTINCT T.Token) / (@TokenCount + 0.0) as [Match],
			SUM(T.[Weight] * 1.5) as [Weight],
			--Extra weight on score for exact matches:
			SUM(T.[Weight] * 1.5) * (COUNT(DISTINCT T.Token) / (@TokenCount + 0.0)) as [Score]
		FROM
			PageToken as T
		INNER JOIN @SearchTerms as ST
			ON ST.Token = T.Token
		GROUP BY
			T.PageId

		UNION ALL

		SELECT
			T.PageId,
			COUNT(DISTINCT T.DoubleMetaphone) / (@TokenCount + 0.0) as [Match],
			SUM(T.[Weight] * 1.0) as [Weight],
			--No weight benefits on score for fuzzy matching weight for exact matches:
			(COUNT(DISTINCT T.DoubleMetaphone) / (@TokenCount + 0.0)) as [Score]
		FROM
			PageToken as T
		INNER JOIN @SearchTerms as ST
			ON ST.Token != T.Token
			AND ST.DoubleMetaphone = T.DoubleMetaphone
		WHERE
			@AllowFuzzyMatching = CAST(1 AS Bit)
		GROUP BY
			T.PageId
		) as T
	GROUP BY
		T.PageId
	HAVING
		SUM(Score) >= @MinimumMatchScore

	SELECT @MaximumScore = MAX(Score) FROM @PageTokens

	SELECT
		P.Id,
		(ST.[Score] / @MaximumScore) * 100.0 as Score,
		ST.[Match],
		ST.[Weight],
		P.[Name],
		P.Navigation,
		P.[Description],
		P.Revision,
		P.CreatedByUserId,
		P.CreatedDate,
		P.ModifiedByUserId,
		P.ModifiedDate,
		Createduser.AccountName as CreatedByUserName,
		ModifiedUser.AccountName as ModifiedByUserName,
		@PaginationSize as PaginationSize,
		(
			SELECT
				CEILING(Count(0) / (@PaginationSize + 0.0))
			FROM
				[Page] as P
			INNER JOIN @PageTokens as ST
				ON ST.PageId = P.Id
		) as PaginationCount
	FROM
		[Page] as P
	INNER JOIN [User] as ModifiedUser
		ON ModifiedUser.Id = P.ModifiedByUserId
	INNER JOIN [User] as Createduser
		ON Createduser.Id = P.CreatedByUserId
	INNER JOIN @PageTokens as ST
		ON ST.PageId = P.Id
	ORDER BY
		ST.[Score] DESC,
		P.[Name],
		P.Id
	OFFSET ((@PageNumber - 1) * @PaginationSize) ROWS FETCH NEXT @PaginationSize ROWS ONLY

END--PROCEDURE