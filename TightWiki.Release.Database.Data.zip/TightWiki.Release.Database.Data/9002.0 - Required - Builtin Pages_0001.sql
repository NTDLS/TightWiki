DECLARE @Discard TABLE (Id INT)
DECLARE @UserId INT = (SELECT Id FROM [User] WHERE AccountName = 'admin')
DECLARE @DateTime DateTime = GetUtcDate()
DECLARE @Id as int = (SELECT Id FROM [Page] WHERE Navigation = 'builtin::wiki_page_does_not_exist')
DECLARE @Name as nvarchar (128) = 'Builtin :: Wiki Page Does Not Exist'
DECLARE @Namespace as nvarchar (128) = 'Builtin'
DECLARE @Navigation as nvarchar (128) = 'builtin::wiki_page_does_not_exist'
DECLARE @Description as nvarchar (MAX) = 'This is the content that is displayed when a wiki pages is requested that does not exist.'
DECLARE @Body varbinary(max) = DECOMPRESS(0x1F8B08000000000004007D90BD0AC2401084A7167C87030B15820F602362A39D8590422C423C7F50A2261115F1DDFD6E4D6223B22C379B7C33D94B471D954AB4554F139D9469A33D535F6DB5F4A4C63ACA2B87EA2986CC61F6F456919CE6E6F5A8356EAF0295A14A4EAF3B6481FEA4855E6867F4B9F13DA0AF9C39D305E5CDE1C9FB9F39608A497B545CA6AE11755E6A898965393CA546CD16A167DCF44B67509F6F86FD8EEC17594698521DD0810BF96575832515937BA09DA695CB6948B91F6F22CBD8D8FF4DE984A74EB786DB3509F5BF595161D317556FFD062EF05608B0010000)
INSERT INTO @Discard EXEC SavePage @Id = @Id, @Name = @Name, @Namespace = @Namespace, @Navigation = @Navigation, @Description = @Description, @Body = @Body, @CreatedByUserId = @UserId, @CreatedDate = @DateTime, @ModifiedByUserId = @UserId, @ModifiedDate = @DateTime
GO
DECLARE @Discard TABLE (Id INT)
DECLARE @UserId INT = (SELECT Id FROM [User] WHERE AccountName = 'admin')
DECLARE @DateTime DateTime = GetUtcDate()
DECLARE @Id as int = (SELECT Id FROM [Page] WHERE Navigation = 'builtin::wiki_default_page')
DECLARE @Name as nvarchar (128) = 'Builtin :: Wiki Default Page'
DECLARE @Namespace as nvarchar (128) = 'Builtin'
DECLARE @Navigation as nvarchar (128) = 'builtin::wiki_default_page'
DECLARE @Description as nvarchar (MAX) = 'This pages content will be used as the default content for new pages when they are created.'
DECLARE @Body varbinary(max) = DECOMPRESS(0x1F8B08000000000004007D8FCB0AC2301045EF5AF01F026E14DCE8BE50D0BD22FE40B55102C5408CBA10FFDD33A1148A2097C963EE23935AB55A2535BA286BAA8966202B509DBC5CB91FE1AF9A6B3B281745FB061B3A890C633D5CA307CEAC255EF39DFA9C08E75047DD607D59EFE4B8FEC5A833E70FB064AB0AECF4449B5803FB6BC455DAE30A25C952567FD9F5883D90D6319D4DD20EFF4E3FDD2FC081484020010000)
INSERT INTO @Discard EXEC SavePage @Id = @Id, @Name = @Name, @Namespace = @Namespace, @Navigation = @Navigation, @Description = @Description, @Body = @Body, @CreatedByUserId = @UserId, @CreatedDate = @DateTime, @ModifiedByUserId = @UserId, @ModifiedDate = @DateTime
GO
DECLARE @Discard TABLE (Id INT)
DECLARE @UserId INT = (SELECT Id FROM [User] WHERE AccountName = 'admin')
DECLARE @DateTime DateTime = GetUtcDate()
DECLARE @Id as int = (SELECT Id FROM [Page] WHERE Navigation = 'builtin::wiki_page_revision_does_not_exist')
DECLARE @Name as nvarchar (128) = 'Builtin :: Wiki Page Revision Does Not Exist'
DECLARE @Namespace as nvarchar (128) = 'Builtin'
DECLARE @Navigation as nvarchar (128) = 'builtin::wiki_page_revision_does_not_exist'
DECLARE @Description as nvarchar (MAX) = 'This is the content that is displayed when a wiki page revision is requested that does not exist.'
DECLARE @Body varbinary(max) = DECOMPRESS(0x1F8B08000000000004007D50CB0AC2400C9CB3E03F047AA950FC006FE2456F1E841EC443A9DB072DADAEF585F8EFCEC66DBD4809B39B6C2693640304E890204788155A34C850329A618A095EB4256A1858B242C4645A724A224704C1566B0D3DCBF3C6CC85703A82236FC35818B5AC17460F65745EDF618742EB4F234A4FDE579F39D333AA61D861BCCB7CE8B2E15E3F9D869C6FB5EB5DB3B7DB25D5284545DFF19C56E7A7DBD362AA568460EDAB040B9AFCC944AA91E96FA644C257C17DE0158342BFF781E6267DD3FAA93F6B76698C9E010000)
INSERT INTO @Discard EXEC SavePage @Id = @Id, @Name = @Name, @Namespace = @Namespace, @Navigation = @Navigation, @Description = @Description, @Body = @Body, @CreatedByUserId = @UserId, @CreatedDate = @DateTime, @ModifiedByUserId = @UserId, @ModifiedDate = @DateTime
GO
DECLARE @Discard TABLE (Id INT)
DECLARE @UserId INT = (SELECT Id FROM [User] WHERE AccountName = 'admin')
DECLARE @DateTime DateTime = GetUtcDate()
DECLARE @Id as int = (SELECT Id FROM [Page] WHERE Navigation = 'builtin::media')
DECLARE @Name as nvarchar (128) = 'Builtin :: Media'
DECLARE @Namespace as nvarchar (128) = 'Builtin'
DECLARE @Navigation as nvarchar (128) = 'builtin::media'
DECLARE @Description as nvarchar (MAX) = 'Page for official media attachments.'
DECLARE @Body varbinary(max) = DECOMPRESS(0x1F8B0800000000000400AD8EBB0AC24010454F2DF80F816DB220E2AA043F4141B109588718D790D5A4D0FFF7EE82A58D09C3853BAF336330BC68A54043A6CC5052E1C939A97255AF62A1CE5E596048FEA26A27457FE6A668A9D364C03267961459071E89D688576AC273D7ADEF7EA67E4DCF532ED7E45BFBF11BCB3211FB74C1B152D83F988E42A441DE8F246D584F442AD84E4472FA69378A7514C94BBF181F4C6B2F8B1E020000)
INSERT INTO @Discard EXEC SavePage @Id = @Id, @Name = @Name, @Namespace = @Namespace, @Navigation = @Navigation, @Description = @Description, @Body = @Body, @CreatedByUserId = @UserId, @CreatedDate = @DateTime, @ModifiedByUserId = @UserId, @ModifiedDate = @DateTime
GO
